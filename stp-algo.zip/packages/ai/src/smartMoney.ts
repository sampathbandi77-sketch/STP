/**
 * Smart Money Tracking Service
 * Tracks institutional flows, FII/DII, block deals, and bulk deals
 */

import { SmartMoneyFlow } from '../types';
import { QuoteService } from '../api/quotes';
import { DhanAdapter } from '../brokers/dhanAdapter';
import { UpstoxAdapter } from '../brokers/upstoxAdapter';
import { CoinSwitchAdapter } from '../brokers/coinswitchAdapter';

export class SmartMoneyTracker {
  private quoteService: QuoteService;
  private flowData: SmartMoneyFlow[] = [];
  private lastUpdate: number = 0;
  private updateInterval: number = 30000; // 30 seconds

  constructor(quoteService: QuoteService) {
    this.quoteService = quoteService;
  }

  async startTracking(): Promise<void> {
    // Initial load
    await this.updateFlowData();

    // Set up periodic updates
    this.intervalId = setInterval(() => {
      this.updateFlowData();
    }, this.updateInterval);
  }

  stopTracking(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  private async updateFlowData(): Promise<void> {
    try {
      // In production, this would fetch from:
      // 1. Broker API order flow data
      // 2. Exchange market data feeds
      // 3. Block deal windows
      // 4. Bulk deal notifications

      // Mock data for demonstration
      const mockFlow: SmartMoneyFlow = {
        symbol: 'NIFTY',
        fiiBuy: 1250000000,
        fiiSell: 980000000,
        diiBuy: 320000000,
        diiSell: 280000000,
        bulkDeals: 47,
        blockDeals: 12,
        totalValue: 1850000000,
        timestamp: Date.now(),
      };

      this.flowData.push(mockFlow);

      // Keep only last 100 data points
      if (this.flowData.length > 100) {
        this.flowData.shift();
      }

      // Trigger any listeners
      this.onFlowUpdate?.(mockFlow);
    } catch (error) {
      console.error('Failed to update smart money flow data:', error);
    }
  }

  // Event handlers
  private onFlowUpdate?: (flow: SmartMoneyFlow) => void;
  private intervalId: NodeJS.Timeout | null = null;

  onFlowChange(handler: (flow: SmartMoneyFlow) => void): void {
    this.onFlowUpdate = handler;
  }

  getFlowData(): SmartMoneyFlow[] {
    return this.flowData;
  }

  // Get institutional flow summary
  getInstitutionalSummary(): {
    netFII: number;
    netDII: number;
    totalFII: number;
    totalDII: number;
    dominantFlow: 'FII' | 'DII' | 'NEUTRAL';
  } {
    const recent = this.flowData.slice(-10); // Last 10 updates

    const netFII = recent.reduce((sum, flow) => sum + flow.fiiBuy - flow.fiiSell, 0);
    const netDII = recent.reduce((sum, flow) => sum + flow.diiBuy - flow.diiSell, 0);
    const totalFII = recent.reduce((sum, flow) => sum + flow.fiiBuy + flow.fiiSell, 0);
    const totalDII = recent.reduce((sum, flow) => sum + flow.diiBuy + flow.diiSell, 0);

    const dominantFlow = Math.abs(netFII) > Math.abs(netDII)
      ? (netFII > 0 ? 'FII Buying' : 'FII Selling')
      : (netDII > 0 ? 'DII Buying' : 'DII Selling');

    return {
      netFII: Math.round(netFII / 10000000) / 100, // In crores
      netDII: Math.round(netDII / 10000000) / 100, // In crores
      totalFII: Math.round(totalFII / 10000000) / 100,
      totalDII: Math.round(totalDII / 10000000) / 100,
      dominantFlow,
    };
  }

  // Get flow impact analysis
  getFlowImpactAnalysis(symbol: string): {
    impact: 'strong-buy' | 'buy' | 'neutral' | 'sell' | 'strong-sell';
    confidence: number;
    description: string;
  } {
    const flow = this.flowData.find(f => f.symbol === symbol);
    if (!flow) {
      return { impact: 'neutral', confidence: 0, description: 'No flow data available' };
    }

    const fiiNet = flow.fiiBuy - flow.fiiSell;
    const diiNet = flow.diiBuy - flow.diiSell;
    const totalFlow = fiiNet + diiNet;

    let impact: 'strong-buy' | 'buy' | 'neutral' | 'sell' | 'strong-sell';
    let confidence = 50;

    if (Math.abs(totalFlow) > 500000000) { // > 50 crores
      if (totalFlow > 0) {
        impact = 'strong-buy';
        confidence = 85;
      } else {
        impact = 'strong-sell';
        confidence = 85;
      }
    } else if (Math.abs(totalFlow) > 100000000) { // > 10 crores
      if (totalFlow > 0) {
        impact = 'buy';
        confidence = 70;
      } else {
        impact = 'sell';
        confidence = 70;
      }
    } else {
      impact = 'neutral';
      confidence = 40;
    }

    const description = totalFlow > 0
      ? `Institutional buying of ₹${Math.abs(totalFlow).toLocaleString('en-IN')}`
      : totalFlow < 0
        ? `Institutional selling of ₹${Math.abs(totalFlow).toLocaleString('en-IN')}`
        : 'Balanced institutional activity';

    return { impact, confidence, description };
  }
}