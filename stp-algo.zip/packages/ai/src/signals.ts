/**
 * AI Signals Service
 * Generates trading signals using ML models and technical analysis
 */

import { AISignal, Quote, MarketDepth } from '../types';
import { QuoteService } from '../api/quotes';
import { DhanAdapter } from '../brokers/dhanAdapter';
import { UpstoxAdapter } from '../brokers/upstoxAdapter';
import { CoinSwitchAdapter } from '../brokers/coinswitchAdapter';

// Technical indicators calculations
export class TechnicalIndicators {
  // Simple Moving Average
  static SMA(prices: number[], period: number): number[] {
    const results: number[] = [];
    if (prices.length < period) {
      return prices.map(() => 0);
    }
    for (let i = 0; i < prices.length; i++) {
      if (i < period - 1) {
        results.push(0);
      } else {
        const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        results.push(sum / period);
      }
    }
    return results;
  }

  // Exponential Moving Average
  static EMA(prices: number[], period: number): number[] {
    if (prices.length < period) {
      return prices.map(() => 0);
    }

    const multiplier = 2 / (period + 1);
    const results: number[] = [];

    // Calculate initial SMA
    const sma = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
    results.push(sma);

    // Calculate EMA for rest
    for (let i = period; i < prices.length; i++) {
      results.push((prices[i] - results[results.length - 1]) * multiplier + results[results.length - 1]);
    }

    return results;
  }

  // Relative Strength Index (RSI)
  static RSI(prices: number[], period: number = 14): { rsi: number[], overbought: number[], oversold: number[] } {
    if (prices.length < period + 1) {
      return { rsi: prices.map(() => 50), overbought: [], oversold: [] };
    }

    const changes: number[] = [];
    for (let i = 1; i < prices.length; i++) {
      changes.push(prices[i] - prices[i - 1]);
    }

    const gains: number[] = changes.map(c => Math.max(c, 0));
    const losses: number[] = changes.map(c => Math.min(c, 0) * -1);

    const avgGain: number[] = [gains.slice(0, period).reduce((a, b) => a + b, 0) / period];
    const avgLoss: number[] = [losses.slice(0, period).reduce((a, b) => a + b, 0) / period];

    const rsi: number[] = [50]; // Start at 50

    for (let i = 1; i < gains.length; i++) {
      const avgGainCurrent = (avgGain[avgGain.length - 1] * (period - 1) + gains[i]) / period;
      const avgLossCurrent = (avgLoss[avgLoss.length - 1] * (period - 1) + losses[i]) / period;

      const rs = avgLossCurrent === 0 ? 100 : avgGainCurrent / avgLossCurrent;
      const rsiValue = 100 - (100 / (1 + rs));

      rsi.push(rsiValue);
      avgGain.push(avgGainCurrent);
      avgLoss.push(avgLossCurrent);
    }

    const overbought = rsi.filter((_, i) => rsi[i] > 70);
    const oversold = rsi.filter((_, i) => rsi[i] < 30);

    return { rsi, overbought: overbought.map(i => i - period), oversold: oversold.map(i => i - period) };
  }

  // MACD (Moving Average Convergence Divergence)
  static MACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
    const fastEMA = this.EMA(prices, fastPeriod);
    const slowEMA = this.EMA(prices, slowPeriod);

    // Calculate MACD line
    const macdLine: number[] = [];
    for (let i = 0; i < prices.length; i++) {
      if (i < slowPeriod + fastPeriod) {
        macdLine.push(0);
      } else {
        macdLine.push(fastEMA[i] - slowEMA[i - slowPeriod + fastPeriod]);
      }
    }

    // Calculate signal line
    const signalLine = this.EMA(macdLine, signalPeriod);

    // Calculate histogram
    const histogram: number[] = [];
    for (let i = 0; i < macdLine.length; i++) {
      histogram.push(macdLine[i] - signalLine[i]);
    }

    return { macdLine, signalLine, histogram };
  }

  // Bollinger Bands
  static BB(prices: number[], period: number = 20, numStdDev: number = 2) {
    const middleBand: number[] = [];
    const upperBand: number[] = [];
    const lowerBand: number[] = [];

    for (let i = 0; i < prices.length; i++) {
      if (i < period - 1) {
        middleBand.push(0);
        upperBand.push(0);
        lowerBand.push(0);
      } else {
        const slice = prices.slice(i - period + 1, i + 1);
        const mean = slice.reduce((a, b) => a + b, 0) / period;
        const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period;
        const stdDev = Math.sqrt(variance);

        middleBand.push(mean);
        upperBand.push(mean + (numStdDev * stdDev));
        lowerBand.push(mean - (numStdDev * stdDev));
      }
    }

    return { middleBand, upperBand, lowerBand };
  }
}

// Signal Generator
export class SignalGenerator {
  private quoteService: QuoteService;

  constructor(quoteService: QuoteService) {
    this.quoteService = quoteService;
  }

  async generateSignal(symbol: string): Promise<AISignal | null> {
    try {
      // Get current quote
      const quote = await this.quoteService.getQuote(symbol);

      // In a real implementation, we would:
      // 1. Fetch historical data
      // 2. Calculate technical indicators
      // 3. Run ML model
      // 4. Generate signal with confidence

      // Mock signal generation for demonstration
      const changePercent = quote.changePercent;
      const ltp = quote.ltp;

      let signalType: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
      let confidence = 50;
      let priceTarget: number | null = null;
      let stopLoss: number | null = null;

      // Simple rule-based logic for demo
      if (changePercent > 2 && quote.volume > 1000000) {
        signalType = 'BUY';
        confidence = 75 + Math.random() * 25;
        priceTarget = ltp * (1 + (2 + Math.random() * 3) / 100);
        stopLoss = ltp * (1 - (1 + Math.random() * 2) / 100);
      } else if (changePercent < -2 && quote.volume > 1000000) {
        signalType = 'SELL';
        confidence = 75 + Math.random() * 25;
        priceTarget = ltp * (1 - (2 + Math.random() * 3) / 100);
        stopLoss = ltp * (1 + (1 + Math.random() * 2) / 100);
      } else if (Math.abs(changePercent) < 1) {
        signalType = 'HOLD';
        confidence = 60 + Math.random() * 30;
      }

      return {
        id: `signal-${symbol}-${Date.now()}`,
        symbol,
        signalType,
        confidence,
        priceTarget: Math.round(priceTarget || ltp * 100) / 100,
        stopLoss: Math.round(stopLoss || ltp * 100) / 100,
        timeHorizon: 'MEDIUM',
        model: 'Ensemble-LSTM',
        features: ['RSI', 'MACD', 'Volume', 'Price Action'],
        generatedAt: new Date(),
        description: this.getSignalDescription(signalType, changePercent)
      };
    } catch (error) {
      console.error(`Failed to generate signal for ${symbol}:`, error);
      return null;
    }
  }

  private getSignalDescription(signalType: 'BUY' | 'SELL' | 'HOLD', changePercent: number): string {
    const basePriceChange = changePercent.toFixed(2);

    switch (signalType) {
      case 'BUY':
        return `Bullish momentum detected. Price up ${basePriceChange}%. Strong volume confirmation.`;
      case 'SELL':
        return `Bearish momentum detected. Price down ${basePriceChange}%. Volume increasing.`;
      case 'HOLD':
        return `Sideways movement. Price change ${basePriceChange}%. Wait for clearer direction.`;
      default:
        return 'Signal generation in progress.';
    }
  }

  async generateSignals(symbols: string[]): Promise<AISignal[]> {
    const promises = symbols.map(symbol => this.generateSignal(symbol));
    return Promise.all(promises).then(results => results.filter((r): r is AISignal => r !== null));
  }
}