/**
 * CoinSwitch Broker Adapter
 * Unified interface for CoinSwitch broker API (crypto focus)
 */

import { BrokerAdapter, Quote, OrderRequest, OrderResponse, Position, MarketDepth } from '../api/types';

// CoinSwitch specific API endpoints and types
const COINSWITCH_BASE_URL = 'https://api.coinswitch.co';
const COINSWITCH_WS_URL = 'wss://realtime.coinswitch.co';

// CoinSwitch product types
enum CoinSwitchProduct {
  SPOT = 'SPOT',
  MARGIN = 'MARGIN',
  FUTURES = 'FUTURES',
}

// CoinSwitch order types
enum CoinSwitchOrderType {
  BUY = 'BUY',
  SELL = 'SELL',
}

// CoinSwitch transaction types
enum CoinSwitchTransactionType {
  BUY = 'BUY',
  SELL = 'SELL',
}

// Interface for CoinSwitch credentials
export interface CoinSwitchCredentials {
  apiKey: string;
  secretKey: string;
  passphrase: string;
  passphrase2?: string;
}

// Interface for CoinSwitch trading pair
export interface CoinSwitchPair {
  base: string;
  quote: string;
  displayName: string;
}

// Interface for CoinSwitch order request
export interface CoinSwitchOrderRequest {
  pair: string;
  order_type: 'MARKET' | 'LIMIT';
  side: 'BUY' | 'SELL';
  quantity: number;
  price?: number;
}

// Interface for CoinSwitch order response
export interface CoinSwitchOrderResponse {
  order_id: string;
  status: string;
  executed_price?: number;
  executed_quantity?: number;
  remaining_quantity?: number;
  timestamp: string;
}

// Interface for CoinSwitch quote
export interface CoinSwitchQuote {
  symbol: string;
  last_price: number;
  bid: number;
  ask: number;
  high_24h: number;
  low_24h: number;
  base_volume: number;
  quote_volume: number;
  percent_change_24h: number;
  timestamp: number;
}

// Interface for CoinSwitch market depth
export interface CoinSwitchMarketDepth {
  symbol: string;
  bids: CoinSwitchDepthLevel[];
  asks: CoinSwitchDepthLevel[];
  last_traded_price: number;
}

// CoinSwitch depth level
export interface CoinSwitchDepthLevel {
  price: number;
  quantity: number;
}

// Implementation of the BrokerAdapter for CoinSwitch
export class CoinSwitchAdapter implements BrokerAdapter {
  private apiKey: string;
  private secretKey: string;
  private passphrase: string;
  private wsConnection: WebSocket | null = null;
  private pendingSubscriptions: Map<string, () => void> = new Map();
  private quoteCallbacks: Map<string, (quote: Quote) => void> = new Map();

  constructor(credentials: CoinSwitchCredentials) {
    this.apiKey = credentials.apiKey;
    this.secretKey = credentials.secretKey;
    this.passphrase = credentials.passphrase;
  }

  async authenticate(credentials: CoinSwitchCredentials): Promise<any> {
    // In production: validate credentials with CoinSwitch API
    return { success: true, token: credentials.apiKey };
  }

  async refreshToken(): Promise<void> {
    // CoinSwitch API typically uses static API keys
  }

  // Market Data Methods

  async subscribe(symbols: string[], mode: 'ltp' | 'quote' | 'depth' = 'ltp'): Promise<void> {
    if (!this.wsConnection?.readyState === WebSocket.OPEN) {
      this.connectWebSocket();
    }

    symbols.forEach(symbol => {
      const message = JSON.stringify({
        action: 'subscribe',
        mode: mode,
        symbol: symbols.join(','),
        exchange: 'COINSWITCH'
      });
      this.wsConnection?.send(message);
      this.pendingSubscriptions.set(symbol, () => {
        this.unsubscribe([symbol]);
      });
    });
  }

  async unsubscribe(symbols: string[]): Promise<void> {
    if (this.wsConnection?.readyState === WebSocket.OPEN) {
      symbols.forEach(symbol => {
        const message = JSON.stringify({
          action: 'unsubscribe',
          symbol: symbols.join(','),
          exchange: 'COINSWITCH'
        });
        this.wsConnection?.send(message);
      });
    }
    symbols.forEach(symbol => this.pendingSubscriptions.delete(symbol));
  }

  async getQuote(symbol: string): Promise<Quote> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/quote?symbol=${symbol}`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return this.mapCoinSwitchQuote(data);
  }

  async getDepth(symbol: string): Promise<MarketDepth> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/depth?symbol=${symbol}`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return this.mapCoinSwitchDepth(data);
  }

  async getOHLC(symbol: string, timeframe: string = '1d'): Promise<any[]> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/ohlc?symbol=${symbol}&timeframe=${timeframe}`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.data || [];
  }

  // Order Methods

  async placeOrder(order: OrderRequest): Promise<OrderResponse> {
    const coinswitchOrder = {
      pair: order.symbol,
      order_type: order.orderType || 'LIMIT',
      side: order.side === 'BUY' ? 'BUY' : 'SELL',
      quantity: order.quantity,
      price: order.price
    };

    const response = await fetch(`${COINSWITCH_BASE_URL}/order/place`, {
      method: 'POST',
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(coinswitchOrder)
    });

    const data = await response.json();
    return this.mapCoinSwitchOrderResponse(data);
  }

  async modifyOrder(orderId: string, modifications: any): Promise<void> {
    await fetch(`${COINSWITCH_BASE_URL}/order/modify`, {
      method: 'POST',
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        order_id: orderId,
        ...modifications
      })
    });
  }

  async cancelOrder(orderId: string): Promise<void> {
    await fetch(`${COINSWITCH_BASE_URL}/order/cancel`, {
      method: 'POST',
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
      },
      body: JSON.stringify({ order_id: orderId })
    });
  }

  async getOrders(filters?: any): Promise<Order[]> {
    const url = filters ? `${COINSWITCH_BASE_URL}/order/list?${new URLSearchParams(filters)}` : `${COINSWITCH_BASE_URL}/order/list`;
    const response = await fetch(url, {
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.orders || [];
  }

  async getTrades(dateRange: any): Promise<any[]> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/trades?from=${dateRange.from}&to=${dateRange.to}`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.trades || [];
  }

  // Portfolio Methods

  async getPositions(): Promise<Position[]> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/position`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.positions || [];
  }

  async getHoldings(): Promise<any[]> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/holding`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.holdings || [];
  }

  async getFunds(): Promise<any> {
    const response = await fetch(`${COINSWITCH_BASE_URL}/funds`, {
      headers: {
        'X-API-Key': this.apiKey,
        'Secret-Key': this.secretKey,
        'Passphrase': this.passphrase,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data;
  }

  // WebSocket Events

  on(event: string, handler: Function): void {
    if (event === 'quote') {
      this.wsConnection?.addEventListener('message', (event: MessageEvent) => {
        const data = JSON.parse(event.data);
        if (data.action === 'quote' && data.symbol) {
          const quote = this.mapCoinSwitchQuote(data);
          this.quoteCallbacks.get(data.symbol)?.(quote);
        }
      });
    }
  }

  off(event: string, handler: Function): void {}

  // Private Methods

  private connectWebSocket(): void {
    this.wsConnection = new WebSocket(`${COINSWITCH_WS_URL}/market-data?api-key=${this.apiKey}`);

    this.wsConnection?.addEventListener('open', () => {
      console.log('CoinSwitch WebSocket connected');
    });

    this.wsConnection?.addEventListener('message', (event: MessageEvent) => {
      const data = JSON.parse(event.data);
      if (data.type === 'quote' && data.symbol) {
        const quote = this.mapCoinSwitchQuote(data);
        this.quoteCallbacks.get(data.symbol)?.(quote);
      }
    });

    this.wsConnection?.addEventListener('close', () => {
      console.log('CoinSwitch WebSocket disconnected');
      setTimeout(() => this.connectWebSocket(), 5000);
    });
  }

  private mapCoinSwitchQuote(data: any): Quote {
    return {
      symbol: data.symbol || '',
      ltp: data.last_price || data.lastPrice || data.close || 0,
      change: data.percent_change_24h || data.change || 0,
      changePercent: data.percent_change_24h || data.change_percent_24h || 0,
      volume: data.base_volume || data.baseVolume || data.quote_volume || 0,
      open: data.open_24h || data.open24h || 0,
      high: data.high_24h || data.high24h || 0,
      low: data.low_24h || data.low24h || 0,
      close: data.close || data.close_24h || 0,
      timestamp: data.timestamp || Date.now(),
      oi: data.oi || 0
    };
  }

  private mapCoinSwitchDepth(data: any): MarketDepth {
    const bids = (data.bid_prices || []).map((level: any) => ({
      price: level.price,
      quantity: level.quantity
    }));
    const asks = (data.ask_prices || []).map((level: any) => ({
      price: level.price,
      quantity: level.quantity
    }));

    return {
      symbol: data.symbol || '',
      bids,
      asks,
      lastTradedPrice: data.last_traded_price || data.lastTradedPrice || 0,
      totalBuyQuantity: data.total_buy_quantity || 0,
      totalSellQuantity: data.total_sell_quantity || 0
    };
  }

  private mapCoinSwitchOrderResponse(data: any): OrderResponse {
    return {
      orderId: data.order_id || data.id || '',
      status: data.status || 'pending',
      averagePrice: data.executed_price || data.averagePrice || 0,
      executedQuantity: data.executed_quantity || data.executedQuantity || 0,
      totalQuantity: data.remaining_quantity || data.totalQuantity || 0,
      timestamp: data.timestamp || new Date().toISOString()
    };
  }
}