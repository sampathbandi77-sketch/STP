/**
 * Dhan Broker Adapter
 * Unified interface for Dhan broker API
 */

import { BrokerAdapter, Quote, OrderRequest, OrderResponse, Position, MarketDepth } from '../api/types';

// Dhan specific API endpoints and types
const DHAN_BASE_URL = 'https://api.dhan.co';
const DHAN_WS_URL = 'wss://api.dhan.co';

// Dhan order types
enum DhanOrderType {
  BUY = 'BUY',
  SELL = 'SELL',
  BUY_TO_COVER = 'BUY_TO_COVER',
  SELL_TO_CLOSE = 'SELL_TO_CLOSE',
}

// Dhan product types
enum DhanProduct {
  CNC = 'CNC',
  MIS = 'MIS',
  CO = 'CO',
  BO = 'BO',
}

// Dhan validity types
enum DhanValidity {
  DAY = 'DAY',
  IOC = 'IOC',
  TTL = 'TTL',
}

// Dhan transaction types
enum DhanTransactionType {
  BUY = 'BUY',
  SELL = 'SELL',
}

// Interface for Dhan credentials
export interface DhanCredentials {
  accessToken: string;
  clientId: string;
  uid: string;
}

// Interface for Dhan order request
export interface DhanOrderRequest {
  variety: 'BO' | 'CO' | 'NOPE';
  symbol: string;
  transactionType: DhanTransactionType;
  exchangeToken: string;
  exchangeName: 'NSE' | 'NFO' | 'BSE' | 'BFO';
  orderType: 'MARKET' | 'LIMIT' | 'SL' | 'SL-M';
  product: DhanProduct;
  quantity: number;
  price?: number;
  triggerPrice?: number;
  validity: DhanValidity;
  disclosedQuantity?: number;
}

// Interface for Dhan order response
export interface DhanOrderResponse {
  orderId: string;
  status: string;
  statusMessage: string;
  averagePrice?: number;
  executedQuantity?: number;
  totalQuantity?: number;
  timestamp: string;
}

// Interface for Dhan quote
export interface DhanQuote {
  symbol: string;
  ltp: number;
  change: number;
  changePercent: number;
  volume: number;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  oi: number;
}

// Interface for Dhan market depth
export interface DhanMarketDepth {
  symbol: string;
  bids: DhanDepthLevel[];
  asks: DhanDepthLevel[];
  lastTradedPrice: number;
  totalBuyQuantity: number;
  totalSellQuantity: number;
}

export interface DhanDepthLevel {
  price: number;
  quantity: number;
}

// Implementation of the BrokerAdapter for Dhan
export class DhanAdapter implements BrokerAdapter {
  private accessToken: string;
  private clientId: string;
  private wsConnection: WebSocket | null = null;
  private pendingSubscriptions: Map<string, () => void> = new Map();
  private quoteCallbacks: Map<string, (quote: Quote) => void> = new Map();

  constructor(credentials: DhanCredentials) {
    this.accessToken = credentials.accessToken;
    this.clientId = credentials.clientId;
  }

  async authenticate(credentials: DhanCredentials): Promise<any> {
    // In production: validate token with Dhan API
    return { success: true, token: credentials.accessToken };
  }

  async refreshToken(): Promise<void> {
    // Dhan tokens typically don't need refresh - long-lived
  }

  // Market Data Methods

  async subscribe(symbols: string[], mode: 'ltp' | 'quote' | 'depth' = 'ltp'): Promise<void> {
    if (!this.wsConnection?.readyState === WebSocket.OPEN) {
      this.connectWebSocket();
    }

    symbols.forEach(symbol => {
      const message = JSON.stringify({
        action: 'subscribe',
        mode: mode,
        symboltoken: symbols, // Dhan uses symbol token
        exchange: 'NSE'
      });
      this.wsConnection?.send(message);
      this.pendingSubscriptions.set(symbol, () => {
        this.unsubscribe([symbol]);
      });
    });
  }

  async unsubscribe(symbols: string[]): Promise<void> {
    if (this.wsConnection?.readyState === WebSocket.OPEN) {
      symbols.forEach(symbol => {
        const message = JSON.stringify({
          action: 'unsubscribe',
          symboltoken: symbols,
          exchange: 'NSE'
        });
        this.wsConnection?.send(message);
      });
    }
    symbols.forEach(symbol => this.pendingSubscriptions.delete(symbol));
  }

  async getQuote(symbol: string): Promise<Quote> {
    // Fetch quote via REST API
    const response = await fetch(`${DHAN_BASE_URL}/quote?symbol=${symbol}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return this.mapDhanQuote(data);
  }

  async getDepth(symbol: string): Promise<MarketDepth> {
    // Fetch market depth via REST API
    const response = await fetch(`${DHAN_BASE_URL}/depth?symbol=${symbol}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return this.mapDhanDepth(data);
  }

  async getOHLC(symbol: string, timeframe: string = '1d'): Promise<any[]> {
    const response = await fetch(`${DHAN_BASE_URL}/ohlc?symbol=${symbol}&timeframe=${timeframe}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.data || [];
  }

  // Order Methods

  async placeOrder(order: OrderRequest): Promise<OrderResponse> {
    const dhanOrder: DhanOrderRequest = {
      variety: order.variety || 'BO',
      symbol: order.symbol,
      transactionType: order.side === 'BUY' ? DhanTransactionType.BUY : DhanTransactionType.SELL,
      exchangeToken: order.exchangeToken || '',
      exchangeName: order.exchange || 'NSE',
      orderType: order.orderType || 'MARKET',
      product: order.productType || DhanProduct.CNC,
      quantity: order.quantity,
      price: order.price,
      triggerPrice: order.triggerPrice,
      validity: order.validity || DhanValidity.DAY,
      disclosedQuantity: order.disclosedQuantity
    };

    const response = await fetch(`${DHAN_BASE_URL}/order/place`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dhanOrder)
    });

    const data = await response.json();
    return this.mapDhanOrderResponse(data);
  }

  async modifyOrder(orderId: string, modifications: any): Promise<void> {
    await fetch(`${DHAN_BASE_URL}/order/modify`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        orderId,
        ...modifications
      })
    });
  }

  async cancelOrder(orderId: string): Promise<void> {
    await fetch(`${DHAN_BASE_URL}/order/cancel`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ orderId })
    });
  }

  async getOrders(filters?: any): Promise<Order[]> {
    const url = filters ? `${DHAN_BASE_URL}/order/list?${new URLSearchParams(filters)}` : `${DHAN_BASE_URL}/order/list`;
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.orders || [];
  }

  async getTrades(dateRange: any): Promise<any[]> {
    const response = await fetch(`${DHAN_BASE_URL}/trades?from=${dateRange.from}&to=${dateRange.to}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.trades || [];
  }

  // Portfolio Methods

  async getPositions(): Promise<Position[]> {
    const response = await fetch(`${DHAN_BASE_URL}/position`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json;
    return data.positions || [];
  }

  async getHoldings(): Promise<any[]> {
    const response = await fetch(`${DHAN_BASE_URL}/holding`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.holdings || [];
  }

  async getFunds(): Promise<any> {
    const response = await fetch(`${DHAN_BASE_URL}/funds`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data;
  }

  // WebSocket Events

  on(event: string, handler: Function): void {
    // Subscribe to WebSocket events
    if (event === 'quote') {
      this.wsConnection?.addEventListener('message', (event: MessageEvent) => {
        const data = JSON.parse(event.data);
        if (data.action === 'quote' && data.symbol) {
          const quote = this.mapDhanQuote(data);
          this.quoteCallbacks.get(data.symbol)?.(quote);
        }
      });
    }
  }

  off(event: string, handler: Function): void {
    // Unsubscribe from events
  }

  // Private Methods

  private connectWebSocket(): void {
    this.wsConnection = new WebSocket(`${DHAN_WS_URL}/market-data?access-token=${this.accessToken}`);

    this.wsConnection?.addEventListener('open', () => {
      console.log('Dhan WebSocket connected');
    });

    this.wsConnection?.addEventListener('message', (event: MessageEvent) => {
      const data = JSON.parse(event.data);
      if (data.type === 'quote' && data.symbol) {
        const quote = this.mapDhanQuote(data);
        this.quoteCallbacks.get(data.symbol)?.(quote);
      }
    });

    this.wsConnection?.addEventListener('close', () => {
      console.log('Dhan WebSocket disconnected');
      // Attempt reconnection
      setTimeout(() => this.connectWebSocket(), 5000);
    });
  }

  private mapDhanQuote(data: any): Quote {
    return {
      symbol: data.symbol || '',
      ltp: data.ltp || 0,
      change: data.change || 0,
      changePercent: data.changePercent || 0,
      volume: data.volume || 0,
      open: data.open || 0,
      high: data.high || 0,
      low: data.low || 0,
      close: data.close || 0,
      timestamp: data.timestamp || Date.now(),
      oi: data.oi || 0
    };
  }

  private mapDhanDepth(data: any): MarketDepth {
    const levels = data.bids || data.asks || [];
    const bids = levels.map((level: any) => ({
      price: level.price,
      quantity: level.quantity
    }));
    const asks = levels.map((level: any) => ({
      price: level.price,
      quantity: level.quantity
    }));

    return {
      symbol: data.symbol || '',
      bids,
      asks,
      lastTradedPrice: data.lastTradedPrice || 0,
      totalBuyQuantity: data.totalBuyQuantity || 0,
      totalSellQuantity: data.totalSellQuantity || 0
    };
  }

  private mapDhanOrderResponse(data: any): OrderResponse {
    return {
      orderId: data.orderId || data.id || '',
      status: data.status || 'pending',
      averagePrice: data.averagePrice || data.price || 0,
      executedQuantity: data.executedQuantity || data.quantityFilled || 0,
      totalQuantity: data.totalQuantity || data.quantityOriginal || 0,
      timestamp: data.timestamp || new Date().toISOString()
    };
  }
}