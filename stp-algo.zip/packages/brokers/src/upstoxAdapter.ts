/**
 * Upstox Broker Adapter
 * Unified interface for Upstox broker API
 */

import { BrokerAdapter, Quote, OrderRequest, OrderResponse, Position, MarketDepth } from '../api/types';

// Upstox specific API endpoints and types
const UPSTOX_BASE_URL = 'https://api.upstox.com';
const UPSTOX_WS_URL = 'https://realtime.upstox.com';

// Upstox order types
enum UpstoxOrderType {
  BUY = 'BUY',
  SELL = 'SELL',
  BUY_TO_COVER = 'BUY_TO_COVER',
  SELL_TO_CLOSE = 'SELL_TO_CLOSE',
}

// Upstox product types
enum UpstoxProduct {
  CNC = 'CNC',
  MIS = 'MIS',
  CO = 'CO',
  BO = 'BO',
}

// Upstox validity types
enum UpstoxValidity {
  DAY = 'DAY',
  IOC = 'IOC',
  TTL = 'TTL',
}

// Upstox transaction types
enum UpstoxTransactionType {
  BUY = 'BUY',
  SELL = 'SELL',
}

// Interface for Upstox credentials
export interface UpstoxCredentials {
  accessToken: string;
  clientId: string;
}

// Interface for Upstox order request
export interface UpstoxOrderRequest {
  transaction_type: UpstoxTransactionType;
  instrument_token: string;
  symbol: string;
  exchange_token: string;
  exchange: 'NSE' | 'NFO' | 'BSE' | 'BFO';
  order_type: 'MARKET' | 'LIMIT' | 'SL' | 'SL-M';
  product: UpstoxProduct;
  quantity: number;
  price?: number;
  trigger_price?: number;
  validity: UpstoxValidity;
  discloseqty?: number;
}

// Interface for Upstox order response
export interface UpstoxOrderResponse {
  order_id: string;
  status: string;
  status_message: string;
  average_price?: number;
  executed_quantity?: number;
  quantity?: number;
  timestamp: string;
}

// Interface for Upstox quote
export interface UpstoxQuote {
  symbol: string;
  ltp: number;
  change: number;
  change_percent: number;
  volume: number;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  oi: number;
}

// Interface for Upstox market depth
export interface UpstoxMarketDepth {
  symbol: string;
  bids: UpstoxDepthLevel[];
  asks: UpstoxDepthLevel[];
  last_traded_price: number;
  total_buy_quantity: number;
  total_sell_quantity: number;
}

export interface UpstoxDepthLevel {
  price: number;
  quantity: number;
}

// Implementation of the BrokerAdapter for Upstox
export class UpstoxAdapter implements BrokerAdapter {
  private accessToken: string;
  private clientId: string;
  private wsConnection: WebSocket | null = null;
  private pendingSubscriptions: Map<string, () => void> = new Map();
  private quoteCallbacks: Map<string, (quote: Quote) => void> = new Map();

  constructor(credentials: UpstoxCredentials) {
    this.accessToken = credentials.accessToken;
    this.clientId = credentials.clientId;
  }

  async authenticate(credentials: UpstoxCredentials): Promise<any> {
    // In production: validate token with Upstox API
    return { success: true, token: credentials.accessToken };
  }

  async refreshToken(): Promise<void> {
    // Upstox token refresh logic
  }

  // Market Data Methods

  async subscribe(symbols: string[], mode: 'ltp' | 'quote' | 'depth' = 'ltp'): Promise<void> {
    if (!this.wsConnection?.readyState === WebSocket.OPEN) {
      this.connectWebSocket();
    }

    symbols.forEach(symbol => {
      const message = JSON.stringify({
        action: 'subscribe',
        mode: mode,
        instrument_token: symbols.join(','),
        exchange: 'NSE'
      });
      this.wsConnection?.send(message);
      this.pendingSubscriptions.set(symbol, () => {
        this.unsubscribe([symbol]);
      });
    });
  }

  async unsubscribe(symbols: string[]): Promise<void> {
    if (this.wsConnection?.readyState === WebSocket.OPEN) {
      symbols.forEach(symbol => {
        const message = JSON.stringify({
          action: 'unsubscribe',
          instrument_token: symbols.join(','),
          exchange: 'NSE'
        });
        this.wsConnection?.send(message);
      });
    }
    symbols.forEach(symbol => this.pendingSubscriptions.delete(symbol));
  }

  async getQuote(symbol: string): Promise<Quote> {
    const response = await fetch(`${UPSTOX_BASE_URL}/quote/${symbol}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return this.mapUpstoxQuote(data);
  }

  async getDepth(symbol: string): Promise<MarketDepth> {
    const response = await fetch(`${UPSTOX_BASE_URL}/depth/${symbol}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return this.mapUpstoxDepth(data);
  }

  async getOHLC(symbol: string, timeframe: string = '1d'): Promise<any[]> {
    const response = await fetch(`${UPSTOX_BASE_URL}/ohlc?symbol=${symbol}&timeframe=${timeframe}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.data || [];
  }

  // Order Methods

  async placeOrder(order: OrderRequest): Promise<OrderResponse> {
    const upstoxOrder = {
      transaction_type: order.side === 'BUY' ? 'BUY' : 'SELL',
      instrument_token: order.exchangeToken || '',
      symbol: order.symbol,
      exchange_token: order.exchangeToken || '',
      exchange: order.exchange || 'NSE',
      order_type: order.orderType || 'MARKET',
      product: order.productType || UpstoxProduct.CNC,
      quantity: order.quantity,
      price: order.price,
      trigger_price: order.triggerPrice,
      validity: order.validity || UpstoxValidity.DAY,
      discloseqty: order.disclosedQuantity
    };

    const response = await fetch(`${UPSTOX_BASE_URL}/order/place`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(upstoxOrder)
    });

    const data = await response.json();
    return this.mapUpstoxOrderResponse(data);
  }

  async modifyOrder(orderId: string, modifications: any): Promise<void> {
    await fetch(`${UPSTOX_BASE_URL}/order/modify`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        order_id: orderId,
        ...modifications
      })
    });
  }

  async cancelOrder(orderId: string): Promise<void> {
    await fetch(`${UPSTOX_BASE_URL}/order/cancel`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ order_id: orderId })
    });
  }

  async getOrders(filters?: any): Promise<Order[]> {
    const url = filters ? `${UPSTOX_BASE_URL}/order/list?${new URLSearchParams(filters)}` : `${UPSTOX_BASE_URL}/order/list`;
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.orders || [];
  }

  async getTrades(dateRange: any): Promise<any[]> {
    const response = await fetch(`${UPSTOX_BASE_URL}/trades?from=${dateRange.from}&to=${dateRange.to}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.trades || [];
  }

  // Portfolio Methods

  async getPositions(): Promise<Position[]> {
    const response = await fetch(`${UPSTOX_BASE_URL}/position`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.positions || [];
  }

  async getHoldings(): Promise<any[]> {
    const response = await fetch(`${UPSTOX_BASE_URL}/holding`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data.holdings || [];
  }

  async getFunds(): Promise<any> {
    const response = await fetch(`${UPSTOX_BASE_URL}/funds`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json'
      }
    });
    const data = await response.json();
    return data;
  }

  // WebSocket Events

  on(event: string, handler: Function): void {
    if (event === 'quote') {
      this.wsConnection?.addEventListener('message', (event: MessageEvent) => {
        const data = JSON.parse(event.data);
        if (data.action === 'quote' && data.instrument_token) {
          const quote = this.mapUpstoxQuote(data);
          this.quoteCallbacks.get(data.instrument_token)?.(quote);
        }
      });
    }
  }

  off(event: string, handler: Function): void {}

  // Private Methods

  private connectWebSocket(): void {
    this.wsConnection = new WebSocket(`${UPSTOX_WS_URL}/?mode=full&instrument_token=`);

    this.wsConnection?.addEventListener('open', () => {
      console.log('Upstox WebSocket connected');
    });

    this.wsConnection?.addEventListener('message', (event: MessageEvent) => {
      const data = JSON.parse(event.data);
      if (data.type === 'quote' && data.instrument_token) {
        const quote = this.mapUpstoxQuote(data);
        this.quoteCallbacks.get(data.instrument_token)?.(quote);
      }
    });

    this.wsConnection?.addEventListener('close', () => {
      console.log('Upstox WebSocket disconnected');
      setTimeout(() => this.connectWebSocket(), 5000);
    });
  }

  private mapUpstoxQuote(data: any): Quote {
    return {
      symbol: data.symbol || data.instrument_token || '',
      ltp: data.last_price || data.ltp || 0,
      change: data.net_change || data.change || 0,
      changePercent: data.net_change_percent || data.change_percent || 0,
      volume: data.total_traded_quantity || data.volume || 0,
      open: data.open_price || data.open || 0,
      high: data.high_price || data.high || 0,
      low: data.low_price || data.low || 0,
      close: data.close_price || data.close || 0,
      timestamp: data.timestamp || Date.now(),
      oi: data.oi || 0
    };
  }

  private mapUpstoxDepth(data: any): MarketDepth {
    const bids = (data.bid_prices || []).map((level: any, i: number) => ({
      price: level.price,
      quantity: level.quantity
    }));
    const asks = (data.ask_prices || []).map((level: any, i: number) => ({
      price: level.price,
      quantity: level.quantity
    }));

    return {
      symbol: data.symbol || '',
      bids,
      asks,
      lastTradedPrice: data.last_traded_price || data.lastPrice || 0,
      totalBuyQuantity: data.total_buy_quantity || data.totalBuyQuantity || 0,
      totalSellQuantity: data.total_sell_quantity || data.totalSellQuantity || 0
    };
  }

  private mapUpstoxOrderResponse(data: any): OrderResponse {
    return {
      orderId: data.order_id || data.id || '',
      status: data.status || 'pending',
      averagePrice: data.average_price || data.averagePrice || 0,
      executedQuantity: data.executed_quantity || data.executedQuantity || 0,
      totalQuantity: data.quantity || data.totalQuantity || 0,
      timestamp: data.timestamp || new Date().toISOString()
    };
  }
}