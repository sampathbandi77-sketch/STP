/**
 * Core Trading Engine - Market Data Service
 * WebSocket-based real-time market data from 3 brokers
 */

import { Quote, MarketDepth, QuoteService } from '../api/types';
import { DhanAdapter } from '../brokers/dhanAdapter';
import { UpstoxAdapter } from '../brokers/upstoxAdapter';
import { CoinSwitchAdapter } from '../brokers/coinswitchAdapter';
import { TechnicalIndicators as BaseIndicators } from '../ai/signals';

export interface MarketDataService {
  subscribeQuotes(symbols: string[], callback: (quotes: Quote[]) => void): void;
  unsubscribeQuotes(symbols: string[]): void;
  getQuote(symbol: string): Promise<Quote>;
  getQuotes(symbols: string[]): Promise<Quote[]>;
  getDepth(symbol: string): Promise<MarketDepth>;
  getOHLC(symbol: string, timeframe: string): Promise<any[]>;
  getRealTimeData(): Promise<{ symbol: string; ltp: number; change: number; volume: number }[]>;
}

export class MarketDataServiceImpl implements MarketDataService {
  private dhanAdapter: DhanAdapter;
  private upstoxAdapter: UpstoxAdapter;
  private coinswitchAdapter: CoinSwitchAdapter;
  private quoteSubscriptions: Map<string, ((quotes: Quote[]) => void)[]> = new Map();
  private isSubscribed: boolean = false;

  constructor(
    dhanAdapter: DhanAdapter,
    upstoxAdapter: UpstoxAdapter,
    coinswitchAdapter: CoinSwitchAdapter
  ) {
    this.dhanAdapter = dhanAdapter;
    this.upstoxAdapter = upstoxAdapter;
    this.coinswitchAdapter = coinswitchAdapter;
  }

  // Quote Subscription Methods

  subscribeQuotes(symbols: string[], callback: (quotes: Quote[]) => void): void {
    // Subscribe via all adapters
    this.dhanAdapter.subscribe(symbols, 'ltp');
    this.upstoxAdapter.subscribe(symbols, 'ltp');
    this.coinswitchAdapter.subscribe(symbols, 'ltp');

    // Store subscription callback
    if (!this.quoteSubscriptions.has(symbols[0])) {
      this.quoteSubscriptions.set(symbols[0], []);
    }
    const callbacks = this.quoteSubscriptions.get(symbols[0])!;
    if (!callbacks.includes(callback)) {
      callbacks.push(callback);
    }

    // Set up WebSocket listeners for each adapter
    this.dhanAdapter.on('quote', (quote: any) => {
      this.broadcastQuote(quote.symbol, quote);
    });

    this.upstoxAdapter.on('quote', (quote: any) => {
      this.broadcastQuote(quote.symbol || quote.instrument_token, quote);
    });

    this.coinswitchAdapter.on('quote', (quote: any) => {
      this.broadcastQuote(quote.symbol, quote);
    });

    this.isSubscribed = true;
  }

  unsubscribeQuotes(symbols: string[]): void {
    this.dhanAdapter.unsubscribe(symbols);
    this.upstoxAdapter.unsubscribe(symbols);
    this.coinswitchAdapter.unsubscribe(symbols);

    // Remove stored callbacks
    symbols.forEach(symbol => {
      this.quoteSubscriptions.delete(symbol);
    });

    this.isSubscribed = this.quoteSubscriptions.size > 0;
  }

  // Quote Retrieval Methods

  async getQuote(symbol: string): Promise<Quote> {
    // Try each adapter and return first success
    try {
      return await this.dhanAdapter.getQuote(symbol);
    } catch {
      try {
        return await this.upstoxAdapter.getQuote(symbol);
      } catch {
        return await this.coinswitchAdapter.getQuote(symbol);
      }
    }
  }

  async getQuotes(symbols: string[]): Promise<Quote[]> {
    const promises = symbols.map(symbol => this.getQuote(symbol));
    return Promise.all(promises);
  }

  // Market Depth

  async getDepth(symbol: string): Promise<MarketDepth> {
    // Try each adapter
    try {
      return await this.dhanAdapter.getDepth(symbol);
    } catch {
      try {
        return await this.upstoxAdapter.getDepth(symbol);
      } catch {
        return await this.coinswitchAdapter.getDepth(symbol);
      }
    }
  }

  // OHLC Data

  async getOHLC(symbol: string, timeframe: string = '1d'): Promise<any[]> {
    try {
      return await this.dhanAdapter.getOHLC(symbol, timeframe);
    } catch {
      try {
        return await this.upstoxAdapter.getOHLC(symbol, timeframe);
      } catch {
        return await this.coinswitchAdapter.getOHLC(symbol, timeframe);
      }
    }
  }

  // Real-time Data Batch

  async getRealTimeData(): Promise<{ symbol: string; ltp: number; change: number; volume: number }[]> {
    const quotes = await this.getQuotes(['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY']);
    return quotes.map(q => ({
      symbol: q.symbol,
      ltp: q.ltp,
      change: q.change,
      volume: q.volume
    }));
  }

  // Private Helper Methods

  private broadcastQuote(symbol: string, quoteData: any): void {
    const callbacks = this.quoteSubscriptions.get(symbol);
    if (callbacks && callbacks.length > 0) {
      const quote: Quote = {
        symbol,
        ltp: quoteData.ltp || quoteData.last_price || 0,
        change: quoteData.change || quoteData.net_change || 0,
        changePercent: quoteData.changePercent || quoteData.net_change_percent || 0,
        volume: quoteData.volume || quoteData.total_traded_quantity || 0,
        open: quoteData.open || 0,
        high: quoteData.high || 0,
        low: quoteData.low || 0,
        close: quoteData.close || 0,
        timestamp: quoteData.timestamp || Date.now(),
        oi: quoteData.oi || 0
      };

      callbacks.forEach(callback => {
        try {
          callback([quote]);
        } catch (e) {
          console.error(`Error in quote callback for ${symbol}:`, e);
        }
      });
    }
  }
}