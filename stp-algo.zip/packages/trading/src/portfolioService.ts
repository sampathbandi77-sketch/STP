/**
 * Core Trading Engine - Portfolio & Position Service
 * Holdings, positions, P&L calculation, risk metrics
 */

import { Position, Holding, Quote, MarketDepth } from '../api/types';
import { DhanAdapter } from '../brokers/dhanAdapter';
import { UpstoxAdapter } from '../brokers/upstoxAdapter';
import { CoinSwitchAdapter } from '../brokers/coinswitchAdapter';
import { TechnicalIndicators as BaseIndicators } from '../ai/signals';

export interface PortfolioService {
  getPositions(): Promise<Position[]>;
  getHoldings(): Promise<Holding[]>;
  getFunds(): Promise<any>;
  calculatePnL(symbol: string): { today: number; todayPercent: number; unrealized: number; realized: number };
  getRiskMetrics(): { var95: number; var99: maxDrawdown: number; exposure: number; marginUsed: number };
  updatePrices(quotes: Quote[]): void;
}

export class PortfolioServiceImpl implements PortfolioService {
  private dhanAdapter: DhanAdapter;
  private upstoxAdapter: UpstoxAdapter;
  private coinswitchAdapter: CoinSwitchAdapter;
  private priceCache: Map<string, number> = new Map();
  private positions: Position[] = [];
  private holdings: Holding[] = [];

  constructor(
    dhanAdapter: DhanAdapter,
    upstoxAdapter: UpstoxAdapter,
    coinswitchAdapter: CoinSwitchAdapter
  ) {
    this.dhanAdapter = dhanAdapter;
    this.upstoxAdapter = upstoxAdapter;
    this.coinswitchAdapter = coinswitchAdapter;
  }

  // Position Retrieval

  async getPositions(): Promise<Position[]> {
    try {
      const dhanPositions = await this.dhanAdapter.getPositions();
      this.positions = dhanPositions;
      return dhanPositions;
    } catch {
      try {
        const upstoxPositions = await this.upstoxAdapter.getPositions();
        this.positions = upstoxPositions;
        return upstoxPositions;
      } catch {
        const coinswitchPositions = await this.coinswitchAdapter.getPositions();
        this.positions = coinswitchPositions;
        return coinswitchPositions;
      }
    }
  }

  async getHoldings(): Promise<Holding[]> {
    try {
      const dhanHoldings = await this.dhanAdapter.getHoldings();
      this.holdings = dhanHoldings;
      return dhanHoldings;
    } catch {
      try {
        const upstoxHoldings = await this.upstoxAdapter.getHoldings();
        this.holdings = upstoxHoldings;
        return upstoxHoldings;
      } catch {
        const coinswitchHoldings = await this.coinswitchAdapter.getHoldings();
        this.holdings = coinswitchHoldings;
        return coinswitchHoldings;
      }
    }
  }

  // Funds Retrieval

  async getFunds(): Promise<any> {
    try {
      return await this.dhanAdapter.getFunds();
    } catch {
      try {
        return await this.upstoxAdapter.getFunds();
      } catch {
        return await this.coinswitchAdapter.getFunds();
      }
    }
  }

  // P&L Calculation

  calculatePnL(symbol: string): { today: number; todayPercent: number; unrealized: number; realized: number } {
    const position = this.positions.find(p => p.symbol === symbol);
    if (!position) {
      return { today: 0, todayPercent: 0, unrealized: 0, realized: 0 };
    }

    const currentPrice = this.priceCache.get(symbol) || position.currentPrice;
    const previousPrice = position.averagePrice;
    const change = currentPrice - previousPrice;
    const changePercent = (change / previousPrice) * 100;

    const unrealizedPnL = (currentPrice - previousPrice) * position.quantity;
    const todayPnL = unrealizedPnL; // For simplicity, today = unrealized
    const todayPnLPercent = changePercent;
    const realizedPnL = 0; // Would need trade history

    return {
      today: Math.round(todayPnL * 100) / 100,
      todayPercent: Math.round(todayPnLPercent * 100) / 100,
      unrealized: Math.round(unrealizedPnL * 100) / 100,
      realized: Math.round(realizedPnL * 100) / 100,
    };
  }

  // Risk Metrics

  getRiskMetrics(): {
    var95: number;
    var99: number;
    maxDrawdown: number;
    exposure: number;
    marginUsed: number;
    dailyPnL: number;
  } {
    // Calculate based on positions and current prices
    const totalExposure = this.positions.reduce((sum, pos) => {
      return sum + (pos.currentPrice * pos.quantity);
    }, 0);

    // Calculate VaR using historical simulation
    const dailyReturns = this.calculateDailyReturns();
    const sortedReturns = [...dailyReturns].sort((a, b) => a - b);

    const var95Index = Math.floor(sortedReturns.length * 0.05);
    const var99Index = Math.floor(sortedReturns.length * 0.01);

    const var95 = Math.abs(sortedReturns[var95Index] * totalExposure);
    const var99 = Math.abs(sortedReturns[var99Index] * totalExposure);

    // Max drawdown calculation
    const peakToTrough = this.calculateMaxDrawdown();

    // Total margin used (rough estimate)
    const marginUsed = this.positions.reduce((sum, pos) => {
      // Rough: 50% of position value for margin
      return sum + (pos.currentPrice * pos.quantity * 0.5);
    }, 0);

    // Daily P&L
    const dailyPnL = this.positions.reduce((sum, pos) => {
      const currentPrice = this.priceCache.get(pos.symbol) || pos.currentPrice;
      const pnl = (currentPrice - pos.averagePrice) * pos.quantity;
      return sum + pnl;
    }, 0);

    return {
      var95: Math.round(var95 * 100) / 100,
      var99: Math.round(var99 * 100) / 100,
      maxDrawdown: Math.round(peakToTrough * 100) / 100,
      exposure: Math.round(totalExposure * 100) / 100,
      marginUsed: Math.round(marginUsed * 100) / 100,
      dailyPnL: Math.round(dailyPnL * 100) / 100,
    };
  }

  // Private Helper Methods

  private calculateDailyReturns(): number[] {
    const returns: number[] = [];
    const positions = this.positions;

    // Get historical price changes (mock for now)
    for (let i = 0; i < Math.min(positions.length, 30); i++) {
      const pos = positions[i];
      const currentPrice = this.priceCache.get(pos.symbol) || pos.currentPrice;
      const prevPrice = pos.averagePrice;
      const returnPct = (currentPrice - prevPrice) / prevPrice;
      returns.push(returnPct);
    }

    // If not enough data, generate realistic mock returns
    if (returns.length < 5) {
      return Array.from({ length: 30 }, () => (Math.random() - 0.5) * 0.03);
    }

    return returns;
  }

  private calculateMaxDrawdown(): number {
    // Simple mock calculation
    // In production: track equity curve over time
    return Math.max(-0.1, -Math.random() * 0.2); // -10% to -20% max drawdown
  }

  // Price Update Handler

  updatePrices(quotes: Quote[]): void {
    quotes.forEach(quote => {
      this.priceCache.set(quote.symbol, quote.ltp);
    });

    // Recalculate any dependent metrics
    // This would trigger UI updates in a real app
  }
}