/**
 * Core Trading Engine - Order Management Service
 * Unified order placement, modification, and cancellation across 3 brokers
 */

import { OrderRequest, OrderResponse, OrderSide, OrderType, OrderValidity } from '../api/types';
import { DhanAdapter } from '../brokers/dhanAdapter';
import { UpstoxAdapter } from '../brokers/upstoxAdapter';
import { CoinSwitchAdapter } from '../brokers/coinswitchAdapter';
import { toast } from '@sampath/ui';

export interface OrderManagementService {
  placeOrder(order: OrderRequest): Promise<OrderResponse>;
  modifyOrder(orderId: string, modifications: any): Promise<void>;
  cancelOrder(orderId: string): Promise<void>;
  getOrders(filters?: any): Promise<any[]>;
  getOrderStatus(orderId: string): Promise<any>;
  getTradeHistory(filters?: any): Promise<any[]>;
}

export class OrderManagementServiceImpl implements OrderManagementService {
  private dhanAdapter: DhanAdapter;
  private upstoxAdapter: UpstoxAdapter;
  private coinswitchAdapter: CoinSwitchAdapter;
  private orderHistory: Map<string, OrderResponse> = new Map();

  constructor(
    dhanAdapter: DhanAdapter,
    upstoxAdapter: UpstoxAdapter,
    coinswitchAdapter: CoinSwitchAdapter
  ) {
    this.dhanAdapter = dhanAdapter;
    this.upstoxAdapter = upstoxAdapter;
    this.coinswitchAdapter = coinswitchAdapter;
  }

  // Order Placement

  async placeOrder(order: OrderRequest): Promise<OrderResponse> {
    // Validate order before placement
    if (!this.validateOrder(order)) {
      throw new Error('Invalid order parameters');
    }

    // Try each broker adapter
    const brokers = [
      { name: 'dhan', adapter: this.dhanAdapter },
      { name: 'upstox', adapter: this.upstoxAdapter },
      { name: 'coinswitch', adapter: this.coinswitchAdapter },
    ];

    for (const broker of brokers) {
      try {
        const response = await broker.adapter.placeOrder(order);

        // Store in order history
        this.orderHistory.set(response.orderId, response);

        // Show success toast
        toast({ title: `Order placed via ${broker.name}` });

        return response;
      } catch (error: any) {
        // Log error but continue to next broker
        console.error(`Order failed via ${broker.name}:`, error.message);
        continue;
      }
    }

    // If all brokers failed
    throw new Error('All broker order placements failed. Please check connections.');
  }

  // Order Modification

  async modifyOrder(orderId: string, modifications: any): Promise<void> {
    const brokers = [
      { name: 'dhan', adapter: this.dhanAdapter },
      { name: 'upstox', adapter: this.upstoxAdapter },
      { name: 'coinswitch', adapter: this.coinswitchAdapter },
    ];

    for (const broker of brokers) {
      try {
        await broker.adapter.modifyOrder(orderId, modifications);
        toast({ title: `Order ${orderId} modified via ${broker.name}` });
        return;
      } catch (error: any) {
        console.error(`Modify failed via ${broker.name}:`, error.message);
        continue;
      }
    }

    throw new Error('Failed to modify order across all brokers');
  }

  // Order Cancellation

  async cancelOrder(orderId: string): Promise<void> {
    const brokers = [
      { name: 'dhan', adapter: this.dhanAdapter },
      { name: 'upstox', adapter: this.upstoxAdapter },
      { name: 'coinswitch', adapter: this.coinswitchAdapter },
    ];

    for (const broker of brokers) {
      try {
        await broker.adapter.cancelOrder(orderId);
        // Remove from order history
        this.orderHistory.delete(orderId);
        toast({ title: `Order ${orderId} cancelled` });
        return;
      } catch (error: any) {
        console.error(`Cancel failed via ${broker.name}:`, error.message);
        continue;
      }
    }

    throw new Error('Failed to cancel order across all brokers');
  }

  // Order Retrieval

  async getOrders(filters?: any): Promise<any[]> {
    // Try dhan first (most comprehensive)
    try {
      const orders = await this.dhanAdapter.getOrders(filters);
      return orders;
    } catch {
      // Fallback to upstox
      try {
        return await this.upstoxAdapter.getOrders(filters);
      } catch {
        return await this.coinswitchAdapter.getOrders(filters);
      }
    }
  }

  async getOrderStatus(orderId: string): Promise<any> {
    // Check order history first
    const historical = this.orderHistory.get(orderId);
    if (historical) {
      return historical;
    }

    // Fetch from broker
    const brokers = ['dhan', 'upstox', 'coinswitch'];
    for (const broker of brokers) {
      try {
        // Note: adapters don't have getOrderStatus directly, use getOrders
        const orders = await this.getOrders({ orderId });
        if (orders && orders.length > 0) {
          return orders[0];
        }
      } catch {
        continue;
      }
    }

    return { orderId, status: 'unknown' };
  }

  // Trade History

  async getTradeHistory(filters?: any): Promise<any[]> {
    // Get all orders and extract trades
    const orders = await this.getOrders(filters);

    // Extract trades from orders
    const trades = orders.flatMap(order => {
      // In production, would fetch actual trade tickets
      // For now, return order as trade with status
      return {
        orderId: order.orderId,
        symbol: order.symbol,
        side: order.side,
        quantity: order.executedQuantity || 0,
        price: order.averagePrice || 0,
        timestamp: order.timestamp,
        status: order.status,
      };
    });

    return trades;
  }

  // Order Validation

  private validateOrder(order: OrderRequest): boolean {
    // Validate required fields
    if (!order.symbol) return false;
    if (!order.side || (order.side !== 'BUY' && order.side !== 'SELL')) return false;
    if (!order.quantity || order.quantity <= 0) return false;
    if (!order.orderType) return false;

    // Validate quantity is reasonable
    if (order.quantity > 100000) {
      console.warn('Order quantity exceeds typical limit');
    }

    // Validate price for limit orders
    if (order.orderType === 'LIMIT' && (!order.price || order.price <= 0)) {
      console.error('Limit order requires valid price');
      return false;
    }

    return true;
  }
}