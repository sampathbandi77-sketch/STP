/**
 * STP Algorithm Engine - Core Orchestration
 * STP (Sampath Tanvi Prathyusha) Algorithmic Trading Engine
 * Combines scanner, signals, risk, and execution
 */

import { Observable, interval, of, BehaviorSubject, combineLatest, from } from 'rxjs';
import { map, switchMap, mergeMap, filter, take, takeUntil, timeout } from 'rxjs/operators';
import { Quote, MarketDepth } from '../api/types';
import { MarketDataService } from '../trading/marketData';
import { ScannerEngine, ScanConfig, ScanResult, defaultScanConfigs } from '../scanner/scanEngine';
import { OrderManagementService } from '../trading/orderManagement';
import { PortfolioService } from '../trading/portfolioService';
import { ProfitProtectionEngine, ProfitProtectionConfig, ProtectionStatus } from './profitProtectionEngine';
import { AlertSystem, AlertConfig } from './alertSystem';
import { StpConfig, DEFAULT_STP_CONFIG, getConfig } from './config';

export interface StpEngineState {
  isRunning: boolean;
  isScanning: boolean;
  lastSignal: any | null;
  activePositions: number;
  totalCapitalAtRisk: number;
  maxDrawdownHit: boolean;
  tradingPaused: boolean;
  lastScan: Date | null;
  nextScanAt: Date;
  config: StpConfig;
}

export class StpEngine {
  private config: StpConfig;
  private marketDataService: MarketDataService;
  private orderManagement: OrderManagementService;
  private portfolioService: PortfolioService;
  private protectionEngine: ProfitProtectionEngine;
  private alertSystem: AlertSystem;
  private stateSubject = new BehaviorSubject<StpEngineState>({
    isRunning: false,
    isScanning: false,
    lastSignal: null,
    activePositions: 0,
    totalCapitalAtRisk: 0,
    maxDrawdownHit: false,
    tradingPaused: false,
    lastScan: null,
    nextScanAt: new Date(),
    config: DEFAULT_STP_CONFIG,
  });
  private shutdown$ = new Subject<boolean>();

  constructor(
    marketDataService: MarketDataService,
    orderManagement: OrderManagementService,
    portfolioService: PortfolioService,
    config: StpConfig = DEFAULT_STP_CONFIG
  ) {
    this.config = config;
    this.marketDataService = marketDataService;
    this.orderManagement = orderManagement;
    this.portfolioService = portfolioService;
    this.protectionEngine = new (await import('./profitProtectionEngine')).ProfitProtectionEngine(
      marketDataService,
      orderManagement,
      portfolioService,
      this.config
    );
    this.alertSystem = new (await import('./alertSystem')).AlertSystemImpl(this.config.alertSystem);
  }

  // Start the STP Engine
  start(): void {
    if (this.stateSubject.value.isRunning) return;

    this.stateSubject.next({
      ...this.stateSubject.value,
      isRunning: true,
      config: this.config,
    });

    // Start protection system
    this.protectionEngine.start();

    // Set up scanning interval
    const scanInterval = interval(this.config.scanInterval);

    scanInterval.pipe(
      takeUntil(this.shutdown$),
      filter(() => !this.stateSubject.value.isPaused),
      mergeMap(() => this._runScanCycle()),
      timeout(30000)
    ).subscribe({
      next: (result) => this._handleScanResult(result),
      error: (err) => {
        console.error('STP Scan cycle error:', err);
        this._handleScanError(err);
      }
    });

    this.stateSubject.next({
      ...this.stateSubject.value,
      isScanning: true,
      nextScanAt: new Date(Date.now() + this.config.scanInterval),
    });

    console.log('STP Engine started with config:', this.config.name);
  }

  // Stop the STP Engine
  stop(): void {
    this.stateSubject.next({
      ...this.stateSubject.value,
      isRunning: false,
      isScanning: false,
    });
    this.shutdown$.next(true);
    this.protectionEngine.stop();
    console.log('STP Engine stopped');
  }

  // Toggle pause/resume
  togglePause(): void {
    const current = this.stateSubject.value;
    this.stateSubject.next({
      ...current,
      tradingPaused: !current.tradingPaused,
    });
    this.protectionEngine.togglePause();
  }

  // Get current state
  getState(): Observable<StpEngineState> {
    return this.stateSubject.asObservable();
  }

  // _runScanCycle: Execute one complete scan cycle
  private _runScanCycle(): Observable<{
    signal: any;
    protectionStatus: any;
    shouldExecute: boolean;
  }> {
    return combineLatest([
      this._getMarketData(),
      this.protectionEngine['getScanHistory']?.() || of([]),
    ]).pipe(
      map(([quotes, scanHistory]) => this._analyzeMarket(quotes, scanHistory)),
      mergeMap(analysis => this._applyRiskChecks(analysis)),
    );
  }

  // _getMarketData: Fetch current quotes for scanning
  private _getMarketData(): Observable<Record<string, Quote>> {
    const symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY'];
    const quoteObservables = symbols.map(symbol =>
      this.marketDataService.getQuote(symbol)
    );

    return combineLatest(quoteObservables).pipe(
      map(quotes => {
        const result: Record<string, Quote> = {};
        symbols.forEach((symbol, i) => {
          result[symbol] = quotes[i];
        });
        return result;
      })
    );
  }

  // _analyzeMarket: Full market analysis with signals
  private _analyzeMarket(quotes: Record<string, Quote>, scanHistory: any[]): {
    signal: any;
    score: number;
    rationale: string;
  } {
    const symbol = 'RELIANCE'; // In production, iterate through all symbols
    const quote = quotes[symbol];

    if (!quote) {
      return { signal: null, score: 0, rationale: 'No quote data' };
    }

    // 1. Run scanner filters
    const scanEngine = new (await import('../scanner/scanEngine')).ScannerEngine;
    const activeFilters = this._getActiveFilters();
    const scanResult = scanEngine.scanSymbol(symbol, activeFilters);

    // 2. Calculate signal score
    let score = 50; // Base score
    let rationale = 'Market scan in progress';

    if (scanResult) {
      score = scanResult.score;
      const matchedFilters = scanResult.matchedFilters || [];
      rationale = `Matched ${matchedFilters.length} filters: ${matchedFilters.join(', ')}`;
    }

    // 3. Apply protection filters
    const currentPosition = this.portfolioService.positions?.find(
      (p: any) => p.symbol === symbol
    );

    // 4. Determine action
    let action: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';

    if (!currentPosition && scanResult?.score >= this.config.confidenceThreshold) {
      action = 'BUY' as const;
      rationale = `Strong buy signal: ${scanResult.description}`;
    } else if (currentPosition && scanResult?.signalType === 'SELL') {
      action = 'SELL' as const;
      rationale = `Sell signal for existing position`;
    } else if (currentPosition && scanResult?.score >= 70) {
      action = 'HOLD' as const;
      rationale = `Hold position, signal confirms`;
    } else {
      rationale = `Insufficient confidence (${scanResult?.score}%) or signal conflict`;
    }

    return {
      signal: {
        id: `stp_${symbol}_${Date.now()}`,
        symbol,
        signalType: action,
        confidence: scanResult?.score || 50,
        priceTarget: scanResult?.priceTarget,
        stopLoss: scanResult?.stopLoss,
        timeHorizon: 'MEDIUM',
        model: 'STP-Ensemble',
        features: scanResult?.indicatorValues ? Object.keys(scanResult.indicatorValues).filter(k => isNumber(scanResult.indicatorValues[k])) : [],
        generatedAt: new Date(),
        description: rationale,
      },
      score,
      rationale,
    };
  }

  // _applyRiskChecks: Apply risk management filters
  private _applyRiskChecks(analysis: { signal: any; score: number; rationale: string }): {
    signal: any;
    shouldExecute: boolean;
    riskCheck: any;
  } {
    const { signal, score, rationale } = analysis;
    const symbol = signal?.symbol || 'RELIANCE';

    // Check 1: Drawdown circuit breaker
    const drawdownCheck = this.protectionEngine['_checkDrawdownLimit']?.();
    if (!drawdownCheck?.withinLimit) {
      return {
        signal,
        shouldExecute: false,
        riskCheck: { type: 'drawdown', message: 'Max drawdown exceeded' },
      };
    }

    // Check 2: Position limit
    const positionCheck = this.protectionEngine['_checkPositionLimit']?.(symbol);
    if (!positionCheck?.withinLimit) {
      return {
        signal,
        shouldExecute: false,
        riskCheck: { type: 'positionLimit', message: 'Position limit exceeded' },
      };
    }

    // Check 3: Margin availability
    const marginCheck = this.protectionEngine['_checkMarginAvailable']?.(symbol);
    if (!marginCheck?.sufficient) {
      return {
        signal,
        shouldExecute: false,
        riskCheck: { type: 'margin', message: 'Insufficient margin' },
      };
    }

    // Check 4: Existing position logic
    const currentPosition = this.portfolioService.positions?.find(
      (p: any) => p.symbol === symbol
    );

    if (currentPosition && currentPosition.quantity !== 0 && signal.signalType === 'BUY') {
      return {
        signal,
        shouldExecute: false,
        riskCheck: { type: 'existingLong', message: 'Already long this symbol' },
      };
    }

    if (currentPosition && currentPosition.quantity !== 0 && signal.signalType === 'SELL') {
      return {
        signal,
        shouldExecute: true,
        riskCheck: { type: 'existingShort', message: 'Exit existing position' },
      };
    }

    return {
      signal,
      shouldExecute: true,
      riskCheck: { type: 'passed', message: 'All checks passed' },
    };
  }

  // _getActiveFilters: Get active scan filters from config
  private _getActiveFilters(): ScanFilter[] {
    // Return filters based on config
    return [
      { id: 'filter_rsi_oversold', name: 'RSI Oversold', description: 'RSI below 30', type: 'technical', operator: 'lt', value: 30, field: 'rsi' },
      { id: 'filter_volume_spike', name: 'Volume Spike', description: 'Volume above average', type: 'volume', operator: 'gte', value: 1.5, field: 'volume' },
    ];
  }

  // _handleScanResult: Process scan results
  private _handleScanResult(result: any): void {
    const signal = result?.signal;
    if (!signal) return;

    const { symbol } = signal;

    // Update state with new signal
    this.stateSubject.next({
      ...this.stateSubject.value,
      lastSignal: signal,
      activePositions: this.portfolioService.positions?.length || 0,
      lastScan: new Date(),
      nextScanAt: new Date(Date.now() + this.config.scanInterval),
    });

    // Trigger alert if signal is strong
    if (signal.confidence >= this.config.confidenceThreshold) {
      this.alertSystem.triggerAISignal(symbol, {
        symbol,
        signalType: signal.signalType,
        confidence: signal.confidence,
        priceTarget: signal.priceTarget,
        stopLoss: signal.stopLoss,
        description: signal.description,
        timestamp: Date.now(),
      });
    }

    // Auto-execute if configured and risk checks pass
    if (this.config.autoExecute && signal.confidence >= this.config.confidenceThreshold) {
      this._autoExecuteSignal(signal);
    }
  }

  // _autoExecuteSignal: Auto-place protective orders
  private _autoExecuteSignal(signal: any): void {
    const { symbol, signalType, confidence, priceTarget, stopLoss } = signal;

    // Determine order side
    const side: 'BUY' | 'SELL' = signalType === 'BUY' ? 'BUY' : 'SELL';

    // Calculate quantity based on risk
    const capitalAtRiskPct = 2; // 2% of capital per trade
    const entryPrice = signal.ltp || 0;
    const riskPerShare = Math.abs(entryPrice - (stopLoss || entryPrice));
    const totalCapital = 1000000; // Would query actual portfolio
    const capitalAtRisk = totalCapital * (capitalAtRiskPct / 100);
    const quantity = Math.max(1, Math.floor(capitalAtRisk / riskPerShare));

    // Build order request
    const orderRequest = {
      symbol,
      side,
      quantity,
      orderType: 'SL-M' as const,
      productType: 'MIS' as const,
      validity: 'DAY' as const,
      disclosedQuantity: 0,
      triggerPrice: stopLoss,
    };

    // Place order through order management
    // In production: this.orderManagement.placeOrder(orderRequest)
    console.log(`STP Auto-Execute: ${side} ${symbol} ${quantity} shares at ₹${entryPrice}`);
    console.log(`  SL: ₹${stopLoss}  Target: ₹${priceTarget}`);

    // Show notification
    // toast({ title: `STP Auto-Trade: ${side} ${symbol}`, description: `Qty: ${qty}` });
  }

  // _handleScanError: Handle scan errors
  private _handleScanError(err: any): void {
    console.error('STP Scan error:', err);
    this.stateSubject.next({
      ...this.stateSubject.value,
      isScanning: false,
    });
    // toast({ title: 'STP Scan Error', variant: 'destructive' });
  }
}

// Helper type guard
function isNumber(value: any): boolean {
  return typeof value === 'number' && !isNaN(value);
}

// Export default engine class
export default StpEngine;

// Export types for external use
export type { StpEngineState, StpConfig };