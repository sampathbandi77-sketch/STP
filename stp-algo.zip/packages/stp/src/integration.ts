/**
 * STP Integration Module
 * Connects STP Engine to SAMPATH PRO MAX ecosystem
 * Bridges algorithm engine with brokers, UI, and data flows
 */

import { StpEngine, StpEngineState, StpConfig, DEFAULT_STP_CONFIG } from './index';
import { MarketDataService } from '../trading/marketData';
import { OrderManagementService } from '../trading/orderManagement';
import { PortfolioService } from '../trading/portfolioService';
import { AlertSystem, AlertConfig } from './alertSystem';
import { QuoteService } from '../api/quotes';

// STP Integration Manager
export class StpIntegration {
  private engine: StpEngine;
  private config: StpConfig;
  private isInitialized = false;

  // Initialize STP with all dependencies
  init(
    marketDataService: MarketDataService,
    orderManagement: OrderManagementService,
    portfolioService: PortfolioService,
    config: StpConfig = DEFAULT_STP_CONFIG
  ): void {
    // Don't re-initialize if already set up
    if (this.isInitialized) return;

    this.config = config;
    this.engine = new StpEngine(
      marketDataService,
      orderManagement,
      portfolioService,
      config
    );

    // Subscribe to engine state changes
    this.engine.getState().subscribe(state => {
      this._onEngineStateChange(state);
    });

    // Initialize alert system
    const alertConfig: AlertConfig = {
      priceAlerts: config.enablePriceAlerts,
      aiSignalAlerts: config.enableSignalAlerts,
      smartMoneyAlerts: config.enableSmartMoneyAlerts,
      volumeAlerts: true,
      trailingStopAlerts: true,
      breachAlerts: true,
      sound: true,
      desktopNotifications: true,
    };
    this.engine['alertSystem']?.['init']?.(alertConfig);

    this.isInitialized = true;
    console.log('STP Integration initialized for', config.name);
  }

  // Get current engine state
  getState(): Observable<StpEngineState> {
    return this.engine?.getState() || of({
      isRunning: false,
      isScanning: false,
      lastSignal: null,
      activePositions: 0,
      totalCapitalAtRisk: 0,
      maxDrawdownHit: false,
      tradingPaused: false,
      lastScan: null,
      nextScanAt: new Date(),
      config: this.config,
    });
  }

  // Public API methods
  toggleEngine(): void {
    if (this.engine?.isRunning()) {
      this.engine.stop();
    } else {
      this.engine.start();
    }
  }

  pauseEngine(): void {
    this.engine?.togglePause();
  }

  // Execute signal for a specific symbol
  executeSignal(symbol: string): void {
    // In production: would trigger scan for specific symbol
    console.log(`STP Signal execution requested for ${symbol}`);
  }

  // Get recommended action for symbol
  getRecommendation(symbol: string): {
    action: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    priceTarget?: number;
    stopLoss?: number;
  } {
    // In production: would run scanner for specific symbol
    return {
      action: 'HOLD',
      confidence: 50,
    };
  }

  // Emergency stop
  emergencyStop(): void {
    this.engine?.stop();
    this.engine['protectionEngine']?['stopTracking']?.();
    console.log('STP Emergency stop activated');
  }

  // Reset all states
  reset(): void {
    this.engine?.stop();
    this.isInitialized = false;
    console.log('STP Integration reset');
  }

  // Check if STP is healthy
  isHealthy(): boolean {
    return this.isInitialized && this.engine?.isRunning() === true;
  }

  // Get configuration summary
  getConfigSummary(): {
    name: string;
    version: string;
    isRunning: boolean;
    isScanning: boolean;
    activePositions: number;
    maxPositions: number;
    confidenceThreshold: number;
  } {
    const config = this.config || DEFAULT_STP_CONFIG;
    return {
      name: config.name,
      version: config.version,
      isRunning: this.engine?.isRunning() ?? false,
      isScanning: this.engine?.isRunning() ?? false,
      activePositions: this.engine?.['stateSubject']?.value?.activePositions ?? 0,
      maxPositions: config.maxPositionsOpen || 5,
      confidenceThreshold: config.confidenceThreshold ?? 70,
    };
  }
}

// Export default integration class
export default StpIntegration;