/**
 * STP - Sampath Tanvi Prathyusha Algorithm Trading Engine
 * Main entry point - re-exports all core modules
 */

// Core Engine
export { StpEngine, StpEngineState, DEFAULT_STP_CONFIG } from './engine';
export { getConfig } from './config';

// Configuration
export type { StpConfig } from './config';
export { DEFAULT_STP_CONFIG };

// Integration
export { default as StpIntegration } from './integration';
export { StpIntegration };

// Scanner and Signals (re-exported from sub-packages)
export type { ScanResult, ScanFilter } from '../scanner/scanEngine';
export type { OrderResponse, OrderRequest } from '../api/types';

// Engine State Management
export { BehaviorSubject, Subject, interval, combineLatest } from 'rxjs';

// Export default for easy importing
export default StpEngine;