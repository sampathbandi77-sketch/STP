/**
 * STP Algorithm Configuration
 * Central configuration for STP (Sampath Tanvi Prathyusha) trading engine
 */

export interface StpConfig {
  // Algorithm Settings
  name: string;
  version: string;
  description: string;

  // Trading Parameters
  maxPositionSize: number;        // Max % capital per position
  maxDrawdownCutoff: number;     // % drawdown to halt trading
  maxPositionsOpen: number;      // Max concurrent positions
  defaultRiskReward: number;     // Risk:Reward ratio (e.g., 1:2)

  // Risk Management
  maxDailyLoss: number;          // Daily loss limit %
  maxDrawdownRecovery: number;   // Max % to resume after drawdown
  minVolumeThreshold: number;    // Min avg volume for entries
  maxSlippagePercent: number;    // Max acceptable slippage

  // Timeframe Settings
  primaryTimeframe: '1Min' | '5Min' | '15Min' | '1H' | '1D';
  scanInterval: number;          // ms between scans
  signalLookback: number;        // Bars for indicator calculation

  // Broker Configuration
  preferredBroker: 'dhan' | 'upstox' | 'coinswitch' | 'auto';
  fallbackBroker: 'dhan' | 'upstox' | 'coinswitch';
  apiTimeout: number;            // ms before timeout
  retryAttempts: number;         // Number of retry attempts
  retryDelay: number;            // ms between retries

  // AI/ML Settings
  modelUpdateInterval: number;   // ms between model retraining
  confidenceThreshold: number;   // Min confidence score (0-100)
  ensembleWeight: number;        // Weight for each model in ensemble

  // Alert Settings
  enablePriceAlerts: boolean;
  enableSignalAlerts: boolean;
  enableSmartMoneyAlerts: boolean;
  alertChannels: ('websocket' | 'email' | 'push')[];
}

// Default Configuration
export const DEFAULT_STP_CONFIG: StpConfig = {
  name: 'STP',
  version: '1.0.0',
  description: 'Sampath Tanvi Prathyusha Algorithmic Trading Engine',

  // Trading Parameters
  maxPositionSize: 20,           // 20% max capital per position
  maxDrawdownCutoff: 15,         // 15% drawdown halts trading
  maxPositionsOpen: 5,           // Max 5 concurrent positions
  defaultRiskReward: 2,          // 1:2 Risk:Reward

  // Risk Management
  maxDailyLoss: 5,               // 5% daily loss limit
  maxDrawdownRecovery: 3,        // Resume after 3% recovery
  minVolumeThreshold: 500000,    // Min 5L avg volume
  maxSlippagePercent: 0.5,       // 0.5% max slippage

  // Timeframe Settings
  primaryTimeframe: '1D',
  scanInterval: 30000,           // 30 second scans
  signalLookback: 100,           // 100 bars for indicators

  // Broker Configuration
  preferredBroker: 'auto',
  fallbackBroker: 'dhan',
  apiTimeout: 10000,
  retryAttempts: 3,
  retryDelay: 2000,

  // AI/ML Settings
  modelUpdateInterval: 604800000, // Weekly (7 days)
  confidenceThreshold: 70,       // 70% min confidence
  ensembleWeight: 0.33,          // Equal weight for 3 models

  // Alert Settings
  enablePriceAlerts: true,
  enableSignalAlerts: true,
  enableSmartMoneyAlerts: true,
  alertChannels: ['websocket'],
} as const;

// Export config type from values
export type StpConfigKey = keyof typeof DEFAULT_STP_CONFIG;

// Helper to get config by key
export function getConfig(key: StpConfigKey): typeof DEFAULT_STP_CONFIG[StpConfigKey] {
  return DEFAULT_STP_CONFIG[key];
}

export type { StpConfig };