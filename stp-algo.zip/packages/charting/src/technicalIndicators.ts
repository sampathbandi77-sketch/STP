/**
 * Technical Indicators for Lightweight Charts
 * Ported from the ai package indicators with Lightweight Charts integration
 */

import { TechnicalIndicators as BaseIndicators } from '../ai/signals';

// Export the same indicators but adapted for chart data
export class ChartTechnicalIndicators {
  // SMA for chart data
  static calculateSMA(prices: number[], period: number): number[] {
    return BaseIndicators.SMA(prices, period);
  }

  // EMA for chart data
  static calculateEMA(prices: number[], period: number): number[] {
    return BaseIndicators.EMA(prices, period);
  }

  // RSI for chart data
  static calculateRSI(prices: number[], period: number = 14): { rsi: number[], overbought: number[], oversold: number[] } {
    return BaseIndicators.RSI(prices, period);
  }

  // MACD for chart data
  static calculateMACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
    return BaseIndicators.MACD(prices, fastPeriod, slowPeriod, signalPeriod);
  }

  // Bollinger Bands for chart data
  static calculateBB(prices: number[], period: number = 20, numStdDev: number = 2) {
    return BaseIndicators.BB(prices, period, numStdDev);
  }
}

// Helper to extract prices from chart candle data
export const extractPrices = (candles: { close: number }[]): number[] => {
  return candles.map(c => c.close);
};

// Helper to extract timestamps from chart data
export const extractTimestamps = (candles: { time: number }[]): number[] => {
  return candles.map(c => c.time);
};

// Convert Lightweight Charts data to price array
export const convertToPriceArray = (seriesData: any): number[] => {
  if (!seriesData || seriesData.length === 0) return [];

  // Handle different data formats from Lightweight Charts
  if (Array.isArray(seriesData)) {
    return seriesData.map(d => {
      if (typeof d === 'object' && d.close !== undefined) return d.close;
      if (typeof d === 'number') return d;
      return 0;
    });
  }

  return [];
};