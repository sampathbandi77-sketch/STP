/**
 * Lightweight Charts Integration
 * TradingView Lightweight Charts wrapper for SAMPATH PRO MAX
 */

import { Chart, Series, TimeScaleMargins } from 'lightweight-charts';

// Chart configuration based on SAMPATH PRO MAX design tokens
export const chartOptions = {
  layout: {
    backgroundColor: '#05080C', // bg-deep
    textColor: '#E8ECF1', // text-primary
  },
  grid: {
    vertLines: '#1E2A3A', // chart-grid
    horzLines: '#1E2A3A', // chart-grid
  },
  rightPriceScale: {
    borderColor: '#2A3A4A', // border-default
    textColor: '#A8B3C0', // text-secondary
    visible: true,
  },
  timeScale: {
    borderColor: '#2A3A4A', // border-default
    textColor: '#A8B3C0', // text-secondary
    mode: 'bilateral' as const,
    timeVisible: true,
    secondsVisible: false,
    scaleMargins: {
      top: 0.1,
      bottom: 0.1,
    },
  },
  crosshair: {
    mode: 'stealth' as const,
    color: '#3B82F6', // chart-crosshair
    verticalLineVisible: true,
    horizontalLineVisible: true,
  },
  watermark: {
    logo: '',
    color: 'rgba(255,255,255,0.05)',
  },
};

// Series type colors matching design system
export const seriesColors = {
  default: '#3B82F6', // blue-info
  up: '#00D47E', // green-profit
  down: '#FF4757', // red-loss
  volumeUp: '#00D47E', // green-profit
  volumeDown: '#FF4757', // red-loss
};

// Chart timeframes
export const timeframes = {
  minute: '1Min',
  '5-minute': '5Min',
  fifteen: '15Min',
  hour: '1H',
  '2-hour': '2H',
  '8-hour': '8H',
  day: '1D',
  '3-day': '3D',
  week: '1W',
  month: '1M',
};

// Technical indicators overlay colors
export const indicatorColors = {
  ma9: '#3B82F6', // blue-info
  ma20: '#F59E0B', // amber-warn
  ma50: '#A855F7', // purple-ai
  ma200: '#FF4757', // red-loss
  bollingerUpper: 'rgba(59,130,246,0.2)', // blue-info with opacity
  bollingerLower: 'rgba(59,130,246,0.2)', // blue-info with opacity
  bollingerMiddle: 'rgba(59,130,246,0.1)', // blue-info with opacity
  rsi: '#F59E0B', // amber-warn
  macd: '#3B82F6', // blue-info
  histogram: 'rgba(59,130,246,0.4)',
};

// Export chart creation function
export function createChart(container: HTMLElement, data: { time: number; price: number }[]): Chart {
  const chart = new Chart(container, {
    width: container.clientWidth,
    height: 400,
    localization: {
      copyButtonCopyLabel: 'Copy',
      copyButtonTooltip: 'Copy data',
      downloadButtonTooltip: 'Download',
      downloadFilename: 'chart',
    },
    layout: chartOptions.layout,
    grid: chartOptions.grid,
    rightPriceScale: chartOptions.rightPriceScale,
    timeScale: chartOptions.timeScale,
    crosshair: chartOptions.crosshair,
    watermark: chartOptions.watermark,
  });

  // Add price series
  const series = chart.addLineSeries({
    color: seriesColors.default,
    lineWidth: 2,
    axisLabelVisible: true,
    title: 'Price',
  });

  // Update series with data
  series.setData(data);

  // Configure time scale
  chart.applyOptions({
    timeScale: chartOptions.timeScale,
  });

  return chart;
}

// Add moving average series
export function addMovingAverage(
  chart: Chart,
  data: { time: number; price: number }[],
  period: number,
  color: string,
  title: string
) {
  const series = chart.addLineSeries({
    color,
    lineWidth: 2,
    title,
    axisLabelVisible: true,
  });

  // Calculate SMA
  const prices = data.map(d => d.price);
  const sma = TechnicalIndicators.SMA(prices, period);

  const smaData = data.map((d, i) => ({
    time: d.time,
    price: sma[i] || d.price,
  }));

  series.setData(smaData);
  return series;
}

// Add Bollinger Bands
export function addBollingerBands(
  chart: Chart,
  data: { time: number; price: number }[],
  period: number = 20,
  stdDev: number = 2
) {
  const prices = data.map(d => d.price);
  const { middleBand, upperBand, lowerBand } = TechnicalIndicators.BB(prices, period, stdDev);

  // Middle band (SMA)
  const middleSeries = chart.addLineSeries({
    color: indicatorColors.ma50,
    lineWidth: 1,
    lineStyle: 2, // dashed
    title: 'MA',
    axisLabelVisible: true,
  });

  middleSeries.setData(data.map((d, i) => ({
    time: d.time,
    price: middleBand[i] || d.price,
  })));

  // Upper band
  const upperSeries = chart.addLineSeries({
    color: indicatorColors.bollingerUpper,
    lineWidth: 1,
    lineStyle: 2, // dashed
    title: 'Upper BB',
    axisLabelVisible: true,
    lastValue: false,
  });

  upperSeries.setData(data.map((d, i) => ({
    time: d.time,
    price: upperBand[i] || d.price,
  })));

  // Lower band
  const lowerSeries = chart.addLineSeries({
    color: indicatorColors.bollingerLower,
    lineWidth: 1,
    lineStyle: 2, // dashed
    title: 'Lower BB',
    axisLabelVisible: true,
    lastValue: false,
  });

  lowerSeries.setData(data.map((d, i) => ({
    time: d.time,
    price: lowerBand[i] || d.price,
  })));

  return { middleSeries, upperSeries, lowerSeries };
}

// Add RSI indicator below chart
export function addRSI(
  chart: Chart,
  data: { time: number; price: number }[],
  rsiData: number[],
  container: HTMLElement
) {
  const rsiChart = new Chart(container, {
    width: container.clientWidth,
    height: 150,
    layout: {
      ...chartOptions.layout,
      backgroundColor: '#0A0F16', // bg-elevated
    },
    grid: {
      vertLines: '#1E2A3A',
      horzLines: '#1E2A3A',
    },
    rightPriceScale: {
      borderColor: '#2A3A4A',
      textColor: '#A8B3C0',
      visible: true,
    },
    timeScale: {
      ...chartOptions.timeScale,
      mode: 'bilateral',
    },
    crosshair: {
      mode: 'stealth',
    },
  });

  const rsiSeries = rsiChart.addLineSeries({
    color: indicatorColors.rsi,
    lineWidth: 2,
    title: 'RSI',
    axisLabelVisible: true,
  });

  rsiSeries.setData(data.map((d, i) => ({
    time: d.time,
    price: rsiData[i] || 50,
  })));

  // Add 30 and 70 levels
  rsiChart.addLabel(0, 30, '30', {
    color: '#FF4757',
    fontSize: 10,
    fontWeight: 500,
  });

  rsiChart.addLabel(0, 70, '70', {
    color: '#00D47E',
    fontSize: 10,
    fontWeight: 500,
  });

  // Add overbought/oversold background
  const priceScale = rsiChart.priceScale();
  if (priceScale) {
    priceSet = priceSet || priceScale.setBackgroundColor;
    // Background between 30-70 is transparent, outside is shaded
  }

  return rsiChart;
}

// Technical indicators helper
export class TechnicalIndicators {
  static SMA(prices: number[], period: number): number[] {
    const results: number[] = [];
    if (prices.length < period) {
      return prices.map(() => 0);
    }
    for (let i = 0; i < prices.length; i++) {
      if (i < period - 1) {
        results.push(0);
      } else {
        const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        results.push(sum / period);
      }
    }
    return results;
  }

  static EMA(prices: number[], period: number): number[] {
    if (prices.length < period) {
      return prices.map(() => 0);
    }
    const multiplier = 2 / (period + 1);
    const results: number[] = [];
    const sma = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
    results.push(sma);
    for (let i = period; i < prices.length; i++) {
      results.push((prices[i] - results[results.length - 1]) * multiplier + results[results.length - 1]);
    }
    return results;
  }

  static RSI(prices: number[], period: number = 14): number[] {
    if (prices.length < period + 1) {
      return prices.map(() => 50);
    }
    const changes: number[] = [];
    for (let i = 1; i < prices.length; i++) {
      changes.push(prices[i] - prices[i - 1]);
    }
    const gains: number[] = changes.map(c => Math.max(c, 0));
    const losses: number[] = changes.map(c => Math.min(c, 0) * -1);
    const avgGain: number[] = [gains.slice(0, period).reduce((a, b) => a + b, 0) / period];
    const avgLoss: number[] = [losses.slice(0, period).reduce((a, b) => a + b, 0) / period];
    const rsi: number[] = [50];
    for (let i = 1; i < gains.length; i++) {
      const avgGainCurrent = (avgGain[avgGain.length - 1] * (period - 1) + gains[i]) / period;
      const avgLossCurrent = (avgLoss[avgLoss.length - 1] * (period - 1) + losses[i]) / period;
      const rs = avgLossCurrent === 0 ? 100 : avgGainCurrent / avgLossCurrent;
      const rsiValue = 100 - (100 / (1 + rs));
      rsi.push(rsiValue);
      avgGain.push(avgGainCurrent);
      avgLoss.push(avgLossCurrent);
    }
    return rsi;
  }

  static MACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
    const fastEMA = this.EMA(prices, fastPeriod);
    const slowEMA = this.EMA(prices, slowPeriod);
    const macdLine: number[] = [];
    for (let i = 0; i < prices.length; i++) {
      if (i < slowPeriod + fastPeriod) {
        macdLine.push(0);
      } else {
        macdLine.push(fastEMA[i] - slowEMA[i - slowPeriod + fastPeriod]);
      }
    }
    const signalLine = this.EMA(macdLine, signalPeriod);
    const histogram: number[] = [];
    for (let i = 0; i < macdLine.length; i++) {
      histogram.push(macdLine[i] - signalLine[i]);
    }
    return { macdLine, signalLine, histogram };
  }

  static BB(prices: number[], period: number = 20, numStdDev: number = 2) {
    const middleBand: number[] = [];
    const upperBand: number[] = [];
    const lowerBand: number[] = [];
    for (let i = 0; i < prices.length; i++) {
      if (i < period - 1) {
        middleBand.push(0);
        upperBand.push(0);
        lowerBand.push(0);
      } else {
        const slice = prices.slice(i - period + 1, i + 1);
        const mean = slice.reduce((a, b) => a + b, 0) / period;
        const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period;
        const stdDev = Math.sqrt(variance);
        middleBand.push(mean);
        upperBand.push(mean + (numStdDev * stdDev));
        lowerBand.push(mean - (numStdDev * stdDev));
      }
    }
    return { middleBand, upperBand, lowerBand };
  }
}

// Chart event handlers
export enum ChartEvent {
  CLICK = 'click',
  MOUSE_MOVE = 'mousemove',
  MOUSE_OUT = 'mouseout',
  ZOOM = 'zoom',
  SCROLL = 'scroll',
}

export interface ChartClickEvent {
  price: number;
  time: number;
  seriesIndex: number;
  elementType: 'main' | 'overlay' | 'price-axis' | 'time-axis';
}

export interface ChartZoomEvent {
  timeStart: number;
  timeEnd: number;
  priceStart: number;
  priceEnd: number;
  scaleFactor: number;
}

// Add vertical line annotation
export function addVerticalLine(
  chart: Chart,
  time: number,
  color: string = '#3B82F6',
  label: string = ''
) {
  const priceScale = chart.priceScale();
  const timeScale = chart.timeScale();

  if (!priceScale || !timeScale) return;

  const bottom = priceScale.bottom();
  const top = priceScale.top();

  const formatter = timeScale.formatter();

  const line = chart.drawLine({
    points: [
      { time, price: bottom },
      { time, price: top },
    ],
    color,
    lineWidth: 1,
    axisAligned: true,
  });

  if (label) {
    chart.insertShape('text', {
      position: { time, price: top - 15 },
      text: label,
      color: color,
      fontSize: 10,
      align: 'center',
    });
  }

  return line;
}

// Add horizontal line annotation
export function addHorizontalLine(
  chart: Chart,
  price: number,
  color: string = '#FF4757',
  label: string = ''
) {
  const priceScale = chart.priceScale();

  if (!priceScale) return;

  const line = chart.drawLine({
    points: [
      { time: priceScale.left(), price },
      { time: priceScale.right(), price },
    ],
    color,
    lineWidth: 1,
    axisAligned: false,
  });

  if (label) {
    const formatter = chart.timeScale().formatter();
    const time = priceScale.left();
    chart.insertShape('text', {
      position: { time, price: price + 10 },
      text: label,
      color: color,
      fontSize: 10,
    });
  }

  return line;
}

// Subscription types for chart events
export type ChartSubscription = {
  onClick: (event: ChartClickEvent) => void;
  onMouseMove: (event: ChartClickEvent) => void;
  onZoom: (event: ChartZoomEvent) => void;
  onScroll: () => void;
};