/**
 * API - Quote Service
 * Fetches real-time quotes from broker adapters
 */

import { Quote } from '../types';
import { DhanAdapter } from '../brokers/dhanAdapter';
import { UpstoxAdapter } from '../brokers/upstoxAdapter';
import { CoinSwitchAdapter } from '../brokers/coinswitchAdapter';
import { BrokerName } from '../types';

export interface QuoteService {
  getQuote(symbol: string, broker?: BrokerName): Promise<Quote>;
  getQuotes(symbols: string[], broker?: BrokerName): Promise<Quote[]>;
  subscribeQuote(symbol: string, callback: (quote: Quote) => void, broker?: BrokerName): void;
  unsubscribeQuote(symbol: string, broker?: BrokerName): void;
}

export class QuoteServiceImpl implements QuoteService {
  private dhanAdapter: DhanAdapter;
  private upstoxAdapter: UpstoxAdapter;
  private coinswitchAdapter: CoinSwitchAdapter;
  private subscriptions: Map<string, { callback: (quote: Quote) => void; broker: BrokerName }> = new Map();

  constructor(
    dhanAdapter: DhanAdapter,
    upstoxAdapter: UpstoxAdapter,
    coinswitchAdapter: CoinSwitchAdapter
  ) {
    this.dhanAdapter = dhanAdapter;
    this.upstoxAdapter = upstoxAdapter;
    this.coinswitchAdapter = coinswitchAdapter;
  }

  async getQuote(symbol: string, broker?: BrokerName): Promise<Quote> {
    broker = broker || 'dhan'; // Default to dhan

    switch (broker) {
      case 'dhan':
        return this.dhanAdapter.getQuote(symbol);
      case 'upstox':
        return this.upstoxAdapter.getQuote(symbol);
      case 'coinswitch':
        return this.coinswitchAdapter.getQuote(symbol);
      default:
        // Try all adapters and return first success
        try {
          return await this.dhanAdapter.getQuote(symbol);
        } catch {
          try {
            return await this.upstoxAdapter.getQuote(symbol);
          } catch {
            return await this.coinswitchAdapter.getQuote(symbol);
          }
        }
      }
    }
  }

  async getQuotes(symbols: string[], broker?: BrokerName): Promise<Quote[]> {
    const promises = symbols.map(symbol => this.getQuote(symbol, broker));
    return Promise.all(promises);
  }

  subscribeQuote(symbol: string, callback: (quote: Quote) => void, broker?: BrokerName): void {
    broker = broker || 'dhan';

    // Subscribe via the appropriate adapter
    switch (broker) {
      case 'dhan':
        this.dhanAdapter.on('quote', (quote: any) => {
          if (quote.symbol === symbol) {
            callback(quote);
          }
        });
        break;
      case 'upstox':
        this.upstoxAdapter.on('quote', (quote: any) => {
          if (quote.symbol === symbol || quote.instrument_token === symbol) {
            callback(quote);
          }
        });
        break;
      case 'coinswitch':
        this.coinswitchAdapter.on('quote', (quote: any) => {
          if (quote.symbol === symbol) {
            callback(quote);
          }
        });
        break;
    }

    // Store subscription for unsubscription
    this.subscriptions.set(symbol, { callback, broker });
  }

  unsubscribeQuote(symbol: string, broker?: BrokerName): void {
    broker = broker || 'dhan';

    // Remove from subscriptions
    this.subscriptions.delete(symbol);

    // Unsubscribe via the appropriate adapter
    switch (broker) {
      case 'dhan':
        // Dhan handles unsubscription internally
        break;
      case 'upstox':
        // Upstox handles unsubscription internally
        break;
      case 'coinswitch':
        // CoinSwitch handles unsubscription internally
        break;
    }
  }
}