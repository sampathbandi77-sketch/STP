/**
 * Shared Types for SAMPATH PRO MAX
 */

// Broker names
export type BrokerName = 'dhan' | 'upstox' | 'coinswitch';

// Broker credentials interfaces
export interface DhanCredentials {
  accessToken: string;
  clientId: string;
  uid: string;
}

export interface UpstoxCredentials {
  accessToken: string;
  clientId: string;
}

export interface CoinSwitchCredentials {
  apiKey: string;
  secretKey: string;
  passphrase: string;
}

// Order side
export type OrderSide = 'BUY' | 'SELL';

// Order types
export type OrderType = 'MARKET' | 'LIMIT' | 'SL' | 'SL-M';

// Order validity
export type OrderValidity = 'DAY' | 'IOC' | 'TTL';

// Order request interface
export interface OrderRequest {
  symbol: string;
  side: OrderSide;
  quantity: number;
  price?: number;
  orderType?: OrderType;
  productType?: 'CNC' | 'MIS' | 'CO' | 'BO';
  variety?: 'BO' | 'CO' | 'NOPE';
  disclosedQuantity?: number;
  triggerPrice?: number;
  validity?: OrderValidity;
}

// Order response interface
export interface OrderResponse {
  orderId: string;
  status: string;
  averagePrice?: number;
  executedQuantity?: number;
  totalQuantity?: number;
  timestamp: string;
}

// Quote interface
export interface Quote {
  symbol: string;
  ltp: number;
  change: number;
  changePercent: number;
  volume: number;
  open: number;
  high: number;
  low: number;
  close: number;
  timestamp: number;
  oi?: number;
}

// Market depth interface
export interface MarketDepth {
  symbol: string;
  bids: { price: number; quantity: number }[];
  asks: { price: number; quantity: number }[];
  lastTradedPrice: number;
  totalBuyQuantity: number;
  totalSellQuantity: number;
}

// Position interface
export interface Position {
  symbol: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  exchange: string;
  exchangeToken: string;
}

// Holding interface
export interface Holding {
  symbol: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  marketValue: number;
}

// Greeks interface
export interface Greeks {
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
}

// Option chain data
export interface OptionData {
  strike: number;
  ce?: {
    ltp: number;
    change: number;
    oi: number;
    volume: number;
    iv: number;
    bid: number;
    ask: number;
  };
  pe?: {
    ltp: number;
    change: number;
    oi: number;
    volume: number;
    iv: number;
    bid: number;
    ask: number;
  };
}

// Strategy types
export type StrategyType =
  | 'VERTICAL'
  | 'CALENDAR'
  | 'BUTTERFLY'
  | 'CONDORE'
  | 'STRADDLE'
  | 'STRANGLE'
  | 'IRON_CONDOR';

export interface Strategy {
  id: string;
  name: string;
  strategyType: StrategyType;
  underlying: string;
  entryDate: Date;
  exitDate?: Date;
  entryPrice: number;
  exitPrice?: number;
  premiumPaid: number;
  premiumReceived: number;
  maxProfit: number;
  maxLoss: number;
  probability: number;
  status: 'PENDING' | 'ACTIVE' | 'CLOSED' | 'EXPIRED';
}

// AI Signal
export interface AISignal {
  id: string;
  symbol: string;
  signalType: 'BUY' | 'SELL' | 'HOLD';
  confidence: number; // 0-100
  priceTarget: number;
  stopLoss: number;
  timeHorizon: 'SHORT' | 'MEDIUM' | 'LONG';
  model: string;
  features: string[];
  generatedAt: Date;
  description: string;
}

// Smart Money Flow
export interface SmartMoneyFlow {
  symbol: string;
  fiiBuy: number;
  fiiSell: number;
  diiBuy: number;
  diiSell: number;
  bulkDeals: number;
  blockDeals: number;
  totalValue: number;
  timestamp: number;
}

// UI State
export interface UIState {
  theme: 'dark' | 'light' | 'high-contrast';
  layout: 'dual' | 'single' | 'mobile';
  notifications: boolean;
  reducedMotion: boolean;
  watchlist: string[];
  selectedSymbols: string[];
}