/**
 * SAMPATH PRO MAX - Design Tokens
 * Single source of truth for all design decisions
 */

// ============================================================================
// COLOR SYSTEM
// ============================================================================

export const colors = {
  // Base - Deep Space
  bg: {
    deep: '#05080C',
    elevated: '#0A0F16',
    surface: '#101820',
    hover: '#161F2B',
    active: '#1B2838',
  },

  // Borders
  border: {
    subtle: '#1E2A3A',
    default: '#2A3A4A',
    strong: '#3A4D5D',
  },

  // Text Hierarchy
  text: {
    primary: '#E8ECF1',
    secondary: '#A8B3C0',
    muted: '#6B7A8A',
    inverse: '#05080C',
  },

  // Semantic - Trading
  green: {
    profit: '#00D47E',
    bright: '#00FF9D',
    dim: '#004D2E',
  },
  red: {
    loss: '#FF4757',
    bright: '#FF6B7A',
    dim: '#4D1A1F',
  },
  blue: {
    info: '#3B82F6',
    bright: '#60A5FA',
    dim: '#1E3A5F',
  },
  amber: {
    warn: '#F59E0B',
    bright: '#FBBF24',
    dim: '#4D3A0A',
  },
  purple: {
    ai: '#A855F7',
    bright: '#C084FC',
    dim: '#3A1F5A',
  },
  gold: {
    premium: '#F5C542',
  },

  // Chart-specific
  chart: {
    grid: '#1E2A3A',
    axis: '#4A5A6A',
    crosshair: '#3B82F6',
    volumeUp: '#00D47E',
    volumeDown: '#FF4757',
    ma9: '#3B82F6',
    ma20: '#F59E0B',
    ma50: '#A855F7',
    ma200: '#FF4757',
    vwap: '#00D47E',
  },
} as const;

// ============================================================================
// TYPOGRAPHY
// ============================================================================

export const typography = {
  fontFamily: {
    display: ['Space Grotesk', 'Inter', 'system-ui', 'sans-serif'],
    mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
    ui: ['Inter', 'system-ui', 'sans-serif'],
  },

  fontSize: {
    xs: 'clamp(0.625rem, 0.6rem + 0.125vw, 0.6875rem)',
    sm: 'clamp(0.75rem, 0.725rem + 0.125vw, 0.8125rem)',
    base: 'clamp(0.875rem, 0.85rem + 0.125vw, 0.9375rem)',
    lg: 'clamp(1rem, 0.975rem + 0.125vw, 1.0625rem)',
    xl: 'clamp(1.125rem, 1.1rem + 0.125vw, 1.1875rem)',
    '2xl': 'clamp(1.25rem, 1.2rem + 0.25vw, 1.375rem)',
    '3xl': 'clamp(1.5rem, 1.45rem + 0.25vw, 1.625rem)',
    '4xl': 'clamp(1.875rem, 1.8rem + 0.375vw, 2.125rem)',
    '5xl': 'clamp(2.25rem, 2.15rem + 0.5vw, 2.625rem)',
  },

  fontWeight: {
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
  },

  lineHeight: {
    tight: 1.1,
    snug: 1.375,
    normal: 1.5,
    relaxed: 1.625,
  },

  letterSpacing: {
    tight: '-0.02em',
    normal: '0',
    wide: '0.02em',
    wider: '0.04em',
    mono: '0.03em',
  },
} as const;

// ============================================================================
// SPACING
// ============================================================================

export const spacing = {
  0: '0',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '20px',
  6: '24px',
  8: '32px',
  10: '40px',
  12: '48px',
  16: '64px',
  20: '80px',
  24: '96px',
} as const;

// ============================================================================
// BORDER RADIUS
// ============================================================================

export const borderRadius = {
  none: '0',
  sm: '4px',
  md: '8px',
  lg: '12px',
  xl: '16px',
  '2xl': '24px',
  full: '9999px',
} as const;

// ============================================================================
// SHADOWS
// ============================================================================

export const shadows = {
  xs: '0 1px 2px rgba(0,0,0,0.3)',
  sm: '0 2px 4px rgba(0,0,0,0.35)',
  md: '0 4px 12px rgba(0,0,0,0.4)',
  lg: '0 8px 24px rgba(0,0,0,0.45)',
  xl: '0 16px 48px rgba(0,0,0,0.5)',
  'glow-green': '0 0 24px rgba(0,212,126,0.15)',
  'glow-red': '0 0 24px rgba(255,71,87,0.15)',
  'glow-blue': '0 0 24px rgba(59,130,246,0.15)',
  'glow-purple': '0 0 24px rgba(168,85,247,0.15)',
} as const;

// ============================================================================
// MOTION
// ============================================================================

export const motion = {
  duration: {
    instant: '50ms',
    fast: '100ms',
    normal: '200ms',
    slow: '300ms',
    slower: '500ms',
  },
  easing: {
    out: 'cubic-bezier(0.16, 1, 0.3, 1)',
    'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)',
    spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    sharp: 'cubic-bezier(0.4, 0, 0.6, 1)',
  },
} as const;

// ============================================================================
// BREAKPOINTS
// ============================================================================

export const breakpoints = {
  mobile: '320px',
  tablet: '768px',
  desktop: '1024px',
  wide: '1440px',
  ultrawide: '1920px',
} as const;

// ============================================================================
// Z-INDEX
// ============================================================================

export const zIndex = {
  base: 0,
  dropdown: 100,
  sticky: 200,
  modal: 300,
  popover: 400,
  tooltip: 500,
  toast: 600,
  loading: 700,
} as const;

// ============================================================================
// COMPONENT TOKENS
// ============================================================================

export const components = {
  button: {
    height: {
      sm: '32px',
      md: '40px',
      lg: '48px',
      xl: '56px',
    },
    padding: {
      sm: '0 12px',
      md: '0 16px',
      lg: '0 24px',
      xl: '0 32px',
    },
    fontSize: {
      sm: '0.75rem',
      md: '0.875rem',
      lg: '1rem',
      xl: '1.125rem',
    },
    borderRadius: '8px',
  },
  input: {
    height: {
      sm: '32px',
      md: '40px',
      lg: '48px',
    },
    padding: '0 12px',
    fontSize: '0.875rem',
    borderRadius: '8px',
  },
  card: {
    padding: {
      sm: '12px',
      md: '16px',
      lg: '24px',
    },
    borderRadius: '12px',
  },
  tooltip: {
    maxWidth: '320px',
    padding: '8px 12px',
    fontSize: '0.75rem',
    borderRadius: '6px',
  },
} as const;

// ============================================================================
// EXPORTS
// ============================================================================

export const tokens = {
  colors,
  typography,
  spacing,
  borderRadius,
  shadows,
  motion,
  breakpoints,
  zIndex,
  components,
} as const;

export type Tokens = typeof tokens;
export type Colors = typeof colors;
export type Typography = typeof typography;
export type Spacing = typeof spacing;
export type BorderRadius = typeof borderRadius;
export type Shadows = typeof shadows;
export type Motion = typeof motion;
export type Breakpoints = typeof breakpoints;
export type ZIndex = typeof zIndex;
export type Components = typeof components;