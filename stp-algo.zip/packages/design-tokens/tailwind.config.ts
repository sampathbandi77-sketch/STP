/**
 * SAMPATH PRO MAX - Tailwind Config
 * Extends Tailwind with design tokens
 */

import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    '../../apps/**/*.{ts,tsx,js,jsx}',
    '../../packages/**/*.{ts,tsx,js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Base backgrounds
        bg: {
          deep: '#05080C',
          elevated: '#0A0F16',
          surface: '#101820',
          hover: '#161F2B',
          active: '#1B2838',
        },
        // Borders
        border: {
          subtle: '#1E2A3A',
          DEFAULT: '#2A3A4A',
          strong: '#3A4D5D',
        },
        // Text
        text: {
          primary: '#E8ECF1',
          secondary: '#A8B3C0',
          muted: '#6B7A8A',
          inverse: '#05080C',
        },
        // Semantic - Trading
        profit: {
          DEFAULT: '#00D47E',
          bright: '#00FF9D',
          dim: '#004D2E',
        },
        loss: {
          DEFAULT: '#FF4757',
          bright: '#FF6B7A',
          dim: '#4D1A1F',
        },
        info: {
          DEFAULT: '#3B82F6',
          bright: '#60A5FA',
          dim: '#1E3A5F',
        },
        warn: {
          DEFAULT: '#F59E0B',
          bright: '#FBBF24',
          dim: '#4D3A0A',
        },
        ai: {
          DEFAULT: '#A855F7',
          bright: '#C084FC',
          dim: '#3A1F5A',
        },
        premium: {
          DEFAULT: '#F5C542',
        },
        // Chart-specific
        chart: {
          grid: '#1E2A3A',
          axis: '#4A5A6A',
          crosshair: '#3B82F6',
          'volume-up': '#00D47E',
          'volume-down': '#FF4757',
          'ma-9': '#3B82F6',
          'ma-20': '#F59E0B',
          'ma-50': '#A855F7',
          'ma-200': '#FF4757',
          vwap: '#00D47E',
        },
      },

      fontFamily: {
        display: ['Space Grotesk', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
        ui: ['Inter', 'system-ui', 'sans-serif'],
      },

      fontSize: {
        xs: ['clamp(0.625rem, 0.6rem + 0.125vw, 0.6875rem)', { lineHeight: '1.5', letterSpacing: '0.02em' }],
        sm: ['clamp(0.75rem, 0.725rem + 0.125vw, 0.8125rem)', { lineHeight: '1.5', letterSpacing: '0.01em' }],
        base: ['clamp(0.875rem, 0.85rem + 0.125vw, 0.9375rem)', { lineHeight: '1.5' }],
        lg: ['clamp(1rem, 0.975rem + 0.125vw, 1.0625rem)', { lineHeight: '1.5' }],
        xl: ['clamp(1.125rem, 1.1rem + 0.125vw, 1.1875rem)', { lineHeight: '1.4' }],
        '2xl': ['clamp(1.25rem, 1.2rem + 0.25vw, 1.375rem)', { lineHeight: '1.3', letterSpacing: '-0.01em' }],
        '3xl': ['clamp(1.5rem, 1.45rem + 0.25vw, 1.625rem)', { lineHeight: '1.2', letterSpacing: '-0.02em' }],
        '4xl': ['clamp(1.875rem, 1.8rem + 0.375vw, 2.125rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        '5xl': ['clamp(2.25rem, 2.15rem + 0.5vw, 2.625rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
      },

      fontWeight: {
        normal: 400,
        medium: 500,
        semibold: 600,
        bold: 700,
      },

      letterSpacing: {
        tight: '-0.02em',
        normal: '0',
        wide: '0.02em',
        wider: '0.04em',
        mono: '0.03em',
      },

      spacing: {
        0: '0',
        1: '4px',
        2: '8px',
        3: '12px',
        4: '16px',
        5: '20px',
        6: '24px',
        8: '32px',
        10: '40px',
        12: '48px',
        16: '64px',
        20: '80px',
        24: '96px',
      },

      borderRadius: {
        none: '0',
        sm: '4px',
        md: '8px',
        lg: '12px',
        xl: '16px',
        '2xl': '24px',
        full: '9999px',
      },

      boxShadow: {
        xs: '0 1px 2px rgba(0,0,0,0.3)',
        sm: '0 2px 4px rgba(0,0,0,0.35)',
        md: '0 4px 12px rgba(0,0,0,0.4)',
        lg: '0 8px 24px rgba(0,0,0,0.45)',
        xl: '0 16px 48px rgba(0,0,0,0.5)',
        'glow-green': '0 0 24px rgba(0,212,126,0.15)',
        'glow-red': '0 0 24px rgba(255,71,87,0.15)',
        'glow-blue': '0 0 24px rgba(59,130,246,0.15)',
        'glow-purple': '0 0 24px rgba(168,85,247,0.15)',
      },

      transitionDuration: {
        instant: '50ms',
        fast: '100ms',
        normal: '200ms',
        slow: '300ms',
        slower: '500ms',
      },

      transitionTimingFunction: {
        out: 'cubic-bezier(0.16, 1, 0.3, 1)',
        'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)',
        spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        sharp: 'cubic-bezier(0.4, 0, 0.6, 1)',
      },

      zIndex: {
        base: 0,
        dropdown: 100,
        sticky: 200,
        modal: 300,
        popover: 400,
        tooltip: 500,
        toast: 600,
        loading: 700,
      },

      screens: {
        mobile: '320px',
        tablet: '768px',
        desktop: '1024px',
        wide: '1440px',
        ultrawide: '1920px',
      },

      // Custom utilities for trading components
      keyframes: {
        'price-flash-green': {
          '0%, 100%': { backgroundColor: 'transparent' },
          '50%': { backgroundColor: 'rgba(0, 212, 126, 0.2)' },
        },
        'price-flash-red': {
          '0%, 100%': { backgroundColor: 'transparent' },
          '50%': { backgroundColor: 'rgba(255, 71, 87, 0.2)' },
        },
        'pulse-ai': {
          '0%, 100%': { opacity: '0.5', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.05)' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-down': {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
      },

      animation: {
        'price-flash-green': 'price-flash-green 100ms ease-out',
        'price-flash-red': 'price-flash-red 100ms ease-out',
        'pulse-ai': 'pulse-ai 1000ms ease-in-out infinite',
        'shimmer': 'shimmer 1200ms ease-in-out infinite',
        'slide-up': 'slide-up 200ms ease-out',
        'slide-down': 'slide-down 200ms ease-out',
        'fade-in': 'fade-in 200ms ease-out',
        'scale-in': 'scale-in 200ms ease-out',
      },

      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'shimmer': 'linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)',
        'bg-mesh': 'radial-gradient(at 0% 0%, rgba(59,130,246,0.1) 0px, transparent 50%), radial-gradient(at 100% 100%, rgba(168,85,247,0.1) 0px, transparent 50%)',
      },
    },
  },
  plugins: [],
};

export default config;