/**
 * Scanner UI Components
 * User interface for building and running stock scans
 */

import React, { useState, useRef, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { ScanFilter, ScanConfig, ScanFilterBuilder, defaultScanConfigs } from '@sampath/scanner';
import { toast } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';

export interface ScanBuilderProps {
  onScanExecute?: (results: any[]) => void;
  onConfigChange?: (config: ScanConfig) => void;
}

export const ScanBuilder = ({ onScanExecute, onConfigChange }: ScanBuilderProps) => {
  const queryClient = useQueryClient();
  const { data: watchlist } = useMarketStore.getState();

  // State for scan configuration
  const [config, setConfig] = useState<ScanConfig>({
    id: 'new-scan',
    name: 'New Scan',
    description: '',
    symbols: watchlist?.length > 0 ? watchlist : ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK'],
    filters: [],
    timeframe: '1D',
    active: false,
    createdAt: new Date(),
    lastRun: null,
    resultsCount: 0,
  });

  const [filterLibrary, setFilterLibrary] = useState<ScanFilter[]>([
    // Price filters
    { ...ScanFilterBuilder.priceAbove(100), isSelected: false },
    { ...ScanFilterBuilder.priceBelow(500), isSelected: false },
    { ...ScanFilterBuilder.changePercentGte(2), isSelected: false },
    { ...ScanFilterBuilder.changePercentLte(-2), isSelected: false },

    // Technical filters
    { ...ScanFilterBuilder.rsiOversold(), isSelected: false },
    { ...ScanFilterBuilder.rsiOverbought(), isSelected: false },
    { ...ScanFilterBuilder.macdBullishCrossover(), isSelected: false },
    { ...ScanFilterBuilder.macdBearishCrossover(), isSelected: false },

    // Moving Average filters
    { ...ScanFilterBuilder.priceAboveMA(9, 0), isSelected: false },
    { ...ScanFilterBuilder.priceAboveMA(20, 0), isSelected: false },
    { ...ScanFilterBuilder.priceBelowMA(50, 0), isSelected: false },

    // Volume filters
    { ...ScanFilterBuilder.volumeAbove(500), isSelected: false },
    { ...ScanFilterBuilder.volumeSpike(1.5), isSelected: false },

    // Custom conditions
    { ...ScanFilterBuilder.and(), isSelected: false },
    { ...ScanFilterBuilder.or(), isSelected: false },
  ]);

  const [selectedFilters, setSelectedFilters] = useState<ScanFilter[]>([]);

  // Add filter to scan
  const addFilter = (filter: ScanFilter) => {
    setSelectedFilters(prev => {
      // Check if filter already exists
      const exists = prev.some(f => f.id === filter.id);
      if (!exists) {
        return [...prev, { ...filter, isSelected: true }];
      }
      return prev.filter(f => f.id !== filter.id).map(f => ({
        ...f,
        isSelected: f.id !== filter.id ? f.isSelected : false,
      }));
    });
  };

  // Remove filter from scan
  const removeFilter = (filterId: string) => {
    setSelectedFilters(prev => prev.filter(f => f.id !== filterId));
  };

  // Build the scan configuration
  const buildConfig = (): ScanConfig => {
    return {
      ...config,
      filters: selectedFilters,
    };
  };

  // Execute the scan
  const executeScan = async () => {
    const scanEngine = new (await import('@sampath/scanner')).ScannerEngine;
    // In production, inject real market data service
    const execution = await scanEngine.executeScan(buildConfig());

    setConfig(prev => ({
      ...prev,
      lastRun: new Date(),
      resultsCount: execution.results.length,
    }));

    onScanExecute?.(execution.results);
    toast({ title: `Scan completed: ${execution.results.length} stocks matched` });
  };

  // UI: Filter Categories
  const filterCategories = [
    { name: 'Price', filters: ['priceAbove', 'priceBelow', 'changePercentGte', 'changePercentLte'] },
    { name: 'Technical', filters: ['rsiOversold', 'rsiOverbought', 'macdBullish', 'macdBearish', 'priceAboveMA', 'priceBelowMA'] },
    { name: 'Volume', filters: ['volumeAbove', 'volumeSpike'] },
    { name: 'Custom', filters: ['and', 'or'] },
  ];

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader>
          <CardTitle>Stock Scanner Builder</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              placeholder="Scan name"
              value={config.name}
              onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
            />
            <Button variant="ghost" size="sm" onClick={executeScan}>
              Run
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {/* Selected Filters Summary */}
          {selectedFilters.length > 0 && (
            <div className="mb-4 p-3 bg-bg-elevated rounded-lg">
              <div className="text-xs text-text-secondary mb-1">Active Filters</div>
              <div className="grid grid-cols-2 gap-2">
                {selectedFilters.map((filter, index) => (
                  <div
                    key={index}
                    className="text-[10px] px-2 py-1 rounded bg-blue-info text-white"
                  >
                    {filter.name}
                    <button
                      onClick={() => removeFilter(filter.id)}
                      className="ml-2 text-[10px] underline text-blue-bright/80"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Filter Library */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            {filterLibrary.map((filter, index) => (
              <div
                key={index}
                className={clsx(
                  'p-3 bg-bg-elevated rounded-lg border border-border-subtle hover:bg-bg-hover transition-colors',
                  filter.isSelected && 'border-blue-bright'
                )}
              >
                <div className="text-xs text-text-secondary mb-1">{filter.name}</div>
                <div className="text-sm font-medium {filter.isSelected ? 'text-blue-bright' : 'text-text-primary'}">
                  {filter.description}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => addFilter(filter)}
                  disabled={filter.isSelected}
                >
                  {filter.isSelected ? 'Added' : 'Add'}
                </Button>
              </div>
            ))}
          </div>

          {/* Quick Presets */}
          <div className="mb-4">
            <div className="text-xs text-text-secondary mb-2">Quick Presets</div>
            <div className="grid grid-cols-2 gap-2">
              {defaultScanConfigs.map((preset) => (
                <Button
                  key={preset.id}
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    // Apply preset filters
                    const presetFilterIds = preset.filters.map(f => f.id);
                    setSelectedFilters(prev => {
                      // Start fresh with preset filters
                      return preset.filters.map(f => ({ ...f, isSelected: true }));
                    });
                    setConfig(prev => ({
                      ...prev,
                      name: preset.name,
                      description: preset.description,
                      symbols: preset.symbols,
                    }));
                  }}
                >
                  {preset.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Scan Symbols */}
          <div>
            <div className="text-xs text-text-secondary mb-2">Scan Symbols</div>
            <Select
              placeholder="Select symbols"
              options={config.symbols.map((sym: string) => ({ value: sym, label: sym }))}
              onChange={(e) => setConfig(prev => ({ ...prev, symbols: e.target.value as string[] }))}
              className="max-h-48"
            />
          </div>

          {/* Timeframe */}
          <div className="mt-4">
            <div className="text-xs text-text-secondary mb-2">Timeframe</div>
            <Select
              placeholder="1D"
              options={[
                { value: '1D', label: '1 Day' },
                { value: '1W', label: '1 Week' },
                { value: '1M', label: '1 Month' },
              ]}
              onChange={(e) => setConfig(prev => ({ ...prev, timeframe: e.target.value as '1D' | '1W' | '1M' }))}
            />
          </div>
        </CardContent>

        <CardFooter>
          <Button variant="primary" onClick={executeScan} disabled={selectedFilters.length === 0}>
            Run Scan {selectedFilters.length > 0 ? `(${selectedFilters.length} filters)` : ''}
          </Button>
          <Button variant="ghost" onClick={() => setSelectedFilters([])}>Clear All</Button>
        </CardFooter>
      </Card>
    </div>
  );
};