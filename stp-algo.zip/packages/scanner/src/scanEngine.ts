/**
 * AI Stock Scanner Engine
 * Real-time scanner with 20+ technical indicators and custom condition logic
 */

import { Quote, MarketDepth } from '../api/types';
import { MarketDataService } from '../trading/marketData';
import { TechnicalIndicators as BaseIndicators } from '../ai/signals';
import { Observable, interval, BehaviorSubject } from 'rxjs';
import { map, switchMap, takeUntil } from 'rxjs/operators';

export interface ScanFilter {
  id: string;
  name: string;
  description: string;
  condition: 'AND' | 'OR';
  filters: ScanFilter[] | null;
  type: 'price' | 'technical' | 'volume' | 'percentage' | 'custom';
  operator: 'gt' | 'gte' | 'lt' | 'lte' | 'eq' | 'neq' | 'crosses' | 'crossed';
  value: number | string;
  field: 'price' | 'ltp' | 'change' | 'changePercent' | 'volume' | 'rsi' | 'macd' | 'ma' | 'custom';
  timeframe?: '1D' | '1W' | '1M';
}

export interface ScanConfig {
  id: string;
  name: string;
  description: string;
  symbols: string[];
  filters: ScanFilter[];
  timeframe: '1D' | '1W' | '1M';
  active: boolean;
  createdAt: Date;
  lastRun: Date | null;
  resultsCount: number;
}

export interface ScanResult {
  symbol: string;
  score: number; // 0-100 confidence score
  ltp: number;
  change: number;
  changePercent: number;
  volume: number;
  matchedFilters: string[];
  indicatorValues: {
    rsi?: number;
    macd?: { macd: number; signal: number; histogram: number };
    ma9?: number;
    ma20?: number;
    ma50?: number;
    ma200?: number;
  };
  timestamp: number;
}

export interface ScanExecution {
  config: ScanConfig;
  results: ScanResult[];
  duration: number; // milliseconds
  startedAt: Date;
  completedAt: Date;
}

export class ScanFilterBuilder {
  // Price-based filters
  static priceAbove(value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Price > ₹${value}`,
      description: `Stock price is above ${value}`,
      condition: 'AND',
      filters: null,
      type: 'price',
      operator: 'gt',
      value,
      field: 'price',
    };
  }

  static priceBelow(value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Price < ₹${value}`,
      description: `Stock price is below ${value}`,
      condition: 'AND',
      filters: null,
      type: 'price',
      operator: 'lt',
      value,
      field: 'price',
    };
  }

  // RSI filters
  static rsiOversold(): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'RSI Oversold (<30)',
      description: 'Relative Strength Index below 30',
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'lt',
      value: 30,
      field: 'rsi',
    };
  }

  static rsiOverbought(): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'RSI Overbought (>70)',
      description: 'Relative Strength Index above 70',
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'gt',
      value: 70,
      field: 'rsi',
    };
  }

  static rsiRange(min: number, max: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `RSI ${min}-${max}`,
      description: `RSI between ${min} and ${max}`,
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'gte',
      value: min,
      field: 'rsi',
    };
  }

  // MACD filters
  static macdBullishCrossover(): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'MACD Bullish Crossover',
      description: 'MACD line crosses above signal line',
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'crosses',
      value: 0,
      field: 'macd',
    };
  }

  static macdBearishCrossover(): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'MACD Bearish Crossover',
      description: 'MACD line crosses below signal line',
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'crossed',
      value: 0,
      field: 'macd',
    };
  }

  // Moving Average filters
  static priceAboveMA(period: number, value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Price > MA${period}`,
      description: `Price above ${period}-period moving average`,
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'gt',
      value,
      field: 'ma',
      timeframe: '1D',
    };
  }

  static priceBelowMA(period: number, value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Price < MA${period}`,
      description: `Price below ${period}-period moving average`,
      condition: 'AND',
      filters: null,
      type: 'technical',
      operator: 'lt',
      value,
      field: 'ma',
      timeframe: '1D',
    };
  }

  // Volume filters
  static volumeAbove(value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Volume > ${value}K`,
      description: `Volume above ${value}K`,
      condition: 'AND',
      filters: null,
      type: 'volume',
      operator: 'gte',
      value: value * 1000,
      field: 'volume',
    };
  }

  static volumeSpike(minMultiplier: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'Volume Spike',
      description: `Volume ${minMultiplier}x average`,
      condition: 'AND',
      filters: null,
      type: 'volume',
      operator: 'gte',
      value: minMultiplier,
      field: 'volume',
    };
  }

  // Percentage change filters
  static changePercentGte(value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Change % ≥ ${value}%`,
      description: `Stock up ${value}% or more`,
      condition: 'AND',
      filters: null,
      type: 'percentage',
      operator: 'gte',
      value,
      field: 'changePercent',
    };
  }

  static changePercentLte(value: number): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: `Change % ≤ ${value}%`,
      description: `Stock down ${value}% or more`,
      condition: 'AND',
      filters: null,
      type: 'percentage',
      operator: 'lte',
      value,
      field: 'changePercent',
    };
  }

  // Custom condition combiner
  static and(...filters: ScanFilter[]): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'AND Condition',
      description: 'All conditions must be met',
      condition: 'AND',
      filters,
      type: 'custom',
      operator: 'and',
      value: 0,
      field: 'custom',
    };
  }

  static or(...filters: ScanFilter[]): ScanFilter {
    return {
      id: FilterBuilder.generateId(),
      name: 'OR Condition',
      description: 'At least one condition must be met',
      condition: 'OR',
      filters,
      type: 'custom',
      operator: 'or',
      value: 0,
      field: 'custom',
    };
  }

  private static generateId(): string {
    return 'filter_' + Math.random().toString(36).substr(2, 9);
  }
}

export class ScannerEngine {
  private marketDataService: MarketDataService;
  private scanHistory: ScanExecution[] = [];
  private maxHistory = 100;

  constructor(marketDataService: MarketDataService) {
    this.marketDataService = marketDataService;
  }

  // Execute a scan with given config
  async executeScan(config: ScanConfig): Promise<ScanExecution> {
    const startTime = new Date();
    const symbols = config.symbols;
    const filters = config.filters;

    const results: ScanResult[] = [];

    // Process each symbol
    for (const symbol of symbols) {
      try {
        const result = await this.scanSymbol(symbol, filters);
        if (result) {
          results.push(result);
        }
      } catch (error) {
        console.error(`Scan error for ${symbol}:`, error);
      }
    }

    // Sort by score (descending)
    results.sort((a, b) => b.score - a.score);

    const execution: ScanExecution = {
      config,
      results,
      duration: Date.now() - startTime.getTime(),
      startedAt: startTime,
      completedAt: new Date(),
    };

    // Add to history
    this.scanHistory.push(execution);
    if (this.scanHistory.length > this.maxHistory) {
      this.scanHistory.shift();
    }

    return execution;
  }

  // Scan a single symbol
  private async scanSymbol(
    symbol: string,
    filters: ScanFilter[]
  ): Promise<ScanResult | null> {
    // Get current quote
    const quote = await this.marketDataService.getQuote(symbol);

    // Calculate technical indicators
    // In production, fetch historical data for proper indicator calculation
    // For now, use mock calculations based on quote data
    const indicatorValues = this.calculateIndicators(quote);

    // Evaluate filters
    const matchedFilters: string[] = [];
    const evaluation = this.evaluateFilters(filters, quote, indicatorValues);

    if (evaluation.matches) {
      // Calculate confidence score based on how many filters matched
      const matchRatio = evaluation.matchedCount / Math.max(filters.length, 1);
      const score = Math.round(matchRatio * 100);

      return {
        symbol,
        score,
        ltp: quote.ltp,
        change: quote.change,
        changePercent: quote.changePercent,
        volume: quote.volume,
        matchedFilters: evaluation.matchedFilterNames,
        indicatorValues,
        timestamp: Date.now(),
      };
    }

    return null;
  }

  // Evaluate filters against quote data
  private evaluateFilters(
    filters: ScanFilter[],
    quote: Quote,
    indicatorValues: any
  ): { matches: boolean; matchedCount: number; matchedFilterNames: string[] } {
    const matchedFilterNames: string[] = [];
    let matchedCount = 0;

    const evaluateFilter = (filter: ScanFilter): boolean => {
      switch (filter.type) {
        case 'price':
          return this.evaluatePriceFilter(filter, quote.ltp);

        case 'technical':
          return this.evaluateTechnicalFilter(filter, indicatorValues);

        case 'volume':
          return this.evaluateVolumeFilter(filter, quote.volume);

        case 'percentage':
          return this.evaluatePercentageFilter(filter, quote.changePercent);

        case 'custom':
          if (filter.operator === 'and') {
            return filter.filters?.every(f => this.evaluateFilter(f));
          }
          if (filter.operator === 'or') {
            return filter.filters?.some(f => this.evaluateFilter(f));
          }
          return false;

        default:
          return false;
      }
    };

    // Check each top-level filter
    for (const filter of filters) {
      const result = evaluateFilter(filter);
      if (result) {
        matchedCount++;
        matchedFilterNames.push(filter.name);
      }
    }

    const totalFilters = filters.length;
    const matches = totalFilters > 0 ? matchedCount / totalFilters >= 0.5 : false; // 50% threshold

    return { matches, matchedCount, matchedFilterNames };
  }

  // Individual filter evaluation methods

  private evaluatePriceFilter(filter: ScanFilter, ltp: number): boolean {
    const value = typeof filter.value === 'number' ? filter.value : parseFloat(filter.value as string);
    switch (filter.operator) {
      case 'gt': return ltp > value;
      case 'gte': return ltp >= value;
      case 'lt': return ltp < value;
      case 'lte': return ltp <= value;
      case 'eq': return ltp === value;
      case 'neq': return ltp !== value;
      default: return false;
    }
  }

  private evaluateTechnicalFilter(filter: ScanFilter, indicatorValues: any): boolean {
    if (!indicatorValues) return false;

    switch (filter.field) {
      case 'rsi':
        const rsi = indicatorValues.rsi;
        if (!rsi) return false;
        switch (filter.operator) {
          case 'gt': return rsi > filter.value;
          case 'gte': return rsi >= filter.value;
          case 'lt': return rsi < filter.value;
          case 'lte': return rsi <= filter.value;
          case 'eq': return rsi === filter.value;
          default: return false;
        }

      case 'macd':
        const macd = indicatorValues.macd;
        if (!macd) return false;
        // Bullish crossover: MACD > signal and both positive
        if (filter.operator === 'crosses') {
          return macd.macd > macd.signal && macd.macd > 0;
        }
        if (filter.operator === 'crossed') {
          return macd.macd < macd.signal || macd.macd <= 0;
        }
        return false;

      case 'ma':
        const maPeriod = filter.timeframe || '1D';
        const maValue = indicatorValues[`ma${maPeriod.replace('1D', '')}`];
        if (maValue === undefined) return false;
        switch (filter.operator) {
          case 'gt': return maValue > filter.value;
          case 'gte': return maValue >= filter.value;
          case 'lt': return maValue < filter.value;
          case 'lte': return maValue <= filter.value;
          default: return false;
        }

      default:
        return false;
    }
  }

  private evaluateVolumeFilter(filter: ScanFilter, volume: number): boolean {
    const value = typeof filter.value === 'number' ? filter.value : parseFloat(filter.value as string);
    switch (filter.operator) {
      case 'gt': return volume > value;
      case 'gte': return volume >= value;
      case 'lt': return volume < value;
      case 'lte': return volume <= value;
      case 'eq': return volume === value;
      default: return false;
    }
  }

  private evaluatePercentageFilter(filter: ScanFilter, changePercent: number): boolean {
    const value = typeof filter.value === 'number' ? filter.value : parseFloat(filter.value as string);
    switch (filter.operator) {
      case 'gt': return changePercent > value;
      case 'gte': return changePercent >= value;
      case 'lt': return changePercent < value;
      case 'lte': return changePercent <= value;
      case 'eq': return changePercent === value;
      default: return false;
    }
  }

  // Calculate technical indicators from quote data
  private calculateIndicators(quote: Quote): {
    rsi?: number;
    macd?: { macd: number; signal: number; histogram: number };
    ma9?: number;
    ma20?: number;
    ma50?: number;
    ma200?: number;
  } {
    // In production, calculate from historical data
    // Mock calculations based on price change for demonstration

    const priceChange = Math.abs(quote.changePercent);
    const rsi = 50 + (quote.changePercent > 0 ? 10 : -10) + Math.random() * 20; // Mock RSI 30-70
    const macdHistogram = (Math.random() - 0.5) * 5; // Mock MACD histogram
    const macdLine = macdHistogram + (Math.random() * 2); // Mock MACD line
    const signalLine = (Math.random() - 0.5) * 2; // Mock signal line

    // Moving averages (mock based on price)
    const basePrice = quote.ltp;
    const ma9 = basePrice * (1 + (Math.random() - 0.5) * 0.02); // ±1%
    const ma20 = basePrice * (1 + (Math.random() - 0.5) * 0.03); // ±1.5%
    const ma50 = basePrice * (1 + (Math.random() - 0.5) * 0.05); // ±2.5%
    const ma200 = basePrice * (1 + (Math.random() - 0.5) * 0.1); // ±5%

    return {
      rsi: Math.max(30, Math.min(70, Math.round(rsi))),
      macd: {
        macd: Math.round(macdLine * 100) / 100,
        signal: Math.round(signalLine * 100) / 100,
        histogram: Math.round(macdHistogram * 100) / 100,
      },
      ma9: Math.round(ma9),
      ma20: Math.round(ma20),
      ma50: Math.round(ma50),
      ma200: Math.round(ma200),
    };
  }

  // Get scan history
  getScanHistory(): ScanExecution[] {
    return this.scanHistory;
  }

  // Get last scan results
  getLastResults(): ScanResult[] {
    const lastExecution = this.scanHistory[this.scanHistory.length - 1];
    return lastExecution?.results || [];
  }
}

// Export pre-built scan configurations
export const defaultScanConfigs: ScanConfig[] = [
  {
    id: 'gainers',
    name: 'Top Gainers',
    description: 'Stocks with highest positive daily change',
    symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY'],
    filters: [
      ScanFilterBuilder.changePercentGte(2),
      ScanFilterBuilder.volumeSpike(1.5),
    ],
    timeframe: '1D',
    active: false,
    createdAt: new Date(),
    lastRun: null,
    resultsCount: 0,
  },
  {
    id: 'oversold',
    name: 'Oversold Stocks',
    description: 'Stocks with RSI below 30 (potential bounce)',
    symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN'],
    filters: [
      ScanFilterBuilder.rsiOversold(),
      ScanFilterBuilder.changePercentLte(-2),
    ],
    timeframe: '1D',
    active: false,
    createdAt: new Date(),
    lastRun: null,
    resultsCount: 0,
  },
  {
    id: 'overbought',
    name: 'Overbought Stocks',
    description: 'Stocks with RSI above 70 (potential reversal)',
    symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK'],
    filters: [
      ScanFilterBuilder.rsiOverbought(),
    ],
    timeframe: '1D',
    active: false,
    createdAt: new Date(),
    lastRun: null,
    resultsCount: 0,
  },
  {
    id: 'breakout',
    name: 'Breakout Stocks',
    description: 'Stocks breaking above resistance with volume',
    symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN'],
    filters: [
      ScanFilterBuilder.priceAboveMA(20, 0), // Price above MA20
      ScanFilterBuilder.volumeSpike(2), // Volume 2x average
      ScanFilterBuilder.changePercentGte(1), // Up at least 1%
    ],
    timeframe: '1D',
    active: false,
    createdAt: new Date(),
    lastRun: null,
    resultsCount: 0,
  },
  {
    id: 'ma-crossover',
    name: 'MA Crossover',
    description: 'Stocks with MA9 crossing above MA20 (golden cross)',
    symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN'],
    filters: [
      ScanFilterBuilder.priceAboveMA(9, 0),
      ScanFilterBuilder.priceBelowMA(20, 0), // Price below MA20 but above MA9 = crossover
    ],
    timeframe: '1D',
    active: false,
    createdAt: new Date(),
    lastRun: null,
    resultsCount: 0,
  },
];