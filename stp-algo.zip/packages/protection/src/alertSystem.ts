/**
 * Alert System - Multi-channel notifications for profit protection events
 */

import { Observable, Subject, BehaviorSubject, interval, of } from 'rxjs';
import { map, filter, mergeMap, takeUntil } from 'rxjs/operators';
import { Quote, MarketDepth } from '../api/types';
import { ScannerEngine, ScanResult, ScanConfig } from '../scanner/scanEngine';
import { ProfitProtectionEngine, ProfitProtectionConfig, ProtectionStatus } from './profitProtectionEngine';
import { toast } from '@sampath/ui';

export interface AlertConfig {
  priceAlerts: boolean;
  aiSignalAlerts: boolean;
  smartMoneyAlerts: boolean;
  volumeAlerts: boolean;
  trailingStopAlerts: boolean;
  breachAlerts: boolean; // Circuit breaker triggers
  sound: boolean;
  desktopNotifications: boolean;
}

export interface PriceAlert {
  symbol: string;
  triggerPrice: number;
  currentPrice: number;
  alertType: 'above' | 'below' | 'crossed';
  triggered: boolean;
  timestamp: number;
}

export interface AISignalAlert {
  symbol: string;
  signalType: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  priceTarget: number;
  stopLoss: number;
  description: string;
  timestamp: number;
}

export interface SmartMoneyAlert {
  symbol: string;
  fiiNet: number;
  diiNet: number;
  bulkDeals: number;
  blockDeals: number;
  impact: 'strong-buy' | 'buy' | 'neutral' | 'sell' | 'strong-sell';
  timestamp: number;
}

export interface AlertSystem {
  init(config: AlertConfig): void;
  subscribe(callback: (alert: any) => void): void;
  triggerPriceAlert(symbol: string, triggerPrice: number, type: 'above' | 'below'): void;
  triggerAISignal(symbol: string, signal: AISignalAlert): void;
  triggerSmartMoneyAlert(smartMoney: SmartMoneyAlert): void;
}

export class AlertSystemImpl implements AlertSystem {
  private subject = new Subject<any>();
  private priceAlerts: Map<string, PriceAlert> = new Map();
  private config: AlertConfig;
  private shutdown$ = new Subject<boolean>();

  constructor(config: AlertConfig = this._defaultConfig()) {
    this.config = config;
    this._setupAutoAlerts();
  }

  private _defaultConfig(): AlertConfig {
    return {
      priceAlerts: true,
      aiSignalAlerts: true,
      smartMoneyAlerts: true,
      volumeAlerts: true,
      trailingStopAlerts: true,
      breachAlerts: true,
      sound: true,
      desktopNotifications: true,
    };
  }

  // Initialize the alert system
  init(config: AlertConfig): void {
    this.config = { ...this.config, ...config };
    this._setupAutoAlerts();
  }

  // Subscribe to alerts
  subscribe(callback: (alert: any) => void): void {
    this.subject.subscribe(callback);
  }

  // Trigger price alert
  triggerPriceAlert(symbol: string, triggerPrice: number, type: 'above' | 'below'): void {
    const currentQuote = this._getMockQuote(symbol);
    if (!currentQuote) return;

    const existing = this.priceAlerts.get(symbol);
    if (existing && existing.triggered) return; // Already triggered

    const alert: PriceAlert = {
      symbol,
      triggerPrice,
      currentPrice: currentQuote.ltp,
      alertType: type,
      triggered: currentQuote.ltp >= triggerPrice === (type === 'above'),
      timestamp: Date.now(),
    };

    this.priceAlerts.set(symbol, alert);
    this._dispatch(alert);
  }

  // Trigger AI signal alert
  triggerAISignal(symbol: string, signal: AISignalAlert): void {
    if (!this.config.aiSignalAlerts) return;

    const alert = {
      ...signal,
      type: 'ai-signal',
      timestamp: Date.now(),
    };

    this._dispatch(alert);
  }

  // Trigger smart money alert
  triggerSmartMoneyAlert(smartMoney: SmartMoneyAlert): void {
    if (!this.config.smartMoneyAlerts) return;

    const alert = {
      ...smartMoney,
      type: 'smart-money',
      timestamp: Date.now(),
    };

    this._dispatch(alert);
  }

  // Trigger trailing stop alert
  triggerTrailingStopAlert(symbol: string, currentPrice: number, entryPrice: number, pnl: number): void {
    if (!this.config.trailingStopAlerts) return;

    const pnlPercent = ((currentPrice - entryPrice) / entryPrice) * 100;
    const alert = {
      symbol,
      type: 'trailing-stop',
      currentPrice,
      entryPrice,
      pnl,
      pnlPercent,
      triggered: Math.abs(pnlPercent) >= 5, // 5% move threshold
      timestamp: Date.now(),
    };

    this._dispatch(alert);
  }

  // Trigger breach alert (circuit breaker)
  triggerBreachAlert(system: 'drawdown' | 'position-limit', details: any): void {
    if (!this.config.breachAlerts) return;

    const alert = {
      type: 'breach',
      system,
      details,
      timestamp: Date.now(),
    };

    this._dispatch(alert);
  }

  // Private: Setup automatic scanning alerts
  private _setupAutoAlerts(): void {
    // Price alerts every 30 seconds for configured symbols
    const priceCheck = interval(30000);

    priceCheck.pipe(
      takeUntil(this.shutdown$),
      mergeMap(() => this._checkPriceAlerts()),
    ).subscribe();

    // Smart money alerts
    const smartMoneyCheck = interval(60000);

    smartMoneyCheck.pipe(
      takeUntil(this.shutdown$),
      mergeMap(() => this._checkSmartMoneyAlerts()),
    ).subscribe();
  }

  // Private: Check price alerts against current market
  private _checkPriceAlerts(): Observable<PriceAlert[]> {
    const symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN'];
    return of(symbols).pipe(
      map(sym => this._getMockQuote(sym)),
      filter(Boolean),
      map(quote => {
        const alerts: PriceAlert[] = [];

        // Check each active price alert
        this.priceAlerts.forEach((alert, symbol) => {
          if (alert.triggered) return; // Already triggered

          const shouldTrigger = alert.alertType === 'above'
            ? quote.ltp >= alert.triggerPrice
            : quote.ltp <= alert.triggerPrice;

          if (shouldTrigger) {
            alert.triggered = true;
            alert.currentPrice = quote.ltp;
            alert.timestamp = Date.now();
            alerts.push(alert);
            this.priceAlerts.set(symbol, alert);
          }
        });

        return alerts;
      })
    );
  }

  // Private: Check smart money flow alerts
  private _checkSmartMoneyAlerts(): Observable<SmartMoneyAlert[]> {
    // In production, would check against real smart money data
    return of<SmartMoneyAlert[]>([]);
  }

  // Private: Get mock quote for symbol
  private _getMockQuote(symbol: string): { ltp: number } | null {
    // In production, fetch from market data service
    const mockQuotes: Record<string, { ltp: number }> = {
      RELIANCE: { ltp: 2510 },
      TCS: { ltp: 3450 },
      HDFCBANK: { ltp: 1520 },
      INFY: { ltp: 1480 },
      ICICIBANK: { ltp: 965 },
      SBIN: { ltp: 720 },
    };

    return mockQuotes[symbol] || null;
  }

  // Private: Dispatch alert to all subscribers
  private _dispatch(alert: any): void {
    this.subject.next(alert);

    // Show toast notification
    toast({
      title: this._getAlertTitle(alert),
      description: this._getAlertDescription(alert),
      variant: this._getAlertVariant(alert),
    });
  }

  // Private: Get alert title for display
  private _getAlertTitle(alert: any): string {
    const types: any = {
      'ai-signal': 'AI Signal',
      'smart-money': 'Smart Money',
      'trailing-stop': 'Trailing Stop',
      'breach': 'Circuit Breaker',
      default: 'Alert',
    };
    return (types as any)[alert.type] || types.default;
  }

  // Private: Get alert description
  private _getAlertDescription(alert: any): string {
    const descriptions: any = {
      'ai-signal': `${alert.symbol}: ${alert.signalType} (${alert.confidence}% confidence)`,
      'smart-money': `${alert.symbol}: ₹${Math.abs(alert.fiiNet).toLocaleString()} FII flow`,
      'trailing-stop': `${alert.symbol}: ${alert.pnlPercent >= 0 ? '+' : ''}${alert.pnlPercent.toFixed(1)}% PnL`,
      'breach': ` ${alert.system} circuit breaker triggered`,
      default: 'New alert triggered',
    };
    return (descriptions as any)[alert.type] || descriptions.default;
  }

  // Private: Get alert variant for toast
  private _getAlertVariant(alert: any): 'success' | 'destructive' | 'default' {
    const variants: any = {
      'ai-signal': 'success',
      'smart-money': 'default',
      'trailing-stop': 'success',
      'breach': 'destructive',
      default: 'default',
    };
    return (variants as any)[alert.type] || variants.default;
  }

  // Cleanup on destroy
  destroy(): void {
    this.shutdown$.next(true);
    this.shutdown$.complete();
  }
}