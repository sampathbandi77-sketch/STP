/**
 * Profit Protection Engine - Core Orchestration
 * Combines scanner, alerts, risk management, and execution to prevent missed profits
 */

import { Quote, MarketDepth } from '../api/types';
import { MarketDataService } from '../trading/marketData';
import { ScannerEngine, ScanConfig, ScanFilter, defaultScanConfigs, ScanResult } from '../scanner/scanEngine';
import { OrderManagementService } from '../trading/orderManagement';
import { PortfolioService } from '../trading/portfolioService';
import { SmartMoneyTracker } from '../ai/smartMoney';
import { Observable, interval, of, BehaviorSubject, combineLatest } from 'rxjs';
import { map, switchMap, mergeMap, filter, take, takeUntil, timeout } from 'rxjs/operators';

export interface ProfitProtectionConfig {
  // Scanner settings
  enabledScanners: string[]; // IDs of active scan configs
  scanInterval: number; // milliseconds (default 30s)
  autoExecute: boolean; // Auto-place protective orders
  minConfidenceScore: number; // Minimum signal confidence (0-100)

  // Alert settings
  priceAlerts: boolean;
  aiSignalAlerts: boolean;
  smartMoneyAlerts: boolean;
  volumeAlerts: boolean;

  // Risk management
  maxPositionSize: number; // Maximum capital per position (%)
  maxDrawdownCutoff: number; % Max drawdown to halt trading
  stopLossMethod: 'percentage' | 'atr' | 'trailing';
  trailingStopPercentage: number;

  // Execution settings
  preferredBroker: 'dhan' | 'upstox' | 'coinswitch' | 'auto';
  confirmBeforeExecution: boolean;
  timeZone: string; // For market hour checks
}

export interface ProtectionStatus {
  isScanning: boolean;
  lastScan: Date | null;
  lastSignal: ScanResult | null;
  activePositions: number;
  totalCapitalAtRisk: number;
  maxDrawdownHit: boolean;
  tradingPaused: boolean;
  nextScanAt: Date;
}

export class ProfitProtectionEngine {
  private marketDataService: MarketDataService;
  private orderManagement: OrderManagementService;
  private portfolioService: PortfolioService;
  private smartMoneyTracker: SmartMoneyTracker;
  private config: ProfitProtectionConfig;
  private scanSubject = new BehaviorSubject<boolean>(false);
  private alertSubject = new BehaviorSubject<any[]>([]);
  private isPaused = false;
  private maxDrawdownObserved = 0;

  constructor(
    marketDataService: MarketDataService,
    orderManagement: OrderManagementService,
    portfolioService: PortfolioService,
    smartMoneyTracker: SmartMoneyTracker,
    config: ProfitProtectionConfig
  ) {
    this.marketDataService = marketDataService;
    this.orderManagement = orderManagement;
    this.portfolioService = portfolioService;
    this.smartMoneyTracker = smartMoneyTracker;
    this.config = config;
  }

  // Start the protection system
  start(): void {
    if (this.isPaused) return;

    // Start scanning interval
    const scanInterval = interval(this.config.scanInterval);

    scanInterval.pipe(
      takeUntil(this._shutdown$),
      // Skip if already scanning
      filter(() => !this.scanSubject.value),
      // Run scan
      mergeMap(() => this._executeScan()),
      // Process results
      mergeMap((execution) => this._processExecution(execution)),
      // Throttle to prevent rate flooding
      timeout(5000)
    ).subscribe({
      next: (result) => {
        console.log('Protection cycle complete:', result);
      },
      error: (err) => {
        console.error('Protection cycle error:', err);
      }
    });

    this.scanSubject.next(true);
    console.log('Profit Protection Engine started');
  }

  // Stop the protection system
  stop(): void {
    this.scanSubject.next(false);
    this.isPaused = true;
    console.log('Profit Protection Engine stopped');
  }

  // Pause/resume
  togglePause(): void {
    this.isPaused = !this.isPaused;
    console.log(`Protection ${this.isPaused ? 'paused' : 'resumed'}`);
  }

  // _executeScan: Run scanners against current market data
  private _executeScan(): Observable<{ execution: ScanExecution; symbol: string }> {
    return combineLatest([
      // Get current quotes for all configured symbols
      this._getCurrentQuotes(),
      // Get smart money data
      this._getSmartMoneyFlow(),
      // Get portfolio status
      this.portfolioService.getPositions()
    ]).pipe(
      map(([quotes, smartMoney, positions]) => {
        // Configure scan based on portfolio and smart money
        const activeConfigs = this._getActiveScanConfigs(smartMoney, positions);

        // Execute scanner for each symbol
        const scanEngine = new (await import('../scanner/scanEngine')).ScannerEngine;

        // In production, iterate through configured symbols
        const symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY'];

        return { quotes, smartMoney, positions, activeConfigs, symbols };
      }),
      mergeMap(({ quotes, smartMoney, positions, activeConfigs, symbols }) => {
        const results: ScanResult[] = [];

        // Execute scan for each symbol
        const scanPromises = symbols.map(symbol => this._scanSymbol(
          symbol, quotes[symbol], smartMoney, positions, activeConfigs
        ));

        return Promise.all(scanPromises).then(scanResults => {
          scanResults.forEach(result => {
            if (result) results.push(result);
          });

          return { results, symbols };
        });
      })
    );
  }

  private _scanSymbol(
    symbol: string,
    quote: Quote,
    smartMoney: any,
    positions: any[],
    activeConfigs: ScanConfig[]
  ): ScanResult | null {
    const scanEngine = new (await import('../scanner/scanEngine')).ScannerEngine;

    // Execute scan with configured filters
    // Filter to only active configs
    const activeFilters = activeConfigs.flatMap(c => c.filters).filter(f => f.id.startsWith('filter_'));

    return scanEngine.scanSymbol(symbol, activeFilters);
  }

  private _getCurrentQuotes(): Observable<Record<string, Quote>> {
    // Fetch quotes for key symbols
    const symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY'];
    const quoteObservables = symbols.map(symbol =>
      this.marketDataService.getQuote(symbol)
    );

    return combineLatest(quoteObservables).pipe(
      map(quotes => {
        const result: Record<string, Quote> = {};
        symbols.forEach((symbol, i) => {
          result[symbol] = quotes[i];
        });
        return result;
      })
    );
  }

  private _getSmartMoneyFlow(): Observable<any> {
    // Get latest smart money data
    // In production, would use the SmartMoneyTracker
    return of({ fiiNet: 0, diiNet: 0, bulkDeals: 0, blockDeals: 0 });
  }

  private _getActiveScanConfigs(smartMoney: any, positions: any[]): ScanConfig[] {
    // Start with default configs
    const configs = [...defaultScanConfigs];

    // Adjust based on smart money flow
    if (smartMoney.fiiNet > 100000000) { // > 10 crores FII buying
      configs.push({
        id: 'fii-bullish',
        name: 'FII Bullish Filter',
        description: 'Override scans with strong FII buying',
        symbols: ['RELIANCE', 'TCS', 'HDFCBANK'],
        filters: [/* FII-related filters */],
        timeframe: '1D',
        active: true,
        createdAt: new Date(),
        lastRun: null,
        resultsCount: 0
      });
    }

    return configs;
  }

  // _processExecution: Process scan results and manage positions
  private _processExecution(execution: { execution: ScanExecution; symbol: string }): Observable<any> {
    const { execution, symbol } = execution;

    return of(execution).pipe(
      mergeMap(exec => this._evaluateSignals(exec, symbol)),
      mergeMap(evaluation => this._manageRisk(evaluation, symbol)),
      mergeMap(riskDecision => this._executeProtections(riskDecision, symbol))
    );
  }

  // _evaluateSignals: Evaluate scan results against current positions
  private _evaluateSignals(execution: ScanExecution, symbol: string): any {
    const { results } = execution;
    const currentPosition = this.portfolioService.positions.find(
      p => p.symbol === symbol
    );

    const signalResults = results.map(result => ({
      symbol,
      signal: result.signalType,
      confidence: result.score,
      currentPrice: result.ltp,
      existingPosition: currentPosition?.quantity || 0,
      // Protection logic
      shouldEnter: this._shouldEnterPosition(result, currentPosition),
      shouldExit: this._shouldExitPosition(result, currentPosition),
      shouldTrailingStop: this._shouldActivateTrailingStop(currentPosition),
      recommendedAction: this._determineAction(result, currentPosition)
    }));

    return { signalResults, symbol };
  }

  // _shouldEnterPosition: Determine if we should enter a new position
  private _shouldEnterPosition(signal: ScanResult, existingPosition: number): boolean {
    // Don't enter if already have position
    if (existingPosition > 0) return false;

    // Check minimum confidence
    if (signal.score < this.config.minConfidenceScore) return false;

    // Check market hours (simplified)
    const now = new Date();
    const hour = now.getHours();
    // Market hours: 9:15 AM to 3:30 PM IST
    if (hour < 9 || hour >= 15) return false;

    return true;
  }

  // _shouldExitPosition: Determine if we should exit existing position
  private _shouldExitPosition(signal: ScanResult, existingPosition: number): boolean {
    // Must have existing position
    if (existingPosition === 0) return false;

    // Take profit if signal reverses
    if (signal.signalType === 'SELL' && existingPosition > 0) return true;
    if (signal.signalType === 'BUY' && existingPosition < 0) return true;

    // Check against trailing stop
    if (this._isTrailingStopTriggered(signal, existingPosition)) return true;

    // RSI extreme exit
    if (signal.indicatorValues?.rsi) {
      if (signal.indicatorValues.rsi > 70 && existingPosition > 0) return true; // Overbought exit
      if (signal.indicatorValues?.rsi < 30 && existingPosition < 0) return true; // Oversold exit
    }

    return false;
  }

  // _isTrailingStopTriggered: Check if trailing stop is triggered
  private _isTrailingStopTriggered(signal: ScanResult, positionQty: number): boolean {
    if (!this.config.trailingStopPercentage) return false;

    const priceChange = signal.ltp - (signal.timestamp ? 0 : 0); // Would need entry price
    // Simplified: if price moved favorably by trailing stop percentage
    return Math.abs(priceChange) / (signal.ltp || 1) * 100 >= this.config.trailingStopPercentage;
  }

  // _determineAction: Recommend action based on signal
  private _determineAction(signal: ScanResult, existingPosition: number): 'BUY' | 'SELL' | 'HOLD' | 'EXIT' {
    // Exit takes priority
    if (this._shouldExitPosition(signal, existingPosition)) return 'EXIT';

    // Enter if no position
    if (existingPosition === 0) {
      if (signal.signalType === 'BUY' && signal.score >= this.config.minConfidenceScore) return 'BUY';
      if (signal.signalType === 'SELL' && signal.score >= this.config.minConfidenceScore) return 'SELL';
    }

    // Hold if already in position and signal confirms
    if (existingPosition !== 0) {
      if (signal.score >= 70) return 'HOLD'; // Strong confirmation
    }

    return 'HOLD';
  }

  // _manageRisk: Apply risk management rules
  private _manageRisk(evaluation: any, symbol: string): Observable<any> {
    const { signalResults } = evaluation;
    const riskChecks = {
      positionLimit: this._checkPositionLimit(symbol),
      drawdownCheck: this._checkDrawdownLimit(),
      concentrationCheck: this._checkConcentrationRisk(symbol),
      marginCheck: this._checkMarginAvailability(symbol)
    };

    return of({ ...evaluation, riskChecks });
  }

  // _checkPositionLimit: Max position size per symbol
  private _checkPositionLimit(symbol: string): { withinLimit: boolean; currentValue: number; maxAllowed: number } {
    const position = this.portfolioService.positions.find(p => p.symbol === symbol);
    if (!position) return { withinLimit: true, currentValue: 0, maxAllowed: 0 };

    // Max 20% of portfolio per position
    const maxAllowed = 0.2; // 20% of total portfolio
    const currentValue = Math.abs(position.quantity * position.currentPrice);

    return {
      withinLimit: currentValue / 100000 < maxAllowed, // Simplified check
      currentValue,
      maxAllowed: maxAllowed * 100000 // In rupees
    };
  }

  // _checkDrawdownLimit: Overall drawdown circuit breaker
  private _checkDrawdownLimit(): { withinLimit: boolean; currentDrawdown: number; maxAllowed: number } {
    // In production, track equity curve
    const currentDrawdown = this.maxDrawdownObserved;
    const maxAllowed = this.config.maxDrawdownCutoff || 15; // 15% default

    return {
      withinLimit: currentDrawdown < maxAllowed,
      currentDrawdown,
      maxAllowed
    };
  }

  // _checkConcentrationRisk: Sector/portfolio concentration
  private _checkConcentrationRisk(symbol: string): { safe: boolean; current: number; limit: number } {
    // Check if adding this position would exceed sector limits
    return { safe: true, current: 0, limit: 0 };
  }

  // _checkMarginAvailable: Margin availability check
  private _checkMarginAvailable(symbol: string): { sufficient: boolean; required: number; available: number } {
    // In production, query broker for margin
    return { sufficient: true, required: 0, available: 0 };
  }

  // _executeProtections: Place protective orders based on decisions
  private _executeProtections(decision: any, symbol: string): Observable<any> {
    const { signalResults, riskChecks } = decision;
    const executions: any[] = [];

    // Process each signal result
    signalResults.forEach(signal => {
      const action = signal.recommendedAction;

      // Skip if HOLD
      if (action === 'HOLD') return;

      // Check risk limits
      if (!riskChecks.positionLimit.withinLimit) {
        console.log(`Position limit exceeded for ${symbol}`);
        return;
      }

      if (!riskChecks.drawdownCheck.withinLimit) {
        console.log(`Drawdown circuit breaker triggered`);
        return;
      }

      // Place protective order
      const orderRequest = this._buildOrderRequest(signal, action);

      if (orderRequest) {
        // Execute via order management
        // In production: this.orderManagement.placeOrder(orderRequest)
        executions.push({
          symbol,
          action,
          orderType: orderRequest.orderType,
          quantity: orderRequest.quantity,
          status: 'pending'
        });
      }
    });

    return of({ executions, symbol });
  }

  // _buildOrderRequest: Build order from signal decision
  private _buildOrderRequest(signal: ScanResult, action: 'BUY' | 'SELL'): any {
    // Determine quantity based on position size
    const capitalAtRisk = 0.1; // 10% of portfolio per trade
    const entryPrice = signal.ltp;
    const stopLoss = this._calculateStopLoss(signal, action);
    const target = this._calculateTarget(signal, action);

    return {
      symbol: signal.symbol,
      side: action,
      quantity: this._calculateQuantity(capitalAtRisk, entryPrice, stopLoss),
      orderType: 'SL-M', // Stop-loss market for protection
      productType: 'MIS', // Intraday for protection scans
      validity: 'DAY',
      price: action === 'BUY' ? undefined : undefined,
      triggerPrice: stopLoss,
      disclosedQuantity: 0
    };
  }

  // _calculateStopLoss: Calculate stop-loss based on method
  private _calculateStopLoss(signal: ScanResult, action: 'BUY' | 'SELL'): number {
    if (action === 'BUY') {
      // For buy: SL below current price
      if (this.config.stopLossMethod === 'percentage') {
        return signal.ltp * (1 - this.config.trailingStopPercentage / 100);
      } else if (this.config.stopLossMethod === 'atr') {
        // Would need ATR calculation from historical data
        return signal.ltp * 0.98; // 2% default
      } else {
        // Trailing
        return signal.ltp * (1 - (this.config.trailingStopPercentage || 5) / 100);
      }
    } else {
      // For sell: SL above current price
      if (this.config.stopLossMethod === 'percentage') {
        return signal.ltp * (1 + this.config.trailingStopPercentage / 100);
      } else {
        return signal.ltp * (1 + (this.config.trailingStopPercentage || 5) / 100);
      }
    }
  }

  // _calculateTarget: Calculate target price
  private _calculateTarget(signal: ScanResult, action: 'BUY' | 'SELL'): number {
    if (action === 'BUY') {
      // Target based on risk-reward ratio (default 2:1)
      const sl = this._calculateStopLoss(signal, 'BUY');
      const risk = signal.ltp - sl;
      return signal.ltp + (risk * 2); // 2:1 reward-to-risk
    } else {
      // For sell: target above current price
      const sl = this._calculateStopLoss(signal, 'SELL');
      const risk = sl - signal.ltp;
      return signal.ltp - (risk * 2); // 2:1 reward-to-risk
    }
  }

  // _calculateQuantity: Calculate order quantity based on capital at risk
  private _calculateQuantity(capitalAtRiskPct: number, entryPrice: number, stopPrice: number): number {
    // Risk per share = entry price - stop price
    const riskPerShare = Math.abs(entryPrice - stopPrice);

    // Total capital at risk (assume ₹10L portfolio for demo)
    const totalPortfolio = 1000000;
    const capitalAtRisk = totalPortfolio * capitalAtRiskPct;

    // Quantity = Capital at risk / Risk per share, rounded to lot size
    const quantity = Math.floor(capitalAtRisk / riskPerShare);

    return Math.max(1, quantity);
  }
}