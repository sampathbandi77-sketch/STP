/**
 * Integrated Stock Scanner - Combines all scanner types with profit protection
 * Real-time scanning with AI signals, smart money, and automatic protection
 */

import { Observable, of, interval, BehaviorSubject, combineLatest } from 'rxjs';
import { map, switchMap, mergeMap, filter, takeUntil } from 'rxjs/operators';
import { Quote, MarketDepth } from '../api/types';
import { MarketDataService } from '../trading/marketData';
import { ScannerEngine, ScanFilter, ScanConfig, ScanResult, defaultScanConfigs } from '../scanner/scanEngine';
import { ProfitProtectionEngine, ProfitProtectionConfig, ProtectionStatus } from './profitProtectionEngine';
import { AlertSystem, AlertConfig } from './alertSystem';

export interface IntegratedScanResult extends ScanResult {
  // Additional protection data
  protectionScore: number; // 0-100 how well it fits protection criteria
  recommendedAction: 'BUY' | 'SELL' | 'HOLD' | 'EXIT';
  suggestedStopLoss: number;
  suggestedTarget: number;
  suggestedQuantity: number;
  riskRewardRatio: number;
  smartMoneyImpact: 'strong-buy' | 'buy' | 'neutral' | 'sell' | 'strong-sell';
}

export interface ScanWithProtection {
  scanResult: IntegratedScanResult;
  protectionStatus: {
    maxDrawdownHit: boolean;
    positionLimitExceeded: boolean;
    marginSufficient: boolean;
    recommended: 'enter' | 'exit' | 'hold' | 'avoid';
  };
}

export class IntegratedScanner {
  private marketDataService: MarketDataService;
  private protectionEngine: ProfitProtectionEngine;
  private alertSystem: AlertSystem;
  private scanSubject = new BehaviorSubject<boolean>(false);
  private shutdown$ = new Subject<boolean>();

  constructor(
    marketDataService: MarketDataService,
    protectionEngine: ProfitProtectionEngine,
    alertSystem: AlertSystem
  ) {
    this.marketDataService = marketDataService;
    this.protectionEngine = protectionEngine;
    this.alertSystem = alertSystem;
  }

  // Start integrated scanning with protection
  start(): void {
    const scanInterval = interval(30000); // 30 seconds

    scanInterval.pipe(
      takeUntil(this.shutdown$),
      filter(() => !this.scanSubject.value),
      mergeMap(() => this._runIntegratedScan()),
      takeUntil(this.shutdown$)
    ).subscribe({
      next: (results) => {
        this._processScanResults(results);
      },
      error: (err) => {
        console.error('Integrated scan error:', err);
      }
    });

    this.scanSubject.next(true);
    console.log('Integrated Scanner started with protection');
  }

  stop(): void {
    this.scanSubject.next(false);
    this.shutdown$.next(true);
    console.log('Integrated Scanner stopped');
  }

  // _runIntegratedScan: Run scanner + apply protection logic
  private _runIntegratedScan(): Observable<ScanWithProtection> {
    return combineLatest([
      this._getCurrentMarketData(),
      this.protectionEngine['getScanHistory']?.() || of([]),
    ]).pipe(
      map(([quotes, scanHistory]) => this._analyzeWithProtection(quotes, scanHistory)),
    );
  }

  // _getCurrentMarketData: Fetch quotes for scanning
  private _getCurrentMarketData(): Observable<Record<string, Quote>> {
    const symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY'];
    const quoteObservables = symbols.map(symbol =>
      this.marketDataService.getQuote(symbol)
    );

    return combineLatest(quoteObservables).pipe(
      map(quotes => {
        const result: Record<string, Quote> = {};
        symbols.forEach((symbol, i) => {
          result[symbol] = quotes[i];
        });
        return result;
      })
    );
  }

  // _analyzeWithProtection: Analyze scans with protection logic
  private _analyzeWithProtection(quotes: Record<string, Quote>, scanHistory: any[]): ScanWithProtection {
    const symbol = 'RELIANCE'; // In production, iterate through all symbols
    const quote = quotes[symbol];

    if (!quote) {
      return this._emptyResult(symbol);
    }

    // 1. Run standard scanner
    const scanEngine = new (await import('../scanner/scanEngine')).ScannerEngine;

    // Use active filter configs
    const activeFilters = this._getActiveFilters();

    const scanResult: ScanResult | null = scanEngine.scanSymbol(symbol, activeFilters);

    // 2. Calculate protection metrics
    const currentPosition = this.protectionEngine['portfolioService']?.positions?.find(
      (p: any) => p.symbol === symbol
    );

    const protectionStatus = this._calculateProtectionStatus(scanResult, currentPosition, quote);

    // 3. Determine recommended action
    const recommendedAction = this._determineProtectedAction(
      scanResult,
      currentPosition,
      protectionStatus
    );

    // 4. Calculate suggested SL/Target
    const suggestedMetrics = this._calculateSuggestedMetrics(
      scanResult,
      currentPosition,
      signalType: 'BUY'
    );

    // 5. Calculate smart money impact
    const smartMoneyImpact = this._calculateSmartMoneyImpact(symbol);

    const integratedResult: IntegratedScanResult = {
      ...(scanResult || {
        id: 'scan_' + Date.now(),
        symbol,
        signalType: 'HOLD',
        confidence: 50,
        priceTarget: quote.ltp,
        stopLoss: quote.ltp,
        timeHorizon: 'MEDIUM',
        model: 'Ensemble-LSTM',
        features: ['RSI', 'MACD', 'Volume'],
        generatedAt: new Date(),
        description: 'No scan data available',
      }),
      protectionScore: protectionStatus.overallScore,
      recommendedAction,
      suggestedStopLoss: suggestedMetrics.stopLoss,
      suggestedTarget: suggestedMetrics.target,
      suggestedQuantity: suggestedMetrics.quantity,
      riskRewardRatio: suggestedMetrics.riskReward,
      smartMoneyImpact,
    };

    return {
      scanResult: integratedResult,
      protectionStatus,
    };
  }

  // _calculateProtectionStatus: Overall protection assessment
  private _calculateProtectionStatus(
    scanResult: ScanResult | null,
    currentPosition: any,
    quote: Quote
  ): {
    overallScore: number; // 0-100
    maxDrawdownHit: boolean;
    positionLimitExceeded: boolean;
    marginSufficient: boolean;
    recommended: 'enter' | 'exit' | 'hold' | 'avoid';
  } {
    let overallScore = 50; // Base score
    let maxDrawdownHit = false;
    let positionLimitExceeded = false;
    let marginSufficient = true;
    let recommended: 'enter' | 'exit' | 'hold' | 'avoid' = 'hold';

    // Check drawdown
    const drawdownCheck = this.protectionEngine['_checkDrawdownLimit']?.();
    if (drawdownCheck?.withinLimit === false) {
      overallScore -= 30;
      maxDrawdownHit = true;
      recommended = 'avoid';
    }

    // Check position limit
    const positionCheck = this.protectionEngine['_checkPositionLimit']?.(quote.symbol);
    if (positionCheck?.withinLimit === false) {
      overallScore -= 25;
      positionLimitExceeded = true;
      recommended = 'avoid';
    }

    // Check margin
    const marginCheck = this.protectionEngine['_checkMarginAvailable']?.(quote.symbol);
    if (marginCheck?.sufficient === false) {
      overallScore -= 15;
      marginSufficient = false;
    }

    // Adjust based on signal confidence
    if (scanResult) {
      overallScore += (scanResult.score - 50) * 0.5; // Scale based on confidence

      // If strong signal but protection says avoid, cap score
      if (recommended === 'avoid') {
        overallScore = Math.max(overallScore, 20);
      }
    }

    // If no position and strong signal, recommend enter
    if (!currentPosition && scanResult?.score >= 70 && recommended !== 'avoid') {
      recommended = 'enter';
    }
    // If have position and signal suggests exit
    else if (currentPosition && scanResult?.signalType === 'SELL') {
      recommended = 'exit';
    }
    // If have position and signal is strong hold
    else if (currentPosition && scanResult?.score >= 70) {
      recommended = 'hold';
    }

    // Ensure overall score is within 0-100
    overallScore = Math.max(0, Math.min(100, overallScore));

    return { overallScore, maxDrawdownHit, positionLimitExceeded, marginSufficient, recommended };
  }

  // _determineProtectedAction: Final action decision with protection
  private _determineProtectedAction(
    scanResult: ScanResult | null,
    currentPosition: any,
    protectionStatus: {
      overallScore: number;
      maxDrawdownHit: boolean;
      positionLimitExceeded: boolean;
      marginSufficient: boolean;
      recommended: 'enter' | 'exit' | 'hold' | 'avoid';
    }
  ): 'BUY' | 'SELL' | 'HOLD' | 'EXIT' {
    // Avoid takes absolute priority
    if (protectionStatus.recommended === 'avoid') return 'HOLD';

    // Exit if signal says sell and we have position
    if (currentPosition && currentPosition.quantity !== 0 && scanResult?.signalType === 'SELL') {
      return 'EXIT';
    }

    // Exit if max drawdown hit
    if (protectionStatus.maxDrawdownHit) {
      return 'EXIT';
    }

    // Enter if no position and strong signal
    if (!currentPosition && scanResult?.score >= 70 && protectionStatus.overallScore >= 60) {
      return 'BUY';
    }

    // Hold if already in position and signal confirms
    if (currentPosition && currentPosition.quantity !== 0 && scanResult?.score >= 60) {
      return 'HOLD';
    }

    return 'HOLD';
  }

  // _calculateSuggestedMetrics: Calculate SL, Target, Quantity
  private _calculateSuggestedMetrics(
    scanResult: ScanResult | null,
    currentPosition: any,
    signalType: 'BUY' | 'SELL'
  ): {
    stopLoss: number;
    target: number;
    quantity: number;
    riskReward: number;
  } {
    const quotePrice = 2510; // Would use actual quote
    const entryPrice = quotePrice;

    let stopLoss: number;
    let target: number;

    if (signalType === 'BUY') {
      // 2:1 risk-reward ratio
      const risk = 100; // 2% risk per trade
      stopLoss = entryPrice - risk;
      target = entryPrice + (risk * 2);
    } else {
      // For sell
      const risk = 100;
      stopLoss = entryPrice + risk;
      target = entryPrice - (risk * 2);
    }

    // Calculate quantity based on 1% capital at risk
    const totalCapital = 1000000; // Demo portfolio
    const capitalAtRisk = totalCapital * 0.01;
    const riskPerShare = Math.abs(entryPrice - stopLoss);
    const quantity = Math.max(1, Math.floor(capitalAtRisk / riskPerShare));

    return {
      stopLoss: Math.round(stopLoss),
      target: Math.round(target),
      quantity: quantity,
      riskReward: 2, // 2:1 ratio
    };
  }

  // _calculateSmartMoneyImpact: Assess institutional flow impact
  private _calculateSmartMoneyImpact(symbol: string): 'strong-buy' | 'buy' | 'neutral' | 'sell' | 'strong-sell' {
    // In production, would query smart money tracker
    // Mock based on symbol
    const impacts: Record<string, 'strong-buy' | 'buy' | 'neutral' | 'sell' | 'strong-sell'> = {
      RELIANCE: 'buy',
      TCS: 'neutral',
      HDFCBANK: 'strong-buy',
      INFY: 'sell',
      ICICIBANK: 'buy',
      SBIN: 'strong-buy',
      BANKNIFTY: 'neutral',
    };

    return impacts[symbol] || 'neutral';
  }

  // _getActiveFilters: Get active scan filters
  private _getActiveFilters(): ScanFilter[] {
    // Return active filter IDs from default configs
    return [
      // Basic filters that are always active
      { id: 'filter_rsi_oversold', name: 'RSI Oversold', description: 'RSI below 30', type: 'technical', operator: 'lt', value: 30, field: 'rsi' },
      { id: 'filter_volume_spike', name: 'Volume Spike', description: 'Volume above average', type: 'volume', operator: 'gte', value: 1.5, field: 'volume' },
    ];
  }

  // _emptyResult: Return empty scan result
  private _emptyResult(symbol: string): ScanWithProtection {
    return {
      scanResult: {
        id: 'scan_empty',
        symbol,
        signalType: 'HOLD',
        confidence: 0,
        priceTarget: 0,
        stopLoss: 0,
        timeHorizon: 'MEDIUM',
        model: 'No data',
        features: [],
        generatedAt: new Date(),
        description: 'No market data available',
        protectionScore: 0,
        recommendedAction: 'HOLD',
        suggestedStopLoss: 0,
        suggestedTarget: 0,
        suggestedQuantity: 0,
        riskRewardRatio: 0,
        smartMoneyImpact: 'neutral',
      },
      protectionStatus: {
        overallScore: 0,
        maxDrawdownHit: false,
        positionLimitExceeded: false,
        marginSufficient: true,
        recommended: 'avoid',
      },
    };
  }
}