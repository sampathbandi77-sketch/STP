/**
 * PriceDisplay Component - Real-time price with flash animation
 * Core trading component for showing live prices
 */

import React, { useEffect, useRef, useState } from 'react';
import { clsx } from 'clsx';

export interface PriceDisplayProps {
  price: number | string | null;
  previousPrice?: number | null;
  change?: number | null;
  changePercent?: number | null;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showChange?: boolean;
  showPercent?: boolean;
  flashDuration?: number;
  className?: string;
  'aria-label'?: string;
  decimals?: number;
  compact?: boolean;
}

const sizeStyles = {
  xs: 'text-xs mono',
  sm: 'text-sm mono',
  md: 'text-base mono',
  lg: 'text-lg mono tracking-mono',
  xl: 'text-xl mono tracking-mono font-medium',
  '2xl': 'text-2xl mono tracking-mono font-semibold',
};

const changeSizeStyles = {
  xs: 'text-xs',
  sm: 'text-xs',
  md: 'text-sm',
  lg: 'text-base',
  xl: 'text-lg',
  '2xl': 'text-xl',
};

export const PriceDisplay = React.forwardRef<HTMLDivElement, PriceDisplayProps>(
  (
    {
      price,
      previousPrice,
      change,
      changePercent,
      size = 'md',
      showChange = true,
      showPercent = true,
      flashDuration = 100,
      className,
      'aria-label': ariaLabel,
      decimals = 2,
      compact = false,
    },
    ref
  ) => {
    const [flashDirection, setFlashDirection] = useState<'up' | 'down' | null>(null);
    const prevPriceRef = useRef<number | null>(null);
    const flashTimeoutRef = useRef<NodeJS.Timeout>();

    const numericPrice = price !== null && price !== undefined ? Number(price) : null;
    const numericPrevPrice = previousPrice !== null && previousPrice !== undefined ? Number(previousPrice) : null;

    // Format price with proper decimals
    const formatPrice = (value: number | null): string => {
      if (value === null || value === undefined || isNaN(value)) return '--';
      return value.toLocaleString('en-IN', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      });
    };

    const formatChange = (value: number | null): string => {
      if (value === null || value === undefined || isNaN(value)) return '--';
      const sign = value >= 0 ? '+' : '';
      return `${sign}${value.toLocaleString('en-IN', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      })}`;
    };

    const formatPercent = (value: number | null): string => {
      if (value === null || value === undefined || isNaN(value)) return '--';
      const sign = value >= 0 ? '+' : '';
      return `${sign}${value.toFixed(2)}%`;
    };

    // Flash animation on price change
    useEffect(() => {
      if (numericPrice !== null && prevPriceRef.current !== null && numericPrice !== prevPriceRef.current) {
        const direction = numericPrice > prevPriceRef.current ? 'up' : 'down';
        setFlashDirection(direction);

        if (flashTimeoutRef.current) {
          clearTimeout(flashTimeoutRef.current);
        }
        flashTimeoutRef.current = setTimeout(() => {
          setFlashDirection(null);
        }, flashDuration);
      }

      if (numericPrice !== null) {
        prevPriceRef.current = numericPrice;
      }
    }, [numericPrice, flashDuration]);

    const isUp = change !== null && change !== undefined && change >= 0;
    const isDown = change !== null && change !== undefined && change < 0;
    const colorClass = isUp ? 'text-profit' : isDown ? 'text-loss' : 'text-text-primary';
    const flashClass = flashDirection === 'up' ? 'animate-price-flash-green' : flashDirection === 'down' ? 'animate-price-flash-red' : '';

    if (compact) {
      return (
        <div
          ref={ref}
          className={clsx(
            'inline-flex items-center gap-1 font-mono tabular-nums',
            sizeStyles[size],
            colorClass,
            flashClass,
            className
          )}
          aria-label={ariaLabel}
          role="status"
          aria-live="polite"
        >
          <span>{formatPrice(numericPrice)}</span>
          {showChange && change !== null && (
            <>
              <span className={clsx(changeSizeStyles[size], colorClass)}>
                {formatChange(change)}
              </span>
              {showPercent && changePercent !== null && (
                <span className={clsx(changeSizeStyles[size], colorClass, 'px-1.5 py-0.5 rounded text-[10px] font-medium')}>
                  {formatPercent(changePercent)}
                </span>
              )}
            </>
          )}
        </div>
      );
    }

    return (
      <div
        ref={ref}
        className={clsx(
          'flex flex-col items-start gap-0.5',
          className
        )}
        aria-label={ariaLabel}
      >
        <div className={clsx('font-mono tabular-nums', sizeStyles[size], colorClass, flashClass)}>
          {formatPrice(numericPrice)}
        </div>

        {(showChange || showPercent) && (change !== null || changePercent !== null)} && (
          <div className={clsx('flex items-center gap-1.5', colorClass)}>
            {showChange && change !== null && (
              <span className={clsx('font-mono tabular-nums', changeSizeStyles[size])}>
                {formatChange(change)}
              </span>
            )}
            {showPercent && changePercent !== null && (
              <span className={clsx('font-mono tabular-nums px-2 py-0.5 rounded text-[10px] font-medium', changeSizeStyles[size])}>
                {formatPercent(changePercent)}
              </span>
            )}
          </div>
        )
      </div>
    );
  }
);

PriceDisplay.displayName = 'PriceDisplay';

// Mini price display for watchlists
export interface MiniPriceProps {
  price: number | string | null;
  change?: number | null;
  changePercent?: number | null;
  size?: 'sm' | 'md';
  className?: string;
}

export const MiniPrice = ({ price, change, changePercent, size = 'sm', className }: MiniPriceProps) => {
  const numericPrice = price !== null && price !== undefined ? Number(price) : null;
  const isUp = change !== null && change !== undefined && change >= 0;
  const isDown = change !== null && change !== undefined && change < 0;
  const colorClass = isUp ? 'text-profit' : isDown ? 'text-loss' : 'text-text-secondary';

  return (
    <div className={clsx('flex flex-col items-end gap-0.5', className)}>
      <span className={clsx('font-mono tabular-nums', size === 'sm' ? 'text-sm' : 'text-base', colorClass)}>
        {numericPrice !== null ? numericPrice.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '--'}
      </span>
      <div className={clsx('flex items-center gap-1', colorClass)}>
        {change !== null && (
          <span className="font-mono text-xs">
            {change >= 0 ? '+' : ''}{change.toFixed(2)}
          </span>
        )}
        {changePercent !== null && (
          <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-bg-surface">
            {changePercent >= 0 ? '+' : ''}{changePercent.toFixed(2)}%
          </span>
        )}
      </div>
    </div>
  );
};