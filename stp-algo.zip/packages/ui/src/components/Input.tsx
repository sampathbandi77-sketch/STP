/**
 * Input Components - Form inputs with trading-specific variants
 */

import React, { forwardRef, InputHTMLAttributes, TextareaHTMLAttributes, SelectHTMLAttributes } from 'react';
import { clsx } from 'clsx';

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

const sizeStyles = {
  sm: 'h-8 px-3 text-xs',
  md: 'h-10 px-3 text-sm',
  lg: 'h-12 px-4 text-base',
};

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, helperText, leftIcon, rightIcon, size = 'md', fullWidth = true, className, id, ...props }, ref) => {
    const inputId = id || `input-${React.useId()}`;
    const errorId = error ? `${inputId}-error` : undefined;
    const helperId = helperText ? `${inputId}-helper` : undefined;

    return (
      <div className={clsx('w-full', fullWidth && 'w-full', className)}>
        {label && (
          <label htmlFor={inputId} className="block text-xs font-medium text-text-secondary mb-1.5">
            {label}
          </label>
        )}
        <div className="relative">
          {leftIcon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none flex items-center">
              {leftIcon}
            </div>
          )}
          <input
            ref={ref}
            id={inputId}
            className={clsx(
              'w-full bg-bg-surface border rounded-lg transition-all duration-fast',
              'text-text-primary placeholder:text-text-muted',
              'focus:outline-none focus:ring-2 focus:ring-blue-bright focus:border-transparent',
              'disabled:bg-bg-hover disabled:cursor-not-allowed disabled:opacity-50',
              'aria-invalid:focus:ring-red-loss aria-invalid:focus:border-red-loss',
              sizeStyles[size],
              leftIcon && 'pl-9',
              rightIcon && 'pr-9',
              error && 'border-red-loss bg-red-dim',
              !error && 'border-border-default hover:border-border-strong',
              props.readOnly && 'bg-bg-hover cursor-default'
            )}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={clsx(errorId, helperId)}
            {...props}
          />
          {rightIcon && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted flex items-center">
              {rightIcon}
            </div>
          )}
        </div>
        {error && (
          <p id={errorId} className="mt-1.5 text-xs text-red-bright flex items-center gap-1" role="alert">
            <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd"/></svg>
            {error}
          </p>
        )}
        {helperText && !error && (
          <p id={helperId} className="mt-1.5 text-xs text-text-muted">
            {helperText}
          </p>
        )}
      </div>
    );
  }
);
Input.displayName = 'Input';

// Number input with stepper for quantities
export interface NumberInputProps extends Omit<InputProps, 'type'> {
  min?: number;
  max?: number;
  step?: number;
  precision?: number;
  showStepper?: boolean;
  suffix?: string;
}

export const NumberInput = forwardRef<HTMLInputElement, NumberInputProps>(
  ({ min, max, step = 1, precision = 0, showStepper = true, suffix, size = 'md', className, ...props }, ref) => {
    const [value, setValue] = React.useState(props.defaultValue || props.value || '');

    const handleIncrement = () => {
      const current = parseFloat(value) || 0;
      const next = Math.min(current + step, max ?? Infinity);
      setValue(next.toFixed(precision));
      props.onChange?.({ target: { value: next.toFixed(precision) } } as React.ChangeEvent<HTMLInputElement>);
    };

    const handleDecrement = () => {
      const current = parseFloat(value) || 0;
      const next = Math.max(current - step, min ?? -Infinity);
      setValue(next.toFixed(precision));
      props.onChange?.({ target: { value: next.toFixed(precision) } } as React.ChangeEvent<HTMLInputElement>);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setValue(e.target.value);
      props.onChange?.(e);
    };

    return (
      <div className={clsx('relative', className)}>
        <Input
          ref={ref}
          type="number"
          min={min}
          max={max}
          step={step}
          size={size}
          value={value}
          onChange={handleChange}
          className={clsx(showStepper && 'pr-12', suffix && 'pr-8')}
          {...props}
        />
        {showStepper && (
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none">
            <button
              type="button"
              onClick={handleIncrement}
              className="h-5 w-5 flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-hover rounded text-[10px] pointer-events-auto"
              aria-label="Increment"
            >
              <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            </button>
            <button
              type="button"
              onClick={handleDecrement}
              className="h-5 w-5 flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-hover rounded text-[10px] pointer-events-auto -mt-1"
              aria-label="Decrement"
            >
              <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
            </button>
          </div>
        )}
        {suffix && (
          <span className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted text-xs pointer-events-none">
            {suffix}
          </span>
        )}
      </div>
    );
  }
);
NumberInput.displayName = 'NumberInput';

// Textarea
export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helperText?: string;
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, helperText, size = 'md', fullWidth = true, className, id, ...props }, ref) => {
    const textareaId = id || `textarea-${React.useId()}`;
    const errorId = error ? `${textareaId}-error` : undefined;
    const helperId = helperText ? `${textareaId}-helper` : undefined;

    const sizeStyles = {
      sm: 'p-2 text-xs',
      md: 'p-3 text-sm',
      lg: 'p-4 text-base',
    };

    return (
      <div className={clsx('w-full', fullWidth && 'w-full', className)}>
        {label && (
          <label htmlFor={textareaId} className="block text-xs font-medium text-text-secondary mb-1.5">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={textareaId}
          className={clsx(
            'w-full bg-bg-surface border rounded-lg transition-all duration-fast resize-y min-h-[80px]',
            'text-text-primary placeholder:text-text-muted',
            'focus:outline-none focus:ring-2 focus:ring-blue-bright focus:border-transparent',
            'disabled:bg-bg-hover disabled:cursor-not-allowed disabled:opacity-50',
            'aria-invalid:focus:ring-red-loss aria-invalid:focus:border-red-loss',
            sizeStyles[size],
            error && 'border-red-loss bg-red-dim',
            !error && 'border-border-default hover:border-border-strong'
          )}
          aria-invalid={error ? 'true' : 'false'}
          aria-describedby={clsx(errorId, helperId)}
          {...props}
        />
        {error && (
          <p id={errorId} className="mt-1.5 text-xs text-red-bright" role="alert">{error}</p>
        )}
        {helperText && !error && (
          <p id={helperId} className="mt-1.5 text-xs text-text-muted">{helperText}</p>
        )}
      </div>
    );
  }
);
Textarea.displayName = 'Textarea';

// Select
export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  helperText?: string;
  options: { value: string; label: string }[];
  placeholder?: string;
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, helperText, options, placeholder, size = 'md', fullWidth = true, className, id, ...props }, ref) => {
    const selectId = id || `select-${React.useId()}`;
    const errorId = error ? `${selectId}-error` : undefined;
    const helperId = helperText ? `${selectId}-helper` : undefined;

    const sizeStyles = {
      sm: 'h-8 px-3 text-xs',
      md: 'h-10 px-3 text-sm',
      lg: 'h-12 px-4 text-base',
    };

    return (
      <div className={clsx('w-full', fullWidth && 'w-full', className)}>
        {label && (
          <label htmlFor={selectId} className="block text-xs font-medium text-text-secondary mb-1.5">
            {label}
          </label>
        )}
        <div className="relative">
          <select
            ref={ref}
            id={selectId}
            className={clsx(
              'w-full bg-bg-surface border rounded-lg transition-all duration-fast appearance-none',
              'text-text-primary',
              'focus:outline-none focus:ring-2 focus:ring-blue-bright focus:border-transparent',
              'disabled:bg-bg-hover disabled:cursor-not-allowed disabled:opacity-50',
              'aria-invalid:focus:ring-red-loss aria-invalid:focus:border-red-loss',
              sizeStyles[size],
              'pr-10',
              error && 'border-red-loss bg-red-dim',
              !error && 'border-border-default hover:border-border-strong'
            )}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={clsx(errorId, helperId)}
            {...props}
          >
            {placeholder && <option value="" disabled>{placeholder}</option>}
            {options.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-text-muted">
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
          </div>
        </div>
        {error && (
          <p id={errorId} className="mt-1.5 text-xs text-red-bright" role="alert">{error}</p>
        )}
        {helperText && !error && (
          <p id={helperId} className="mt-1.5 text-xs text-text-muted">{helperText}</p>
        )}
      </div>
    );
  }
);
Select.displayName = 'Select';