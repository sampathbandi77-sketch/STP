/**
 * Order Entry Component - Advanced order placement interface
 */

import React, { useState, useRef, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { OrderRequest, OrderSide, OrderType, OrderValidity } from '@sampath/api';
import { OrderManagementService } from '@sampath/trading';
import { toast } from '@sampath/ui';

export interface OrderEntryProps {
  symbol: string;
  onOrderPlaced?: (order: OrderResponse) => void;
}

export const OrderEntry = ({ symbol, onOrderPlaced }: OrderEntryProps) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { data: positions } = useMarketStore.getState();

  // State for order fields
  const [side, setSide] = useState<OrderSide>('BUY');
  const [orderType, setOrderType] = useState<OrderType>('MARKET');
  const [quantity, setQuantity] = useState<string>('');
  const [price, setPrice] = useState<string>('');
  const [productType, setProductType] = useState<'CNC' | 'MIS' | 'CO' | 'BO'>('CNC');
  const [variety, setVariety] = useState<'BO' | 'CO' | 'NOPE'>('BO');
  const [disclosedQuantity, setDisclosedQuantity] = useState<string>('');

  // Form state
  const [validating, setValidating] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Get lot size or minimum quantity from positions
  const minQuantity = positions?.find(p => p.symbol === symbol)?.quantity
    ? Math.max(1, Math.floor(positions!.find(p => p.symbol === symbol)!.quantity / 10))
    : 1;

  // Validate order before placement
  const validateOrder = (): boolean => {
    if (!quantity || parseInt(quantity) <= 0) {
      setError('Quantity must be greater than 0');
      return false;
    }
    if (orderType === 'LIMIT' && (!price || parseFloat(price) <= 0)) {
      setError('Price required for limit orders');
      return false;
    }
    if (parseInt(quantity) > 100000) {
      setError('Quantity exceeds maximum limit');
      return false;
    }
    return true;
  };

  // Place order handler
  const handlePlaceOrder = async () => {
    if (!validateOrder()) return;

    setValidating(true);
    setError(null);

    const order: OrderRequest = {
      symbol,
      side,
      quantity: parseInt(quantity),
      price: orderType !== 'LIMIT' ? undefined : parseFloat(price),
      orderType,
      productType,
      variety,
      disclosedQuantity: disclosedQuantity ? parseInt(disclosedQuantity) : undefined,
    };

    try {
      const orderManagement = new (await import('@sampath/trading')).OrderManagementServiceImpl(
        // In production, inject real adapters
        {} as any, {} as any, {} as any
      );

      const response = await orderManagement.placeOrder(order);

      // Success
      setValidating(false);
      onOrderPlaced?.(response);
      toast({ title: `Order ${response.status.toLowerCase()} successfully` });

      // Refresh portfolio and quotes
      queryClient.invalidateQueries(['portfolio-positions']);
      queryClient.invalidateQueries(['market-quotes']);

      // Close modal or reset form
      setQuantity('');
      setPrice('');

    } catch (err: any) {
      setValidating(false);
      setError(err.message || 'Order placement failed');
      toast({ title: err.message || 'Order placement failed', variant: 'destructive' });
    }
  };

  // Handle side change
  const handleSideChange = (newSide: OrderSide) => {
    setSide(newSide);
    // Adjust price based on side for limit orders
  };

  // Handle order type change
  const handleOrderTypeChange = (newType: OrderType) => {
    setOrderType(newType);
    if (newType !== 'LIMIT') {
      setPrice('');
    }
  };

  // Handle product type change
  const handleProductTypeChange = (newProduct: 'CNC' | 'MIS' | 'CO' | 'BO') => {
    setProductType(newProduct);
    setVariety(newProduct === 'BO' ? 'BO' : 'CO');
  };

  // Auto-populate price for market orders (LTP)
  useEffect(() => {
    // In production: fetch LTP from WebSocket
    // For now, use a reasonable default
    if (orderType === 'MARKET' && !price) {
      setPrice('0');
    }
  }, [orderType, price]);

  return (
    <Card variant="elevated" padding="lg">
      <CardHeader>
        <CardTitle>Order Entry - {symbol}</CardTitle>
      </CardHeader>

      <CardContent>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <Select
            placeholder="Side"
            options={[
              { value: 'BUY', label: 'BUY' },
              { value: 'SELL', label: 'SELL' },
            ]}
            onChange={(e) => setSide(e.target.value as OrderSide)}
          />
          <Select
            placeholder="Order Type"
            options={[
              { value: 'MARKET', label: 'Market' },
              { value: 'LIMIT', label: 'Limit' },
              { value: 'SL', label: 'SL' },
              { value: 'SL-M', label: 'SL-M' },
            ]}
            onChange={(e) => handleOrderTypeChange(e.target.value as OrderType)}
          />

          <Input
            placeholder="Quantity"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            min={minQuantity}
            className="grid-col-1"
          />
          <Input
            placeholder="Price (for Limit/SL/SL-M)"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            type={orderType === 'LIMIT' ? 'number' : 'text'}
            className="grid-col-2"
          />

          <Select
            placeholder="Product"
            options={[
              { value: 'CNC', label: 'CNC (Delivery)' },
              { value: 'MIS', label: 'MIS (Intraday)' },
              { value: 'CO', label: 'CO (Cover Order)' },
              { value: 'BO', label: 'BO (Bracket Order)' },
            ]}
            onChange={(e) => handleProductTypeChange(e.target.value as 'CNC' | 'MIS' | 'CO' | 'BO')}
          />

          <Input
            placeholder="Disclosed Qty"
            value={disclosedQuantity}
            onChange={(e) => setDisclosedQuantity(e.target.value)}
            type="number"
            className="grid-col-2"
          />
        </div>

        {/* Order Summary */}
        <div className="mt-4 p-3 bg-bg-elevated rounded-lg">
          <div className="text-xs text-text-secondary mb-1">Order Summary</div>
          <div className="flex items-center justify-between">
            <span className="font-medium text-text-primary">{side} {quantity}</span>
            <span className="text-sm font-medium">{orderType}</span>
          </div>
          {orderType === 'LIMIT' && price && (
            <div className="mt-2 text-xs text-text-muted">Price: ₹{price}</div>
          )}
        </div>
      </CardContent>

      <CardFooter>
        <Button
          variant="primary"
          size="lg"
          disabled={validating}
          onClick={handlePlaceOrder}
        >
          {validating ? 'Placing Order...' : 'Place Order'}
        </Button>
        <Button
          variant="ghost"
          size="lg"
          onClick={() => {
            setQuantity('');
            setPrice('');
            setError(null);
          }}
        >
          Clear
        </Button>
      </CardFooter>
    </Card>
  );
};