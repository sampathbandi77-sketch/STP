/**
 * Tabs Component - Navigation tabs with multiple variants
 */

import React, { forwardRef, useState, HTMLAttributes } from 'react';
import { clsx } from 'clsx';

export interface TabItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  count?: number;
  disabled?: boolean;
}

export interface TabsProps extends HTMLAttributes<HTMLDivElement> {
  tabs: TabItem[];
  activeTab: string;
  onChange: (tabId: string) => void;
  variant?: 'line' | 'pill' | 'segmented' | 'underline';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  className?: string;
}

const variantStyles = {
  line: 'border-b border-border-subtle',
  pill: 'bg-bg-surface p-1 rounded-lg',
  segmented: 'bg-bg-surface p-1 rounded-lg',
  underline: '',
};

const tabStyles = {
  line: 'border-b-2 border-transparent hover:border-border-strong data-[active]:border-blue-bright',
  pill: 'rounded-md data-[active]:bg-bg-elevated data-[active]:shadow-sm data-[active]:text-text-primary',
  segmented: 'rounded-md data-[active]:bg-blue-info data-[active]:text-white',
  underline: 'relative data-[active]:text-blue-bright data-[active]:after:content-[""] data-[active]:after:absolute data-[active]:after:bottom-0 data-[active]:after:left-0 data-[active]:after:right-0 data-[active]:after:h-0.5 data-[active]:after:bg-blue-bright data-[active]:after:rounded-t',
};

const sizeStyles = {
  sm: 'px-3 py-1.5 text-xs',
  md: 'px-4 py-2 text-sm',
  lg: 'px-6 py-2.5 text-base',
};

export const Tabs = forwardRef<HTMLDivElement, TabsProps>(
  ({ tabs, activeTab, onChange, variant = 'line', size = 'md', fullWidth = false, className, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={clsx(
          'flex gap-1',
          variantStyles[variant],
          fullWidth && 'w-full',
          className
        )}
        role="tablist"
        {...props}
      >
        {tabs.map((tab) => (
          <button
            key={tab.id}
            role="tab"
            aria-selected={activeTab === tab.id}
            aria-controls={`${tab.id}-panel`}
            id={`${tab.id}-trigger`}
            disabled={tab.disabled}
            onClick={() => !tab.disabled && onChange(tab.id)}
            className={clsx(
              'flex items-center justify-center gap-1.5 font-medium transition-all duration-fast',
              'focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-bright focus-visible:ring-offset-2 focus-visible:ring-offset-bg-deep',
              'disabled:opacity-40 disabled:cursor-not-allowed',
              tabStyles[variant],
              sizeStyles[size],
              fullWidth && 'flex-1',
              activeTab === tab.id && 'data-[active]:true',
              tab.disabled && 'cursor-not-allowed'
            )}
            data-active={activeTab === tab.id}
          >
            {tab.icon && <span className="flex-shrink-0">{tab.icon}</span>}
            {tab.label}
            {tab.count !== undefined && tab.count > 0 && (
              <span className={clsx(
                'px-1.5 py-0.5 rounded-full text-[10px] font-medium',
                activeTab === tab.id
                  ? variant === 'segmented'
                    ? 'bg-white/20 text-white'
                    : 'bg-blue-info text-white'
                  : 'bg-bg-surface text-text-muted'
              )}>
                {tab.count > 99 ? '99+' : tab.count}
              </span>
            )}
          </button>
        ))}
        {children}
      </div>
    );
  }
);
Tabs.displayName = 'Tabs';

// Tab Panels
export interface TabPanelProps extends HTMLAttributes<HTMLDivElement> {
  tabId: string;
  activeTab: string;
  children: React.ReactNode;
}

export const TabPanel = forwardRef<HTMLDivElement, TabPanelProps>(
  ({ tabId, activeTab, children, className, ...props }, ref) => {
    if (activeTab !== tabId) return null;

    return (
      <div
        ref={ref}
        role="tabpanel"
        id={`${tabId}-panel`}
        aria-labelledby={`${tabId}-trigger`}
        className={clsx('animate-slide-up', className)}
        {...props}
      >
        {children}
      </div>
    );
  }
);
TabPanel.displayName = 'TabPanel';