/**
 * Option Chain Service
 * Fetches and displays option chains with Greeks and IV surface
 */

import { GreekValues, BlackScholes, OptionStrategy, OptionLeg, StrategyBuilder, defaultStrategies } from './greekCalculations';
import { Quote, MarketDepth } from '../api/types';
import { MarketDataService } from '../trading/marketData';

export interface OptionChainData {
  underlying: string;
  ltp: number;
  change: number;
  changePercent: number;
  expiry: string;
  strikes: OptionStrikeData[];
  greeks: GreekValues;
  ivSurface: {
    min: number;
    max: number;
    avg: number;
  };
  timestamp: number;
}

export interface OptionStrikeData {
  strike: number;
  call: OptionSideData;
  put: OptionSideData;
  oi: number;
  volume: number;
  iv: number;
}

export interface OptionSideData {
  ltp: number;
  change: number;
  changePercent: number;
  bid: number;
  ask: number;
  oi: number;
  volume: number;
}

export class OptionChainService {
  private marketDataService: MarketDataService;

  constructor(marketDataService: MarketDataService) {
    this.marketDataService = marketDataService;
  }

  // Fetch option chain for a symbol and expiry
  async getOptionChain(symbol: string, expiry: string): Promise<OptionChainData> {
    // In production, fetch from broker API
    // For now, generate mock option chain data

    const underlyingLtp = 18542; // Mock NIFTY LTP
    const change = 125;
    const changePercent = 0.68;

    // Generate strikes around ATM
    const strikes = this.generateStrikes(underlyingLtp, 100, 5); // 5 strikes each side

    // Calculate Greeks for at-the-money strike
    const atmStrike = strikes.find(s => s.strike === Math.round(underlyingLtp))!;
    const greekInputs = {
      underlyingPrice: underlyingLtp,
      strike: atmStrike.strike,
      daysToExpiration: 30,
      optionType: 'call',
    };
    const greeks = BlackScholes.calculateGreeks({
      ...greekInputs,
      price: atmStrike.call.ltp,
    });

    return {
      underlying: symbol,
      ltp: underlyingLtp,
      change,
      changePercent,
      expiry,
      strikes,
      greeks,
      ivSurface: {
        min: 15.2,
        max: 25.8,
        avg: 19.5,
      },
      timestamp: Date.now(),
    };
  }

  // Generate strike prices around underlying price
  private generateStrikes(underlyingPrice: number, range: number, count: number): OptionStrikeData[] {
    const strikes: OptionStrikeData[] = [];
    const step = range / (count * 2);

    for (let i = -count; i <= count; i++) {
      const strike = Math.round(underlyingPrice + i * step);
      if (strike > 0) {
        const callData = this.generateOptionSide('call', strike, underlyingPrice);
        const putData = this.generateOptionSide('put', strike, underlyingPrice);

        strikes.push({
          strike,
          call: callData,
          put: putData,
          oi: callData.oi + putData.oi,
          volume: callData.volume + putData.volume,
          iv: (callData.iv + putData.iv) / 2,
        });
      }
    }

    return strikes;
  }

  // Generate option side data (call or put)
  private generateOptionSide(optionType: 'call' | 'put', strike: number, underlyingPrice: number): OptionSideData {
    // Determine if ITM, ATM, or OTM
    const moneyness = (strike - underlyingPrice) / underlyingPrice;

    // Mock LTP based on moneyness
    const baseLTP = Math.max(0.5, 100 - Math.abs(moneyness * 100));
    const ltp = Math.round((baseLTP + Math.random() * 50) * 100) / 100;

    // Mock Greeks based on moneyness
    let delta, gamma, theta, vega;

    if (optionType === 'call') {
      if (moneyness > 0.05) { // ITM call
        delta = 0.7 + Math.random() * 0.3;
      } else if (moneyness < -0.05) { // OTM call
        delta = Math.random() * 0.3;
      } else { // ATM call
        delta = 0.5 + Math.random() * 0.2;
      }
      gamma = 0.02 + Math.random() * 0.02;
      theta = -2 + Math.random() * 2;
      vega = 5 + Math.random() * 5;
    } else {
      // Put
      if (moneyness < -0.05) { // ITM put
        delta = -0.7 - Math.random() * 0.3;
      } else if (moneyness > 0.05) { // OTM put
        delta = -Math.random() * 0.3;
      } else { // ATM put
        delta = -0.5 - Math.random() * 0.2;
      }
      gamma = 0.02 + Math.random() * 0.02;
      theta = -2 + Math.random() * 2;
      vega = 5 + Math.random() * 5;
    }

    const change = (Math.random() - 0.5) * 20;
    const changePercent = (change / ltp) * 100;
    const bid = Math.max(0.1, ltp * 0.95);
    const ask = ltp + Math.random() * 5;
    const oi = Math.floor(1000 + Math.random() * 50000);
    const volume = Math.floor(50 + Math.random() * 500);
    const iv = 15 + Math.random() * 20;

    return {
      ltp,
      change,
      changePercent,
      bid,
      ask,
      oi,
      volume,
      iv,
    };
  }

  // Scan for options opportunities
  async scanForOpportunities(symbol: string, expiry: string): Promise<{
    overpriced: OptionStrikeData[];
    underpriced: OptionStrikeData[];
    ivRank: number;
    activity: OptionStrikeData[];
  }> {
    const chain = await this.getOptionChain(symbol, expiry);
    const strikes = chain.strikes;

    const overpriced: OptionStrikeData[] = [];
    const underpriced: OptionStrikeData[] = [];
    const activity: OptionStrikeData[] = [];

    strikes.forEach(strike => {
      // Simple IV rank logic
      if (strike.iv > 22) {
        overpriced.push(strike);
      }
      if (strike.iv < 18) {
        underpriced.push(strike);
      }
      // High activity = high volume + open interest
      if (strike.volume > 500 || strike.oi > 10000) {
        activity.push(strike);
      }
    });

    return {
      overpriced,
      underpriced,
      ivRank: 45, // Mock IV rank
      activity,
    };
  }
}