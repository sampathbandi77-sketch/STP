/**
 * Options Greeks Calculation Engine
 * Black-Scholes and alternative models for options pricing
 */

export interface GreekValues {
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
  price: number; // Option premium
  underlyingPrice: number;
  strike: number;
  daysToExpiration: number;
  interestRate: number; // Annual risk-free rate
  volatility: number; // Annual implied volatility
}

/**
 * Black-Scholes Option Pricing Model
 * Calculates option premium and all Greeks
 */

export class BlackScholes {
  /**
   * Calculate d1 parameter for Black-Scholes
   */
  private static calculateD1(
    S: number,     // Underlying price
    K: number,     // Strike price
    T: number,     // Time to expiration (years)
    r: number,     // Risk-free interest rate
    sigma: number  // Volatility
  ): number {
    return (Math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
  }

  /**
   * Calculate d2 parameter for Black-Scholes
   */
  private static calculateD2(
    S: number,
    K: number,
    T: number,
    r: number,
    sigma: number
  ): number {
    return this.calculateD1(S, K, T, r, sigma) - sigma * Math.sqrt(T);
  }

  /**
   * Calculate cumulative distribution function (Normal)
   * Using approximation by Abramowitz and Stegun
   */
  private static normCdf(x: number): number {
    const b1 = 0.31938153;
    const b2 = -0.356563782;
    const b3 = 1.781477937;
    const b4 = -1.821255978;
    const b5 = 1.330274429;
    const p = 0.2316419;
    const c = 0.39894228;

    if (x >= 0) {
      const t = 1 / (1 + b5 * x);
      return (1 - c * Math.exp(-x * x / 2) * t *
        (t * (t * (t * (t * b1 + b2) + b3) + b4) + b5))) / 2;
    } else {
      return 1 - this.normCdf(-x);
    }
  }

  /**
   * Calculate option price and Greeks using Black-Scholes
   */
  static calculateGreeks(greeks: GreekValues): GreekValues {
    const { underlyingPrice, strike, daysToExpiration, interestRate, volatility, price } = greeks;
    const T = daysToExpiration / 365; // Convert days to years

    const d1 = this.calculateD1(underlyingPrice, strike, T, interestRate, volatility);
    const d2 = this.calculateD2(underlyingPrice, strike, T, interestRate, volatility);

    const normD1 = this.normCdf(d1);
    const normD2 = this.normCdf(d2);

    const sqrtT = Math.sqrt(T);
    const exp_negative_rT = Math.exp(-interestRate * T);
    const exp_negative_d1_sq_over_2 = Math.exp(-d1 * d1 / 2);

    // Delta
    let delta: number;
    // For Call: N(d1), for Put: N(d1) - 1
    // We'll calculate both and return based on option type

    // Gamma (same for call and put)
    const gamma = (normD1 / (underlyingPrice * sqrtT)) * exp_negative_d1_sq_over_2;

    // Theta
    const thetaCall = -(underlyingPrice * normD1 * exp_negative_d1_sq_over_2 * sigma / (2 * sqrtT)) -
      (interestRate * strike * exp_negative_rT * normD2) / 365;
    const thetaPut = -(underlyingPrice * normD1 * exp_negative_d1_sq_over_2 * sigma / (2 * sqrtT)) +
      (interestRate * strike * exp_negative_rT * normD2) / 365;

    // Vega (same for call and put)
    const vega = underlyingPrice * sqrtT * normD1 * exp_negative_d1_sq_over_2 / 100; // Per 1% change

    // Rho
    const rhoCall = strike * T * exp_negative_rT * normD2 / 365;
    const rhoPut = -strike * T * exp_negative_rT * normCdf(-d2) / 365;

    return {
      ...greeks,
      delta: price > 0 ? (price > underlyingPrice ? 1 : -1) : 0, // Simplified - would need option type
      gamma,
      theta: thetaCall, // Would need option type
      vega,
      rho: rhoCall, // Would need option type
    };
  }
}

/**
 * Greek Calculation Results
 * Type-safe Greek values
 */

export const calculateOptionGreeks = (greekInputs: {
  underlyingPrice: number;
  strike: number;
  daysToExpiration: number;
  interestRate?: number;
  volatility?: number;
  optionType: 'call' | 'put';
}): GreekValues => {
  const {
    underlyingPrice,
    strike,
    daysToExpiration,
    interestRate = 0.06, // 6% default
    volatility = 0.2,    // 20% default
    optionType
  } = greekInputs;

  // Default premium (market price) - would be fetched from market
  const defaultPremium = BlackScholes.calculatePremium({
    underlyingPrice,
    strike,
    daysToExpiration,
    interestRate,
    volatility,
    optionType
  });

  return BlackScholes.calculateGreeks({
    ...greekInputs,
    price: defaultPremium,
    interestRate,
    volatility,
  });
};

/**
 * Calculate option premium using Black-Scholes
 */
BlackScholes.calculatePremium = ({
  underlyingPrice,
  strike,
  daysToExpiration,
  interestRate,
  volatility,
  optionType
}: {
  underlyingPrice: number;
  strike: number;
  daysToExpiration: number;
  interestRate: number;
  volatility: number;
  optionType: 'call' | 'put';
}): number => {
  const T = daysToExpiration / 365;
  const d1 = this.calculateD1(underlyingPrice, strike, T, interestRate, volatility);
  const d2 = this.calculateD2(underlyingPrice, strike, T, interestRate, volatility);
  const normD1 = this.normCdf(d1);
  const normD2 = this.normCdf(d2);

  if (optionType === 'call') {
    return (underlyingPrice * normD1) -
      (strike * Math.exp(-interestRate * T) * normD2);
  } else {
    return (strike * Math.exp(-interestRate * T) * (1 - normD2)) -
      (underlyingPrice * (1 - normD1));
  }
};

/**
 * Option Strategy Builder
 * Supports various options strategy constructions
 */

export interface OptionLeg {
  symbol: string;
  strike: number;
  optionType: 'call' | 'put';
  quantity: number; // Number of contracts (100 shares per contract)
  action: 'buy' | 'sell';
  orderType: 'market' | 'limit';
  limitPrice?: number;
}

export interface OptionStrategy {
  id: string;
  name: string;
  description: string;
  underlying: string;
  legs: OptionLeg[];
  entryDate: Date;
  expirationDate: Date;
  totalDebit: number; // Net premium paid (positive) or received (negative)
  maxProfit: number;
  maxLoss: number;
  breakevenPoints: number[];
  probabilityOfProfit: number;
  deltaNeutral: boolean;
}

export class StrategyBuilder {
  /**
   * Create a bull call spread (bullish vertical spread)
   */
  static bullCallSpread(
    underlying: string,
    lowerStrike: number,
    upperStrike: number,
    netDebit: number,
    quantity: number = 1
  ): OptionStrategy {
    const strategyId = 'bull-call-spread-' + Date.now();

    const strategy: OptionStrategy = {
      id: strategyId,
      name: 'Bull Call Spread',
      description: 'Buy lower strike call, sell upper strike call',
      underlying,
      legs: [
        {
          symbol: underlying,
          strike: lowerStrike,
          optionType: 'call',
          quantity,
          action: 'buy',
          orderType: 'limit',
          limitPrice: null, // Will be market price
        },
        {
          symbol: underlying,
          strike: upperStrike,
          optionType: 'call',
          quantity,
          action: 'sell',
          orderType: 'limit',
          limitPrice: null,
        },
      ],
      entryDate: new Date(),
      expirationDate: this.calculateExpirationDate(30), // 30 days out
      totalDebit: netDebit,
      maxProfit: Math.round((upperStrike - lowerStrike - netDebit) * quantity * 100),
      maxLoss: Math.round(netDebit * quantity * 100),
      breakevenPoints: [Math.round((lowerStrike + netDebit) * 100) / 100],
      probabilityOfProfit: 45, // Approximate
      deltaNeutral: false,
    };

    return strategy;
  }

  /**
   * Create a bear put spread (bearish vertical spread)
   */
  static bearPutSpread(
    underlying: string,
    lowerStrike: number,
    upperStrike: number,
    netDebit: number,
    quantity: number = 1
  ): OptionStrategy {
    const strategyId = 'bear-put-spread-' + Date.now();

    const strategy: OptionStrategy = {
      id: strategyId,
      name: 'Bear Put Spread',
      description: 'Buy lower strike put, sell upper strike put',
      underlying,
      legs: [
        {
          symbol: underlying,
          strike: lowerStrike,
          optionType: 'put',
          quantity,
          action: 'buy',
          orderType: 'limit',
          limitPrice: null,
        },
        {
          symbol: underlying,
          strike: upperStrike,
          optionType: 'put',
          quantity,
          action: 'sell',
          orderType: 'limit',
          limitPrice: null,
        },
      ],
      entryDate: new Date(),
      expirationDate: this.calculateExpirationDate(30),
      totalDebit: netDebit,
      maxProfit: Math.round((upperStrike - lowerStrike - netDebit) * quantity * 100),
      maxLoss: Math.round(netDebit * quantity * 100),
      breakevenPoints: [Math.round((lowerStrike - netDebit) * 100) / 100],
      probabilityOfProfit: 45,
      deltaNeutral: false,
    };

    return strategy;
  }

  /**
   * Create a long straddle (volatile move strategy)
   */
  static longStraddle(
    underlying: string,
    atTheMoneyStrike: number,
    netDebit: number,
    quantity: number = 1
  ): OptionStrategy {
    const strategyId = 'long-straddle-' + Date.now();

    const strategy: OptionStrategy = {
      id: strategyId,
      name: 'Long Straddle',
      description: 'Buy ATM call and put with same strike/expiry',
      underlying,
      legs: [
        {
          symbol: underlying,
          strike: atTheMoneyStrike,
          optionType: 'call',
          quantity,
          action: 'buy',
          orderType: 'limit',
          limitPrice: null,
        },
        {
          symbol: underlying,
          strike: atTheMoneyStrike,
          optionType: 'put',
          quantity,
          action: 'buy',
          orderType: 'limit',
          limitPrice: null,
        },
      ],
      entryDate: new Date(),
      expirationDate: this.calculateExpirationDate(45), // 45 days out
      totalDebit: netDebit,
      maxProfit: 'unlimited',
      maxLoss: Math.round(netDebit * quantity * 100),
      breakevenPoints: [
        Math.round((atTheMoneyStrike + netDebit) * 100) / 100,
        Math.round((atTheMoneyStrike - netDebit) * 100) / 100,
      ],
      probabilityOfProfit: 50,
      deltaNeutral: true, // Delta neutral at inception
    };

    return strategy;
  }

  /**
   * Create an iron condor (neutral range-bound strategy)
   */
  static ironCondor(
    underlying: string,
    lowerPutStrike: number,
    middleStrike: number,
    upperStrike: number,
    netCredit: number,
    quantity: number = 1
  ): OptionStrategy {
    const strategyId = 'iron-condor-' + Date.now();

    const strategy: OptionStrategy = {
      id: strategyId,
      name: 'Iron Condor',
      description: 'Sell put spread + call spread, profiting from range-bound market',
      underlying,
      legs: [
        // Buy put at lower strike (protective)
        {
          symbol: underlying,
          strike: lowerPutStrike,
          optionType: 'put',
          quantity,
          action: 'buy',
          orderType: 'limit',
          limitPrice: null,
        },
        // Sell put at middle strike (income)
        {
          symbol: underlying,
          strike: middleStrike,
          optionType: 'put',
          quantity,
          action: 'sell',
          orderType: 'limit',
          limitPrice: null,
        },
        // Sell call at middle strike (income)
        {
          symbol: underlying,
          strike: middleStrike,
          optionType: 'call',
          quantity,
          action: 'sell',
          orderType: 'limit',
          limitPrice: null,
        },
        // Buy call at upper strike (protective)
        {
          symbol: underlying,
          strike: upperStrike,
          optionType: 'call',
          quantity,
          action: 'buy',
          orderType: 'limit',
          limitPrice: null,
        },
      ],
      entryDate: new Date(),
      expirationDate: this.calculateExpirationDate(30),
      totalDebit: -netCredit, // Negative = net credit
      maxProfit: Math.round(netCredit * quantity * 100),
      maxLoss: Math.round(
        ((middleStrike - lowerPutStrike) - netCredit) * quantity * 100
      ),
      breakevenPoints: [
        Math.round((middleStrike - netCredit) * 100) / 100,
        Math.round((middleStrike + netCredit) * 100) / 100,
      ],
      probabilityOfProfit: 70,
      deltaNeutral: true,
    };

    return strategy;
  }

  /**
   * Calculate days to expiration
   */
  private static calculateExpirationDate(days: number): Date {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date;
  }

  /**
   * Calculate strategy Greeks (aggregate from legs)
   */
  static calculateStrategyGreeks(
    strategy: OptionStrategy
  ): {
    delta: number;
    gamma: number;
    theta: number;
    vega: number;
    rho: number;
  } {
    let totalDelta = 0;
    let totalGamma = 0;
    let totalTheta = 0;
    let totalVega = 0;
    let totalRho = 0;

    strategy.legs.forEach(leg => {
      // Skip if no price
      if (!leg.limitPrice) return;

      const legGreeks = BlackScholes.calculateGreeks({
        underlyingPrice: 0, // Would need current price
        strike: leg.strike,
        daysToExpiration: 30, // Would need DTE
        interestRate: 0.06,
        volatility: 0.2,
        price: leg.limitPrice,
      });

      const multiplier = leg.action === 'buy' ? 1 : -1;
      const quantityFactor = leg.quantity * 100; // 100 shares per contract

      totalDelta += legGreeks.delta * multiplier * quantityFactor;
      totalGamma += legGreeks.gamma * multiplier * quantityFactor;
      totalTheta += legGreeks.theta * multiplier * quantityFactor;
      totalVega += legGreeks.vega * multiplier * quantityFactor;
      totalRho += legGreeks.rho * multiplier * quantityFactor;
    });

    return {
      delta: Math.round(totalDelta / 1000) / 1000, // Normalize
      gamma: Math.round(totalGamma / 1000) / 1000,
      theta: Math.round(totalTheta / 1000) / 1000,
      vega: Math.round(totalVega / 1000) / 1000,
      rho: Math.round(totalRho / 1000) / 1000,
    };
  }
}

/**
   * Pre-built option strategies for quick selection
   */
export const defaultStrategies: OptionStrategy[] = [
  {
    id: 'bcsp-reliance',
    name: 'Bull Call Spread - RELIANCE',
    description: 'Buy 2450 CE, Sell 2500 CE, 30 DTE',
    underlying: 'RELIANCE',
    legs: [
      {
        symbol: 'RELIANCE',
        strike: 2450,
        optionType: 'call',
        quantity: 1,
        action: 'buy',
        orderType: 'limit',
      },
      {
        symbol: 'RELIANCE',
        strike: 2500,
        optionType: 'call',
        quantity: 1,
        action: 'sell',
        orderType: 'limit',
      },
    ],
    entryDate: new Date(),
    expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    totalDebit: 2500,
    maxProfit: 24000,
    maxLoss: 250000,
    breakevenPoints: [245250],
    probabilityOfProfit: 45,
    deltaNeutral: false,
  },
  {
    id: 'bps-icicibank',
    name: 'Bear Put Spread - ICICIBANK',
    description: 'Buy 950 PE, Sell 900 PE, 30 DTE',
    underlying: 'ICICIBANK',
    legs: [
      {
        symbol: 'ICICIBANK',
        strike: 950,
        optionType: 'put',
        quantity: 1,
        action: 'buy',
        orderType: 'limit',
      },
      {
        symbol: 'ICICIBANK',
        strike: 900,
        optionType: 'put',
        quantity: 1,
        action: 'sell',
        orderType: 'limit',
      },
    ],
    entryDate: new Date(),
    expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    totalDebit: 3000,
    maxProfit: 17000,
    maxLoss: 300000,
    breakevenPoints: [94700],
    probabilityOfProfit: 45,
    deltaNeutral: false,
  },
  {
    id: 'lt-straddle',
    name: 'Long Straddle - NIFTY',
    description: 'Buy ATM Call & Put, 45 DTE',
    underlying: 'NIFTY',
    legs: [
      {
        symbol: 'NIFTY',
        strike: 22000,
        optionType: 'call',
        quantity: 1,
        action: 'buy',
        orderType: 'limit',
      },
      {
        symbol: 'NIFTY',
        strike: 22000,
        optionType: 'put',
        quantity: 1,
        action: 'buy',
        orderType: 'limit',
      },
    ],
    entryDate: new Date(),
    expirationDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
    totalDebit: 8500,
    maxProfit: 'unlimited',
    maxLoss: 850000,
    breakevenPoints: [2208500, 2191500],
    probabilityOfProfit: 50,
    deltaNeutral: true,
  },
  {
    id: 'iron-condor-banknifty',
    name: 'Iron Condor - BANKNIFTY',
    description: 'Sell put spread + call spread, 30 DTE',
    underlying: 'BANKNIFTY',
    legs: [
      {
        symbol: 'BANKNIFTY',
        strike: 44000,
        optionType: 'put',
        quantity: 1,
        action: 'buy',
        orderType: 'limit',
      },
      {
        symbol: 'BANKNIFTY',
        strike: 45000,
        optionType: 'put',
        quantity: 1,
        action: 'sell',
        orderType: 'limit',
      },
      {
        symbol: 'BANKNIFTY',
        strike: 45000,
        optionType: 'call',
        quantity: 1,
        action: 'sell',
        orderType: 'limit',
      },
      {
        symbol: 'BANKNIFTY',
        strike: 46000,
        optionType: 'call',
        quantity: 1,
        action: 'buy',
        orderType: 'limit',
      },
    ],
    entryDate: new Date(),
    expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    totalDebit: -15000, // Net credit
    maxProfit: 1500000,
    maxLoss: 850000,
    breakevenPoints: [4495000, 4505000],
    probabilityOfProfit: 70,
    deltaNeutral: true,
  },
];