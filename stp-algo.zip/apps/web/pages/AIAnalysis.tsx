/**
 * AI Analysis Page - ML signals, pattern recognition, market analysis
 */

import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { toast } from '@sampath/ui';
import { AISignal, SmartMoneyFlow, SignalGenerator, SmartMoneyTracker } from '@sampath/ai';
import { useMarketStore } from '@sampath/stores';
import { useTheme } from '@sampath/ui';

export const AIAnalysis = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: quotes } = useQuery({
    queryKey: ['market-quotes'],
    queryFn: async () => [],
    refetchInterval: 2000,
  });

  const { signals, setSignals } = useMarketStore.getState();
  const { flowData, setFlowData } = useMarketStore.getState();
  const { theme } = useTheme();

  // Initialize signal generator and smart money tracker
  useEffect(() => {
    const initAI = async () => {
      const queryClient = useQueryClient;

      // Generate signals for top symbols
      const topSymbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BANKNIFTY'];
      const signals = await queryClient.fetchQuery({
        queryKey: ['ai-signals', topSymbols],
        queryFn: async () => {
          // In production: use real SignalGenerator
          return [
            { id: 's1', symbol: 'RELIANCE', signalType: 'BUY', confidence: 82, priceTarget: 2650, stopLoss: 2450, timeHorizon: 'MEDIUM', model: 'Ensemble-LSTM', features: ['RSI', 'MACD', 'Volume'], generatedAt: new Date(), description: 'Bullish momentum with volume confirmation' },
            { id: 's2', symbol: 'TCS', signalType: 'HOLD', confidence: 65, priceTarget: 3600, stopLoss: 3300, timeHorizon: 'MEDIUM', model: 'Ensemble-LSTM', features: ['RSI', 'MACD'], generatedAt: new Date(), description: 'Sideways movement, waiting for direction' },
            { id: 's3', symbol: 'HDFCBANK', signalType: 'BUY', confidence: 78, priceTarget: 1650, stopLoss: 1520, timeHorizon: 'MEDIUM', model: 'Ensemble-LSTM', features: ['RSI', 'Volume'], generatedAt: new Date(), description: 'Strong institutional buying detected' },
            { id: 's4', symbol: 'INFY', signalType: 'SELL', confidence: 71, priceTarget: 1420, stopLoss: 1580, timeHorizon: 'MEDIUM', model: 'Ensemble-LSTM', features: ['RSI', 'MACD'], generatedAt: new Date(), description: 'Bearish momentum with rising volume' },
            { id: 's5', symbol: 'ICICIBANK', signalType: 'BUY', confidence: 85, priceTarget: 1050, stopLoss: 960, timeHorizon: 'MEDIUM', model: 'Ensemble-LSTM', features: ['RSI', 'MACD', 'Volume'], generatedAt: new Date(), description: 'Breakout pattern with high confidence' },
          ];
        },
        refetchInterval: 30000,
      });

      setSignals(signals);

      // Start smart money tracking
      const tracker = new SmartMoneyTracker(queryClient);
      await tracker.startTracking();
      tracker.onFlowChange((flow) => {
        setFlowData(prev => [...prev, flow]);
      });
    };

    initAI();
  }, [queryClient, setSignals, setFlowData, theme]);

  const handleRefresh = () => {
    queryClient.invalidateQueries(['market-quotes']);
    toast({ title: 'Analysis refreshed' });
  };

  const handleScanClick = () => {
    navigate('/scanner');
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader>
          <CardTitle>AI Market Analysis</CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleRefresh}>
              Refresh
            </Button>
            <Button variant="ghost" size="sm" onClick={handleScanClick}>
              Scanner
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {/* AI Signals Section */}
          <div className="mb-6">
            <div className="text-sm text-text-secondary mb-3">Top AI Signals</div>
            {signals.length === 0 ? (
              <div className="p-4 text-center">
                <svg className="mx-auto mb-3 h-12 w-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v6a2 2 0 002 2H5a2 2 0 00-2-2v-6m2-3a2 2 0 012 2h2a2 2 0 012 2v-3m-6 2l-3-3m6 3l3-3" /></svg>
                <h3 className="mb-2">No signals yet</h3>
                <p className="text-text-muted">AI analysis will appear here once market data is available</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {signals.map((signal) => (
                  <div key={signal.id} className="bg-bg-elevated rounded-lg p-3 border-l-4 border-{signal.signalType === 'BUY' ? 'green-profit' : signal.signalType === 'SELL' ? 'red-loss' : 'blue-info'}>
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-text-primary">{signal.symbol}</span>
                      <span className="text-xs font-medium">{signal.confidence}%</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={signal.signalType === 'BUY' ? 'text-green-profit' : signal.signalType === 'SELL' ? 'text-red-loss' : 'text-blue-info'}>
                        {signal.signalType}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-bg-surface">{signal.priceTarget?.toFixed(2) || '--'}</span>
                    </div>
                    <div className="text-[10px] text-sm font-medium mt-1">{signal.description}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Smart Money Section */}
          <div className="mt-6">
            <div className="text-sm text-text-secondary mb-3">Institutional Flow</div>
            {flowData.length === 0 ? (
              <div className="p-4 text-center text-text-muted">
                <svg className="mx-auto mb-3 h-12 w-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v6a2 2 0 002 2H5a2 2 0 00-2-2v-6m2-3a2 2 0 012 2h2a2 2 0 012 2v-3m-6 2l-3-3m6 3l3-3" /></svg>
                <p>No institutional flow data available</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Net FII</div>
                  <div className="font-medium text-green-profit">
                    +{flowData[flowData.length - 1]?.fiiBuy?.toLocaleString('en-IN') || '0'}
                  </div>
                </div>
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Net DII</div>
                  <div className="font-medium text-red-loss">
                    -{flowData[flowData.length - 1]?.diiSell?.toLocaleString('en-IN') || '0'}
                  </div>
                </div>
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Bulk Deals</div>
                  <div className="font-medium text-text-primary">
                    {flowData[flowData.length - 1]?.bulkDeals?.toLocaleString() || '0'}
                  </div>
                </div>
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Block Deals</div>
                  <div className="font-medium text-text-primary">
                    {flowData[flowData.length - 1]?.blockDeals?.toLocaleString() || '0'}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Pattern Recognition Section */}
          <div className="mt-6">
            <div className="text-sm text-text-secondary mb-3">Pattern Recognition</div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              <div className="bg-bg-elevated rounded-lg p-3">
                <div className="text-xs text-text-secondary mb-1">Head & Shoulders</div>
                <div className="text-sm font-medium text-red-loss">Bearish - 78% confidence</div>
              </div>
              <div className="bg-bg-elevated rounded-lg p-3">
                <div className="text-xs text-text-secondary mb-1">Cup & Handle</div>
                <div className="text-sm font-medium text-green-profit">Bullish - 82% confidence</div>
              </div>
              <div className="bg-bg-elevated rounded-lg p-3">
                <div className="text-xs text-text-secondary mb-1">Double Top</div>
                <div className="text-sm font-medium text-red-loss">Bearish - 65% confidence</div>
              </div>
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex justify-end">
          <Button variant="primary" onClick={handleRefresh}>
            Refresh Analysis
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};