/**
 * Main Dashboard Page - Trading Platform Dashboard
 * Shows real-time prices, portfolio summary, and quick actions
 */

import React, { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { Input } from '@sampath/ui';
import { Button } from '@sampath/ui';
import { Tabs, TabPanel, TabPanelProps } from '@sampath/ui';
import { useTheme } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { toast } from '@sampath/ui';

export const Dashboard = () => {
  const navigate = useNavigate();
  const { data: quotes } = useQuery({
    queryKey: ['dashboard-quotes'],
    queryFn: async () => {
      // In production, this would fetch from WebSocket via API
      return [];
    },
    refetchInterval: 500, // 200ms updates
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  const portfolioSummary = useMarketStore(state => state.portfolioSummary);
  const watchlist = useMarketStore(state => state.watchlist);

  const handleScanClick = () => {
    navigate('/scanner');
  };

  const handlePortfolioClick = () => {
    navigate('/portfolio');
  };

  const handleWatchlistClick = () => {
    navigate('/watchlist');
  };

  useEffect(() => {
    // Initialize WebSocket connection for real-time data
    initWebSocket();
  }, []);

  const initWebSocket = () => {
    // Mock WebSocket initialization
    // In production: connect to broker WebSocket for live data
    console.log('WebSocket initialized for real-time market data');
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle>SAMPATH PRO MAX Dashboard</CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleScanClick}>
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a4 4 0 11-8 0 4 4 0 018 0m6.364-7.364l-.707-.707M10 7h2m4-10v10a2 2 0 002 2h2m-6 2v3a1 1 0 001 1h4a1 1 0 001-1v-3M5 11h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v2" />
              </svg>
              Scan
            </Button>
            <Button variant="ghost" size="sm" onClick={handlePortfolioClick}>
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              Portfolio
            </Button>
            <Button variant="ghost" size="sm" onClick={handleWatchlistClick}>
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6m2-3a2 2 0 012 2h2a2 2 0 012 2v-3m-6 2l-3-3m6 3l3-3" />
              </svg>
              Watchlist
            </Button>
          </div>
        </CardHeader>

        {/* Portfolio Summary */}
        <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <div>
            <div className="text-text-sm text-text-secondary mb-1">Total Portfolio Value</div>
            <div className="font-2xl font-bold text-text-primary">₹{portfolioSummary.totalValue.toLocaleString('en-IN')}</div>
            <div className="text-green-profit font-medium">+{portfolioSummary.todayPnL.toLocaleString('en-IN')} (+{portfolioSummary.todayPnLPercent.toFixed(2)}%)</div>
          </div>

          <div>
            <div className="text-text-sm text-text-secondary mb-1">Cash Balance</div>
            <div className="font-2xl font-bold text-text-primary">₹{portfolioSummary.cashBalance.toLocaleString('en-IN')}</div>
          </div>

          <div>
            <div className="text-text-sm text-text-secondary mb-1">Today's P&L</div>
            <div className="font-medium {portfolioSummary.todayPnL >= 0 ? 'text-green-profit' : 'text-red-loss'}">
              {portfolioSummary.todayPnL >= 0 ? '+' : ''}{portfolioSummary.todayPnL.toFixed(2)}
            </div>
          </div>
        </CardContent>

        {/* Quick Actions */}
        <div className="mt-6 grid grid-cols-2 gap-3">
          <Button variant="primary" size="sm" onClick={handlePortfolioClick}>
            View Full Portfolio
          </Button>
          <Button variant="secondary" size="sm" onClick={handleWatchlistClick}>
            View Watchlist
          </Button>
          <Button variant="secondary" size="sm" onClick={handleScanClick}>
            Stock Scanner
          </Button>
          <Button variant="ghost" size="sm">
            Options
          </Button>
        </div>
      </Card>
    </div>
  );
};