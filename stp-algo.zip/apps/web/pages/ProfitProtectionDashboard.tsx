/**
 * Profit Protection Dashboard - Complete view and control center
 * Shows real-time scanning, alerts, risk status, and protection actions
 */

import React, { useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { toast } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { useTheme } from '@sampath/ui';
import { ProfitProtectionEngine, ProfitProtectionConfig, ProtectionStatus, IntegratedScanResult } from '@sampath/protection';
import { AlertSystem, AlertConfig } from '@sampath/protection';

export const ProfitProtectionDashboard = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { theme } = useTheme();
  const { data: quotes } = useMarketStore.getState();

  // State
  const [config, setConfig] = useState<ProfitProtectionConfig>({
    enabledScanners: ['gainers', 'oversold', 'breakout'],
    scanInterval: 30000,
    autoExecute: true,
    minConfidenceScore: 70,
    priceAlerts: true,
    aiSignalAlerts: true,
    smartMoneyAlerts: true,
    volumeAlerts: true,
    maxPositionSize: 20,
    maxDrawdownCutoff: 15,
    stopLossMethod: 'percentage' as 'percentage' | 'atr' | 'trailing',
    trailingStopPercentage: 5,
    preferredBroker: 'auto',
    confirmBeforeExecution: true,
    timeZone: 'Asia/Calcutta',
  });

  const [alertConfig, setAlertConfig] = useState<AlertConfig>({
    priceAlerts: true,
    aiSignalAlerts: true,
    smartMoneyAlerts: true,
    volumeAlerts: true,
    trailingStopAlerts: true,
    breachAlerts: true,
    sound: true,
    desktopNotifications: true,
  });

  const [status, setStatus] = useState<ProtectionStatus>({
    isScanning: false,
    lastScan: null,
    lastSignal: null,
    activePositions: 0,
    totalCapitalAtRisk: 0,
    maxDrawdownHit: false,
    tradingPaused: false,
    nextScanAt: new Date(),
  });

  const [activeScans, setActiveScans] = useState<Map<string, IntegratedScanResult>>(new Map());

  // Initialize protection engine and alert system
  useEffect(() => {
    // In production, inject real dependencies
    // const protectionEngine = new ProfitProtectionEngine(
    //   marketDataService,
    //   orderManagement,
    //   portfolioService,
    //   smartMoneyTracker,
    //   config
    // );
    // const alertSystem = new AlertSystemImpl(alertConfig);
    // protectionEngine.start();
    // alertSystem.subscribe(alert => toast({ title: alert.title, description: alert.description }));

    console.log('Profit Protection Dashboard initialized');
    console.log('Config:', config);
    console.log('Alert Config:', alertConfig);

    // Simulate starting
    setStatus(prev => ({
      ...prev,
      isScanning: true,
      lastScan: new Date(),
      nextScanAt: new Date(Date.now() + 30000),
    }));
  }, [config, alertConfig, quotes]);

  // Refresh status
  const handleRefresh = () => {
    queryClient.invalidateQueries(['market-quotes']);
    toast({ title: 'Protection data refreshed' });
  };

  // Toggle scanning
  const handleToggleScan = () => {
    // In production: protectionEngine.togglePause()
    setStatus(prev => ({
      ...prev,
      isScanning: !prev.isScanning,
      tradingPaused: !prev.tradingPaused,
    }));
  };

  // Add price alert
  const handleAddPriceAlert = (symbol: string, triggerPrice: number, type: 'above' | 'below') => {
    // alertSystem.triggerPriceAlert(symbol, triggerPrice, type);
    toast({ title: `Price alert set: ₹${triggerPrice} ${type}` });
  };

  // Add trailing stop
  const handleSetTrailingStop = (symbol: string, percentage: number) => {
    // config.trailingStopPercentage = percentage;
    // setConfig(prev => ({ ...prev, trailingStopPercentage }));
    toast({ title: `Trailing stop set: ${percentage}%` });
  };

  // Emergency stop
  const handleEmergencyStop = () => {
    // protectionEngine.stop();
    // setStatus(prev => ({ ...prev, tradingPaused: true }));
    toast({ title: 'Emergency stop activated' });
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Profit Protection System</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant={status.isScanning ? 'destructive' : 'primary'}
              size="sm"
              onClick={handleToggleScan}
            >
              {status.isScanning ? 'Pause Protection' : 'Start Protection'}
            </Button>
            <Button variant="ghost" size="sm" onClick={handleEmergencyStop}>
              🛑 Emergency
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {/* Status Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-6">
            <div>
              <div className="text-xs text-text-secondary mb-1">Scanning</div>
              <div className={status.isScanning ? 'font-medium text-green-profit' : 'font-medium text-red-loss'}>
                {status.isScanning ? 'Active' : 'Paused'}
              </div>
            </div>
            <div>
              <div className="text-xs text-text-secondary mb-1">Active Positions</div>
              <div className="font-medium text-text-primary">{status.activePositions}</div>
            </div>
            <div>
                <div className="text-xs text-text-secondary mb-1">Capital at Risk</div>
                <div className="font-medium text-text-primary">
                  {status.totalCapitalAtRisk.toFixed(1)}%
                </div>
              </div>
              <div>
                <div className="text-xs text-text-secondary mb-1">Max Drawdown</div>
                <div className={status.maxDrawdownHit ? 'font-medium text-red-loss' : 'font-medium text-green-profit'}>
                  {status.maxDrawdownHit ? 'HIT - Trading paused' : `${status.totalCapitalAtRisk.toFixed(1)}%`}
                </div>
              </div>
            </div>
            <div>
              <div className="text-xs text-text-secondary mb-1">Next Scan</div>
              <div className="font-medium text-text-primary">
                {status.nextScanAt.toLocaleTimeString()}
              </div>
            </div>
          </div>

          {/* Active Signals */}
          {status.isScanning && status.lastSignal && (
            <div className="mb-4 p-3 bg-bg-elevated rounded-lg">
              <div className="text-sm text-text-secondary mb-2">Last Scan Signal</div>
              <div className={`font-medium ${status.lastSignal.signalType === 'BUY' ? 'text-green-profit' : status.lastSignal.signalType === 'SELL' ? 'text-red-loss' : 'text-blue-info'}`}>
                {status.lastSignal.signalType}: {status.lastSignal.symbol} ({status.lastSignal.score}% confidence)
              </div>
              <div className="text-xs text-text-muted mt-1">
                {status.lastSignal.description || ''}
              </div>
              <div className="mt-2">
                <Button variant="outline" size="sm" onClick={() => navigate('/options')}>
                  Review Signal
                </Button>
              </div>
            </div>
          )}

          {/* Scanned Symbols */}
          <div>
            <div className="text-sm text-text-secondary mb-2">Scanned Symbols</div>
            <div className="grid grid-cols-2 gap-2">
              {[...activeScans.keys()].map(symbol => (
                <div key={symbol} className="p-2 bg-bg-elevated rounded-lg text-center">
                  <div className="font-medium text-text-primary">{symbol}</div>
                  <div className="text-[10px]">{activeScans.get(symbol)?.recommendedAction || 'HOLD'}</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>

        <CardFooter className="pt-3">
          <div className="grid grid-cols-2 gap-3 text-xs text-text-secondary">
            <div>
              <span>Scan Interval</span>
              <span>{config.scanInterval / 1000}s</span>
            </div>
            <div>
              <span>Min Confidence</span>
              <span>{config.minConfidenceScore}%</span>
            </div>
            <div>
              <span>Max Position</span>
              <span>{config.maxPositionSize}%</span>
            </div>
            <div>
              <span>Trailing SL</span>
              <span>{config.trailingStopPercentage}%</span>
            </div>
          </div>

          <div className="mt-2 pt-2 border-t border-border-subtle">
            <Button variant="secondary" size="sm" onClick={handleRefresh}>
              Refresh
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setConfig(prev => ({ ...prev, scanInterval: prev.scanInterval === 30000 ? 60000 : 30000 }))}>
              {config.scanInterval / 1000}s → {config.scanInterval === 60000 ? '1m' : '30s'}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};