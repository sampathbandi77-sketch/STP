/**
 * Options Analytics Page - Option chain, Greeks, strategy builder
 */

import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { toast } from '@sampath/ui';
import { OptionChainService, OptionChainData, OptionStrikeData, defaultStrategies, StrategyBuilder, GreekValues, BlackScholes } from '@sampath/options';
import { useMarketStore } from '@sampath/stores';
import { useTheme } from '@sampath/ui';

export const OptionsAnalytics = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: quotes } = useMarketStore.getState();
  const { theme } = useTheme();

  // State
  const [symbol, setSymbol] = useState('NIFTY');
  const [expiry, setExpiry] = useState('2024-12-26');
  const [strike, setStrike] = useState('18500');
  const [optionType, setOptionType] = useState<'call' | 'put'>('call');
  const [showGreeks, setShowGreeks] = useState<boolean>(true);
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);

  // Fetch option chain
  const { data: optionChain, isLoading } = useQuery({
    queryKey: ['option-chain', symbol, expiry],
    queryFn: async () => {
      const service = new OptionChainService({} as any); // In production: inject real service
      return await service.getOptionChain(symbol, expiry);
    },
    refetchInterval: 5000,
  });

  // Calculate Greeks for selected strike
  const calculateSelectedGreeks = () => {
    if (!optionChain?.strikes) return {};

    const selectedStrike = optionChain.strikes.find(s => String(s.strike) === strike);
    if (!selectedStrike) return {};

    const greekInputs = {
      underlyingPrice: optionChain.ltp,
      strike: Number(strike),
      daysToExpiration: 30,
      optionType,
    };

    return BlackScholes.calculateGreeks(greekInputs);
  };

  // Execute strategy
  const executeStrategy = (strategyId: string) => {
    const strategy = defaultStrategies.find(s => s.id === strategyId);
    if (strategy) {
      setSelectedStrategy(strategyId);
      toast({ title: `Strategy: ${strategy.name} selected` });
    }
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Options Analytics - {symbol}</CardTitle>
          <div className="flex items-center gap-2">
            <Select
              placeholder="Symbol"
              options={['NIFTY', 'BANKNIFTY', 'RELIANCE', 'TCS', 'HDFCBANK'].map(s => ({ value: s, label: s }))}
              onChange={(e) => setSymbol(e.target.value)}
            />
            <Select
              placeholder="Expiry"
              options={['2024-12-26', '2025-01-30', '2025-02-27'].map(e => ({ value: e, label: e }))}
              onChange={(e) => setExpiry(e.target.value)}
            />
            <Button variant="ghost" size="sm" onClick={() => executeStrategy('bcsp-reliance')}>
              Bull Call Spread
            </Button>
            <Button variant="ghost" size="sm" onClick={() => executeStrategy('bps-icicibank')}>
              Bear Put Spread
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {/* Option Chain Table */}
          {isLoading ? (
            <div className="h-64 flex items-center justify-center">Loading option chain...</div>
          ) : optionChain && optionChain.strikes.map((strike, index) => (
            <div key={index} className="bg-bg-elevated rounded-lg p-4 border-b border-border-subtle">
              <div className="flex items-center justify-between">
                <span className="font-medium text-text-primary">{strike.strike}</span>
                <div>
                  <PriceDisplay price={strike.call.ltp.toString()} className="text-green-profit" flashDuration={50} />
                  <PriceDisplay price={strike.put.ltp.toString()} className="text-red-loss" flashDuration={50} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-text-muted mt-2">
                <div>
                  <div>Call OI</div>
                  <div>{strike.call.oi.toLocaleString()}</div>
                </div>
                <div>
                  <div>Put OI</div>
                  <div>{strike.put.oi.toLocaleString()}</div>
                </div>
                <div>
                  <div>Call Vol</div>
                  <div>{strike.call.volume.toLocaleString()}</div>
                </div>
                <div>
                  <div>Put Vol</div>
                  <div>{strike.put.volume.toLocaleString()}</div>
                </div>
              </div>

              <div className="mt-2 flex items-center gap-2">
                <span className="text-[10px] px-2 py-1 rounded bg-bg-surface">
                  {strike.iv.toFixed(1)}% IV
                </span>
                <span className="text-[10px] px-2 py-1 rounded bg-bg-surface">
                  {strike.call.changePercent >= 0 ? '+' : ''}{strike.call.changePercent.toFixed(1)}%
                </span>
                <span className="text-[10px] px-2 py-1 rounded bg-bg-surface">
                  {strike.put.changePercent >= 0 ? '+' : ''}{strike.put.changePercent.toFixed(1)}%
                </span>
              </div>
            </div>
          ))}

          {/* Greeks Panel */}
          {showGreeks && optionChain && !isLoading && (
            <div className="mt-6 p-4 bg-bg-elevated rounded-lg">
              <div className="text-sm text-text-secondary mb-3">Greeks Analysis</div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-xs text-text-secondary">Delta</div>
                  <div className="font-medium {optionChain.greeks.delta > 0 ? 'text-green-profit' : 'text-red-loss'}">
                    {optionChain.greeks.delta.toFixed(3)}
                  </div>
                  <small>Rate of change w.r.t. underlying</small>
                </div>
                <div>
                  <div className="text-xs text-text-secondary">Gamma</div>
                  <div className="font-medium text-blue-info">
                    {optionChain.greeks.gamma.toFixed(3)}
                  </div>
                  <small>Rate of change of delta</small>
                </div>
                <div>
                  <div className="text-xs text-text-secondary">Theta</div>
                  <div className="font-medium {optionChain.greeks.theta < 0 ? 'text-red-loss' : 'text-green-profit'}">
                    {optionChain.greeks.theta.toFixed(2)}
                  </div>
                  <small>Time decay per day</small>
                </div>
                <div>
                  <div className="text-xs text-text-secondary">Vega</div>
                  <div className="font-medium text-purple-ai">
                    {optionChain.greeks.vega.toFixed(2)}
                  </div>
                  <small>Change per 1% IV change</small>
                </div>
                <div>
                  <div className="text-xs text-text-secondary">Rho</div>
                  <div className="font-medium text-amber-warn">
                    {optionChain.greeks.rho.toFixed(2)}
                  </div>
                  <small>Change per 1% rate change</small>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-border-subtle">
                <div className="text-xs text-text-secondary">Premium</div>
                <div className="font-medium text-text-primary">₹{optionChain.greeks.price.toFixed(2)}</div>
                <div className="text-xs text-text-muted">Based on Black-Scholes model</div>
              </div>
            </div>
          )}

          {/* Strategy Builder */}
          <div className="mt-6">
            <div className="text-sm text-text-secondary mb-3">Quick Strategies</div>
            <div className="grid grid-cols-2 gap-2">
              {defaultStrategies.map((strategy) => (
                <Button
                  key={strategy.id}
                  variant="outline"
                  size="sm"
                  onClick={() => executeStrategy(strategy.id)}
                >
                  {strategy.name.split(' - ')[0]}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>

        <CardFooter>
          <div className="text-xs text-text-muted">
            Last updated: just now
          </div>
          <Button variant="secondary" onClick={() => queryClient.invalidateQueries(['option-chain'])}>
            Refresh
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};