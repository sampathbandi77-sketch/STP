/**
 * Chart Page - Advanced charting with technical indicators
 */

import React, { useEffect, useRef, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { useTheme } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { createChart, addMovingAverage, addBollingerBands, addRSI, TechnicalIndicators, ChartTechnicalIndicators, ChartEvent, ChartClickEvent, ChartZoomEvent, TechnicalIndicators as BaseIndicators } from '@sampath/charting';
import { QuoteService } from '@sampath/api';
import { toast } from '@sampath/ui';

export const ChartPage = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: quotes } = useQuery({
    queryKey: ['market-quotes'],
    queryFn: async () => [],
    refetchInterval: 2000,
  });

  const { theme } = useTheme();
  const chartRef = useRef<HTMLElement | null>(null);
  const rsiRef = useRef<HTMLElement | null>(null);

  const [symbol, setSymbol] = useState('NIFTY');
  const [timeframe, setTimeframe] = useState<'1Min' | '5Min' | '15Min' | '1H' | '1D'>('1D');
  const [indicators, setIndicators] = useState<{
    sma9: boolean;
    sma20: boolean;
    sma50: boolean;
    bollinger: boolean;
    rsi: boolean;
  }>({
    sma9: false,
    sma20: false,
    sma50: false,
    bollinger: false,
    rsi: false,
  });

  const [priceData, setPriceData] = useState<{ time: number; price: number }[]>([]);

  useEffect(() => {
    // Fetch quotes and convert to chart data
    const initChart = async () => {
      if (!chartRef.current) return;

      const queryClient = useQueryClient;

      // In production, fetch historical data from broker WebSocket
      // For now, generate mock OHLC data
      const mockData = generateMockOHLCData(100);

      setPriceData(mockData);

      // Create chart
      const chart = createChart(chartRef.current, mockData);

      // Add moving averages if enabled
      if (indicators.sma9) {
        addMovingAverage(chart, mockData, 9, '#3B82F6', 'MA9');
      }
      if (indicators.sma20) {
        addMovingAverage(chart, mockData, 20, '#F59E0B', 'MA20');
      }
      if (indicators.sma50) {
        addMovingAverage(chart, mockData, 50, '#A855F7', 'MA50');
      }

      // Add Bollinger Bands if enabled
      if (indicators.bollinger) {
        addBollingerBands(chart, mockData);
      }

      // Add RSI if enabled
      if (indicators.rsi && rsiRef.current) {
        const rsiData = BaseIndicators.RSI(mockData.map(d => d.price));
        addRSI(chart, mockData, rsiData, rsiRef.current);
      }

      // Store chart reference for later use
      (chartRef.current as any).chart = chart;
    };

    initChart();
  }, [indicators, theme]);

  useEffect(() => {
    // Generate mock OHLC data
    const generateMockOHLCData = (count: number): { time: number; price: number }[] => {
      const data: { time: number; price: number }[] = [];
      let price = 18500 + Math.random() * 500 - 250; // Start around NIFTY level

      for (let i = 0; i < count; i++) {
        const change = (Math.random() - 0.5) * 20; // Random change -10 to +10
        price = Math.max(8000, Math.min(28000, price + change));
        const time = Date.now() - (count - i) * 60000; // 1-minute intervals going back
        data.push({ time, price: Math.round(price * 100) / 100 });
      }

      return data;
    };

    // Initialize on mount
    const data = generateMockOHLCData(200);
    setPriceData(data);
  }, []);

  const handleRefresh = () => {
    queryClient.invalidateQueries(['market-quotes']);
    toast({ title: 'Chart refreshed' });
  };

  const handleSymbolChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSymbol(e.target.value);
  };

  const handleTimeframeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setTimeframe(e.target.value);
  };

  const handleIndicatorToggle = (indicator: keyof typeof indicators) => {
    setIndicators(prev => ({
      ...prev,
      [indicator]: !prev[indicator],
    }));
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Advanced Charts - {symbol}</CardTitle>
          <div className="flex items-center gap-2">
            <Select
              placeholder="Symbol"
              options={[
                { value: 'NIFTY', label: 'NIFTY 50' },
                { value: 'BANKNIFTY', label: 'BANKNIFTY' },
                { value: 'RELIANCE', label: 'RELIANCE' },
                { value: 'TCS', label: 'TCS' },
                { value: 'HDFCBANK', label: 'HDFC BANK' },
              ]}
              onChange={handleSymbolChange}
            />
            <Select
              placeholder="Timeframe"
              options={[
                { value: '1Min', label: '1Min' },
                { value: '5Min', label: '5Min' },
                { value: '15Min', label: '15Min' },
                { value: '1H', label: '1H' },
                { value: '1D', label: '1D' },
              ]}
              onChange={handleTimeframeChange}
            />
            <Button variant="ghost" size="sm" onClick={handleRefresh}>
              Refresh
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <div className="flex gap-3 flex-wrap">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleIndicatorToggle('sma9')}
            >
              SMA9 {indicators.sma9 ? '✓' : ''}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleIndicatorToggle('sma20')}
            >
              SMA20 {indicators.sma20 ? '✓' : ''}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleIndicatorToggle('sma50')}
            >
              SMA50 {indicators.sma50 ? '✓' : ''}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleIndicatorToggle('bollinger')}
            >
              BB {indicators.bollinger ? '✓' : ''}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleIndicatorToggle('rsi')}
            >
              RSI {indicators.rsi ? '✓' : ''}
            </Button>
          </div>

          {/* Chart Container */}
          <div
            ref={chartRef}
            className="h-96 w-full bg-bg-elevished rounded-md overflow-auto"
            style={{ minHeight: '400px' }}
          >
            {/* RSI Container */}
            <div
              ref={rsiRef}
              className="h-48 w-full bg-bg-elevated rounded-md mt-3 overflow-auto"
              style={{ minHeight: '150px', display: indicators.rsi ? 'block' : 'none' }}
            >
              {/* RSI will be rendered by addRSI */}
            </div>
          </div>

          {/* Indicator Controls */}
          <div className="mt-4 pt-4 border-t border-border-subtle">
            <div className="text-xs text-text-secondary mb-2">Technical Indicators</div>
            <div className="grid grid-cols-2 gap-2">
              <span className="text-[10px] px-2 py-1 rounded bg-bg-surface text-center">
                {'SMA9'} {indicators.sma9 ? 'active' : ''}
              </span>
              <span className="text-[10px] px-2 py-1 rounded bg-bg-surface text-center">
                {'SMA20'} {indicators.sma20 ? 'active' : ''}
              </span>
              <span className="text-[10px] px-2 py-1 rounded bg-bg-surface text-center">
                {'SMA50'} {indicators.sma50 ? 'active' : ''}
              </span>
              <span className="text-[10px] px-2 py-1 rounded bg-bg-surface text-center">
                {'BB'} {indicators.bollinger ? 'active' : ''}
              </span>
              <span className="text-[10px] px-2 py-1 rounded bg-bg-surface text-center">
                {'RSI'} {indicators.rsi ? 'active' : ''}
              </span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex justify-end">
          <Button variant="secondary" size="sm" onClick={handleRefresh}>
            Refresh
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};