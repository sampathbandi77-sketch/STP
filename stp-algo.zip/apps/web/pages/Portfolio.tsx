/**
 * Portfolio Page - Holdings, positions, performance analytics
 */

import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { Input, Select, Textarea } from '@sampath/ui';
import { Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { toast } from '@sampath/ui';
import { OptionChain } from '@sampath/ui';

export const Portfolio = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Fetch portfolio data
  const { data: positions, isLoading } = useQuery({
    queryKey: ['portfolio-positions'],
    queryFn: async () => {
      // In production: fetch from broker API
      return [];
    },
    refetchInterval: 2000,
    enabled: true,
  });

  // Fetch holdings
  const { data: holdings } = useQuery({
    queryKey: ['portfolio-holdings'],
    queryFn: async () => {
      return [
        { symbol: 'RELIANCE', qty: 1500, avgPrice: 2450, currentPrice: 2510, pnl: 9000, pnlPercent: 3.67 },
        { symbol: 'TCS', qty: 800, avgPrice: 3200, currentPrice: 3450, pnl: 4000, pnlPercent: 2.5 },
        { symbol: 'HDFCBANK', qty: 2000, avgPrice: 1450, currentPrice: 1520, pnl: 1400, pnlPercent: 1.72 },
        { symbol: 'INFY', qty: 3000, avgPrice: 1400, currentPrice: 1480, pnl: 2400, pnlPercent: 2.86 },
        { symbol: 'ICICIBANK', qty: 2500, avgPrice: 920, currentPrice: 965, pnl: 1050, pnlPercent: 2.28 },
      ];
    },
    refetchInterval: 2000,
  });

  // Scan for opportunities
  const handleScanClick = () => {
    navigate('/scanner');
  };

  const handleOptionsClick = () => {
    navigate('/options');
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries(['portfolio-positions']);
    queryClient.invalidateQueries(['portfolio-holdings']);
    toast({ title: 'Portfolio refreshed' });
  };

  // Order placement mutation
  const [placeOrderMutation] = useMutation({
    mutationFn: async (order: any) => {
      // In production: place order via broker API
      await new Promise(resolve => setTimeout(resolve, 500));
      return { orderId: 'ORD-' + Date.now(), status: 'placed' };
    },
    onSuccess: () => {
      toast({ title: 'Order placed successfully' });
      queryClient.invalidateQueries(['portfolio-positions']);
    },
    onError: (error: any) => {
      toast({ title: error.message || 'Order failed', variant: 'destructive' });
    },
  });

  const handlePlaceOrder = (order: any) => {
    placeOrderMutation.mutate(order);
  };

  useEffect(() => {
    // Initialize WebSocket for live position updates
    console.log('Portfolio WebSocket initialized');
  }, [queryClient]);

  const columns = [
    { accessorKey: 'symbol', header: 'Symbol', size: '120px' },
    { accessorKey: 'qty', header: 'Qty', size: '80px', cell: info => <MiniPrice price={info.currentPrice.toString()} /> },
    { accessorKey: 'avgPrice', header: 'Avg Price', size: '100px', cell: info => <PriceDisplay price={info.avgPrice.toString()} /> },
    { accessorKey: 'currentPrice', header: 'CMP', size: '80px', cell: info => <PriceDisplay price={info.currentPrice.toString()} /> },
    { accessorKey: 'pnl', header: 'P&L', size: '100px', cell: info => (
      <div className="flex items-center gap-1">
        <span className={info.pnl >= 0 ? 'text-green-profit' : 'text-red-loss'}>
          {info.pnl >= 0 ? '+' : ''}{info.pnl.toFixed(0)}
        </span>
        <span className="text-[10px]">{info.pnlPercent >= 0 ? '+' : ''}{info.pnlPercent.toFixed(2)}%</span>
      </div>
    )},
    { accessorKey: 'action', header: 'Action', size: '120px', cell: () => (
      <div className="flex gap-1">
        <Button variant="ghost" size="sm" onClick={() => navigate('/options')}><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg> Options</Button>
        <Button variant="ghost" size="sm"><svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4m0 0l-4-4m4 4l4-4" /></svg> Sell</Button>
      </div>
    )},
  ];

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader>
          <CardTitle>Portfolio</CardTitle>
          <Button variant="ghost" size="sm" onClick={handleScanClick} className="ml-2">
            <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a4 4 0 11-8 0 4 4 0 018 0m6.364-7.364l-.707-.707M10 7h2m4-10v10a2 2 0 002 2h2m-6 2v3a1 1 0 001 1h4a1 1 0 001-1v-3M5 11h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v2" />
            </svg>
            Scanner
          </Button>
          <Button variant="ghost" size="sm" onClick={handleOptionsClick} className="ml-2">
            <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4m0 0l-4-4m4 4l4-4" />
            </svg>
            Options
          </Button>
        </CardHeader>

        <CardContent>
          <div className="overflow-x-auto">
            <div className="min-w-max divide-y divide-border-subtive">
              <div className="bg-bg-elevated rounded-t-lg px-4 py-3 text-sm font-medium text-text-secondary">
                <span>Symbol</span>
                <span>Qty</span>
                <span>Avg Price</span>
                <span>CMP</span>
                <span>P&L</span>
                <span>Action</span>
              </div>
              {isLoading ? (
                <div className="p-4 text-center">Loading positions...</div>
              ) : positions && positions.length > 0 ? (
                positions.map((info, index) => (
                  <div key={index} className="bg-bg-elevated rounded-b-lg px-4 py-3 divide-y divide-border-subtle">
                    <div className="flex items-center gap-3">
                      <span className="font-medium text-text-primary">{info.symbol}</span>
                      <span className="font-mono text-sm">{info.qty}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-sm text-text-secondary flex-1">{info.avgPrice?.toLocaleString('en-IN') || '--'}</span>
                      <PriceDisplay price={info.currentPrice?.toString()} />
                      <div className="flex-1 flex items-center gap-2">
                        {info.pnl !== undefined && (
                          <span className={info.pnl >= 0 ? 'text-green-profit' : 'text-red-loss'}>
                            {info.pnl >= 0 ? '+' : ''}{info.pnl.toFixed(0)}
                          </span>
                        )}
                        <span className="text-[10px] text-sm font-medium">{info.pnlPercent >= 0 ? '+' : ''}{info.pnlPercent.toFixed(2)}%</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Button variant="ghost" size="sm" title="View Options">
                        <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4m0 0l-4-4m4 4l4-4" /></svg>
                      </Button>
                      <Button variant="ghost" size="sm" title="Place Order" onClick={() => handlePlaceOrder({ symbol: info.symbol, action: 'BUY' })}>
                        Buy
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center">
                  <svg className="mx-auto mb-4 h-12 w-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v6a2 2 0 002 2H5a2 2 0 00-2-2v-6m2-3a2 2 0 012 2h2a2 2 0 012 2v-3m-6 2l-3-3m6 3l3-3" /></svg>
                  <h3 className="mb-2">No positions yet</h3>
                  <p className="text-text-muted">Start trading to add positions to your portfolio</p>
                  <Button variant="primary" onClick={handleScanClick}>
                    Scan for Stocks
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex justify-end">
          <Button variant="primary" onClick={handleRefresh}>
            Refresh
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};