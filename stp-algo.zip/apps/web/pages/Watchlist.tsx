/**
 * Watchlist Page - Multi-symbol watchlist with real-time updates
 */

import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { toast } from '@sampath/ui';

export const Watchlist = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Fetch watchlist quotes
  const { data: quotes, isLoading } = useQuery({
    queryKey: ['watchlist-quotes'],
    queryFn: async () => {
      // In production: real-time quotes from WebSocket
      return [
        { symbol: 'RELIANCE', ltp: 2510, change: +35, changePercent: +1.42, volume: 1254897 },
        { symbol: 'TCS', ltp: 3450, change: -12, changePercent: -0.35, volume: 893456 },
        { symbol: 'HDFCBANK', ltp: 1520, change: +8, changePercent: +0.53, volume: 2345678 },
        { symbol: 'INFY', ltp: 1480, change: +5, changePercent: +0.34, volume: 1123456 },
        { symbol: 'ICICIBANK', ltp: 965, change: -2, changePercent: -0.21, volume: 3456789 },
        { symbol: 'SBIN', ltp: 720, change: +5, changePercent: +0.70, volume: 4567890 },
        { symbol: 'BANKNIFTY', ltp: 45200, change: +350, changePercent: +0.78, volume: 1234567 },
      ];
    },
    refetchInterval: 300, // 3s updates for watchlist
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  const watchlistState = useMarketStore.getState();
  const addToWatchlist = watchlistState.addToWatchlist;
  const removeFromWatchlist = watchlistState.removeFromWatchlist;

  const handleAddSymbol = (symbol: string) => {
    addToWatchlist(symbol);
    toast({ title: `${symbol} added to watchlist` });
  };

  const handleRemove = (symbol: string) => {
    removeFromWatchlist(symbol);
    toast({ title: `${symbol} removed from watchlist` });
  };

  const handleScanClick = () => {
    navigate('/scanner');
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries(['watchlist-quotes']);
    toast({ title: 'Watchlist refreshed' });
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Watchlist</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              placeholder="Add symbol..."
              onKeyDown={(e) => e.key === 'Enter' && handleAddSymbol(e.target.value)}
              className="max-w-xs"
            />
            <Button variant="secondary" size="sm" onClick={handleScanClick}>
              Scanner
            </Button>
            <Button variant="ghost" size="sm" onClick={handleRefresh}>
              Refresh
            </Button>
          </div>
        </CardHeader>

        <CardContent className="overflow-x-auto">
          {isLoading ? (
            <div className="h-64 flex items-center justify-center">Loading quotes...</div>
          ) : quotes.map((quote) => (
            <div key={quote.symbol} className="bg-bg-elevated rounded-lg p-4 border-b border-border-subtle flex items-center gap-4">
              <span className="font-medium text-text-primary flex-1">{quote.symbol}</span>
              <div className="flex-1">
                <PriceDisplay price={quote.ltp.toString()} flashDuration={200} />
              </div>
              <div className="flex flex-col gap-1">
                <span className={quote.change >= 0 ? 'text-green-profit' : 'text-red-loss'}>
                  {quote.change >= 0 ? '+' : ''}{quote.change.toFixed(2)}
                </span>
                <span className="text-[10px] text-sm font-medium">{quote.changePercent >= 0 ? '+' : ''}{quote.changePercent.toFixed(2)}%</span>
              </div>
              <div className="text-xs text-text-muted">{quote.volume?.toLocaleString('en-IN') || '--'} vol</div>
              <div className="flex gap-2 mt-2">
                <Button variant="ghost" size="sm" onClick={() => handleRemove(quote.symbol)}>
                  Remove
                </Button>
              </div>
            </div>
          ))}
        </CardContent>

        <CardFooter className="flex justify-between">
          <div className="text-xs text-text-muted">Last updated: just now</div>
          <Button variant="secondary" size="sm" onClick={handleRefresh}>
            Refresh
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};