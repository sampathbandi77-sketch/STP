/**
 * Options Page - Option chain, Greeks, strategy builder
 */

import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { Input, Select, Button } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { toast } from '@sampath/ui';
import { OptionChain } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';

export const Options = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Fetch option chain for NIFTY
  const { data: optionChain, isLoading } = useQuery({
    queryKey: ['option-chain', 'NIFTY'],
    queryFn: async () => {
      // In production: fetch from broker API
      return {
        underlying: 'NIFTY',
        ltp: 18542,
        expiry: '2024-12-26',
        strikes: [18300, 18400, 18500, 18600, 18700],
        options: [
          // CE (Call Options)
          { strike: 18300, ce: { ltp: 285, change: +15, oi: 254321, volume: 12345, iv: 18.5, bid: 280, ask: 290 }, pe: null },
          { strike: 18400, ce: { ltp: 220, change: +8, oi: 312456, volume: 89012, iv: 17.8, bid: 215, ask: 225 }, pe: null },
          { strike: 18500, ce: { ltp: 165, change: +3, oi: 512345, volume: 67890, iv: 17.2, bid: 160, ask: 170 }, pe: null },
          { strike: 18600, ce: { ltp: 115, change: -2, oi: 189432, volume: 23456, iv: 16.5, bid: 110, ask: 120 }, pe: null },
          { strike: 18700, ce: { ltp: 72, change: -5, oi: 67834, volume: 8901, iv: 15.8, bid: 68, ask: 75 }, pe: null },
          // PE (Put Options)
          { strike: 18300, ce: null, pe: { ltp: 125, change: -3, oi: 189432, volume: 56789, iv: 20.3, bid: 120, ask: 130 } },
          { strike: 18400, ce: null, pe: { ltp: 185, change: +5, oi: 324567, volume: 123456, iv: 19.7, bid: 180, ask: 195 } },
          { strike: 18500, ce: null, pe: { ltp: 265, change: +8, oi: 654321, volume: 234567, iv: 19.1, bid: 255, ask: 275 } },
          { strike: 18600, ce: null, pe: { ltp: 365, change: +12, oi: 456789, volume: 345678, iv: 18.4, bid: 350, ask: 380 } },
          { strike: 18700, ce: null, pe: { ltp: 485, change: +18, oi: 234567, volume: 123456, iv: 17.7, bid: 460, ask: 510 } },
        ],
        greeks: {
          delta: -0.45,
          gamma: 0.08,
          theta: -2.3,
          vega: 15.2,
          rho: 3.5,
        },
        impliedVolatility: 17.8,
        premium: 2.1,
      };
    },
    refetchInterval: 5000,
  });

  const handleRefresh = () => {
    queryClient.invalidateQueries(['option-chain', 'NIFTY']);
    toast({ title: 'Option chain refreshed' });
  };

  const handleViewGreeks = () => {
    navigate('/ai-analysis');
  };

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader>
          <CardTitle>Option Chain - NIFTY {optionChain?.underlying}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-sm text-text-muted">LTP: {optionChain?.ltp}</span>
            <Button variant="ghost" size="sm" onClick={handleRefresh}>
              Refresh
            </Button>
            <Button variant="ghost" size="sm" onClick={handleViewGreeks}>
              AI Analysis
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {isLoading ? (
            <div className="h-64 flex items-center justify-center">Loading option chain...</div>
          ) : optionChain && optionChain.options.map((opt, index) => (
            <div key={index} className="bg-bg-elevated rounded-lg p-4 border-b border-border-subtle flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="font-medium text-text-primary flex-1">{opt.strike}</span>
                {opt.ce && (
                  <PriceDisplay
                    price={opt.ce.ltp.toString()}
                    flashDuration={100}
                    className="text-green-profit font-medium"
                  />
                )}
                {opt.pe && (
                  <PriceDisplay
                    price={opt.pe.ltp.toString()}
                    flashDuration={100}
                    className="text-red-loss font-medium"
                  />
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-text-muted">
                {opt.ce && (
                  <>
                    <div>CE</div>
                    <div>OI: {opt.ce.oi?.toLocaleString() || '--'}</div>
                    <div>Vol: {opt.ce.volume?.toLocaleString() || '--'}</div>
                    <div>IV: {opt.ce.iv?.toFixed(1)}%</div>
                  </>
                )}
                {opt.pe && (
                  <>
                    <div>PE</div>
                    <div>OI: {opt.pe.oi?.toLocaleString() || '--'}</div>
                    <div>Vol: {opt.pe.volume?.toLocaleString() || '--'}</div>
                    <div>IV: {opt.pe.iv?.toFixed(1)}%</div>
                  </>
                )}
              </div>

              <div className="flex items-center gap-2 mt-1">
                {opt.ce && (
                  <Button variant="ghost" size="xs" title="Buy CE">
                    <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                  </Button>
                )}
                {opt.pe && (
                  <Button variant="ghost" size="xs" title="Buy PE">
                    <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
                  </Button>
                )}
              </div>
            </div>
          ))}
        </CardContent>

        <CardFooter>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <div className="text-text-secondary">IV Surface</div>
              <div className="font-medium">{optionChain?.impliedVolatility?.toFixed(1)}%</div>
            </div>
            <div>
              <div className="text-text-secondary">Premium</div>
              <div className="font-medium">₹{optionChain?.premium?.toFixed(2)}</div>
            </div>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};