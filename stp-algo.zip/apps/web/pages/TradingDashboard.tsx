/**
 * Trading Dashboard - Main trading interface
 * Combines order entry, portfolio, and watchlist
 */

import React, { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { OrderEntry } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';
import { useTheme } from '@sampath/ui';
import { Tabs, TabPanel } from '@sampath/ui';
import { PriceDisplay, MiniPrice } from '@sampath/ui';
import { toast } from '@sampath/ui';

export const TradingDashboard = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { theme } = useTheme();
  const { data: quotes } = useMarketStore.getState();

  // Initialize market data
  useEffect(() => {
    // Subscribe to real-time quotes
    console.log('Trading dashboard initialized with real-time data');
  }, [quotes]);

  const columns = [
    { accessorKey: 'symbol', header: 'Symbol', size: '120px' },
    { accessorKey: 'ltp', header: 'LTP', size: '100px', cell: info => <PriceDisplay price={info.ltp.toString()} /> },
    { accessorKey: 'change', header: 'Change', size: '80px', cell: info => (
      <span className={info.change >= 0 ? 'text-green-profit' : 'text-red-loss'}>
        {info.change >= 0 ? '+' : ''}{info.change.toFixed(2)}
      </span>
    )},
    { accessorKey: 'changePercent', header: '%', size: '80px', cell: info => (
      <span className={info.changePercent >= 0 ? 'text-green-profit' : 'text-red-loss'}>
        {info.changePercent >= 0 ? '+' : ''}{info.changePercent.toFixed(2)}%
      </span>
    )},
    { accessorKey: 'action', header: 'Action', size: '120px', cell: () => (
      <div className="flex gap-1">
        <Button variant="ghost" size="sm" onClick={() => navigate('/order-entry/RELIANCE')}>
          Order
        </Button>
      </div>
    )},
  ];

  const tabs = [
    { id: 'watchlist', label: 'Watchlist' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'orders', label: 'Orders' },
  ];

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle>SAMPATH PRO MAX - Trading</CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate('/scanner')}>
              Scanner
            </Button>
            <Button variant="ghost" size="sm">
              Alerts
            </Button>
          </div>
        </CardHeader>

        <Tabs defaultActiveKey="watchlist" tabs={tabs} fullWidth>
          {/* Watchlist Tab */}
          <TabPanel tabId="watchlist">
            <CardContent className="overflow-x-auto">
              <div className="min-w-max divide-y divide-border-subtle">
                <div className="bg-bg-elevated rounded-t-lg px-4 py-3 text-sm font-medium text-text-secondary">
                  <span>Symbol</span>
                  <span>LTP</span>
                  <span>Change</span>
                  <span>%</span>
                  <span>Action</span>
                </div>
                {quotes && quotes.length > 0 ? (
                  quotes.map((quote, index) => (
                    <div key={index} className="bg-bg-elevated rounded-b-lg px-4 py-3 divide-y divide-border-subtle flex items-center gap-3">
                      <span className="font-medium text-text-primary flex-1">{quote.symbol}</span>
                      <PriceDisplay price={quote.ltp.toString()} flashDuration={100} />
                      <span className={quote.change >= 0 ? 'text-green-profit' : 'text-red-loss'}>
                        {quote.change >= 0 ? '+' : ''}{quote.change.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-sm font-medium">{quote.changePercent >= 0 ? '+' : ''}{quote.changePercent.toFixed(2)}%</span>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => navigate(`/order-entry/${quote.symbol}`)}>
                          Order
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center">
                    <svg className="mx-auto mb-4 h-12 w-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v6a2 2 0 002 2H5a2 2 0 00-2-2v-6m2-3a2 2 0 012 2h2a2 2 0 012 2v-3m-6 2l-3-3m6 3l3-3" /></svg>
                    <h3 className="mb-2">No symbols in watchlist</h3>
                    <p className="text-text-muted">Add symbols to watchlist from the dashboard</p>
                    <Button variant="primary">Add Symbols</Button>
                  </div>
                )}
              </div>
            </CardContent>
          </TabPanel>

          {/* Portfolio Tab */}
          <TabPanel tabId="portfolio">
            <CardContent>
              <div className="text-sm text-text-secondary mb-2">Portfolio Summary</div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Total Value</div>
                  <div className="font-medium text-text-primary">₹1,25,45,890</div>
                </div>
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Today P&L</div>
                  <div className="font-medium text-green-profit">+₹2,34,567</div>
                </div>
                <div className="bg-bg-elevated rounded-lg p-3">
                  <div className="text-xs text-text-secondary mb-1">Cash Balance</div>
                  <div className="font-medium text-text-primary">₹45,67,890</div>
                </div>
              </div>
            </CardContent>
          </TabPanel>

          {/* Orders Tab */}
          <TabPanel tabId="orders">
            <CardContent>
              <div className="overflow-x-auto">
                <div className="bg-bg-elevated rounded-t-lg px-4 py-3 text-sm font-medium text-text-secondary">
                  <span>Order ID</span>
                  <span>Symbol</span>
                  <span>Side</span>
                  <span>Qty</span>
                  <span>Status</span>
                  <span>Price</span>
                </div>
                {/* Orders would be fetched from API */}
                <div className="bg-bg-elevated rounded-b-lg px-4 py-3 text-center text-text-muted">
                  No active orders
                </div>
              </div>
            </CardContent>
          </TabPanel>
        </Tabs>
      </Card>

      {/* Order Entry Floating Section */}
      <Card variant="elevated" padding="lg" className="mt-4">
        <CardHeader>
          <CardTitle>Quick Order</CardTitle>
        </CardHeader>
        <CardContent>
          <OrderEntry symbol="RELIANCE" onOrderPlaced={() => {
            toast({ title: 'Order executed successfully' });
            queryClient.invalidateQueries(['market-quotes']);
          }} />
        </CardContent>
        <CardFooter className="pt-2">
          <Button variant="primary" style={{ width: '100%' }}>
            Place Order
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};