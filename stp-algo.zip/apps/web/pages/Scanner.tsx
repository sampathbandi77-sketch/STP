/**
 * Scanner Page - AI-powered stock scanner with custom condition builder
 */

import React, { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@sampath/ui';
import { ScanBuilder } from '@sampath/scanner';
import { toast } from '@sampath/ui';
import { useMarketStore } from '@sampath/stores';

export const Scanner = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { data: watchlist } = useMarketStore.getState();

  useEffect(() => {
    // Initialize with watchlist or default symbols
    console.log('Scanner initialized with', watchlist?.length, 'watchlist symbols');
  }, [watchlist]);

  return (
    <div className="min-h-screen bg-bg-deep text-text-primary">
      <Card variant="elevated" padding="lg">
        <CardHeader>
          <CardTitle>AI Stock Scanner</CardTitle>
          <CardDescription>
            Scan NSE/BSE stocks with 20+ technical filters and custom conditions
          </CardDescription>
        </CardHeader>

        <CardContent>
          <ScanBuilder
            onScanExecute={(results) => {
              // Display scan results
              if (results.length > 0) {
                toast({ title: `Scan Found ${results.length} Stocks` });
                // Navigate to results or show in modal
                // navigate('/scanner-results');
              } else {
                toast({ title: 'No stocks matched the criteria', variant: 'destructive' });
              }
            }}
            onConfigChange={(config) => {
              // Handle config changes
            }}
          />
        </CardContent>

        <CardFooter>
          <div className="grid grid-cols-2 gap-2 text-xs text-text-secondary">
            <div>Active Filters</div>
            <div>{watchlist?.length || 0} symbols</div>
            <div>Scan Frequency</div>
            <div>Real-time</div>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};