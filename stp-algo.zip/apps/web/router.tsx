import { createRouter } from '@tanstack/react-router';
import { Routes } from './Routes';

export const router = createRouter({
  defaultPreload: true,
  initialTab: false,
});

export const { RouterProvider } = router;