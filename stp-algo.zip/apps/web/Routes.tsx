import {
  Router,
  createRoot,
} from '@tanstack/react-router';
import { lazy } from 'react';
import { Suspense } from 'react';

const Home = lazy(() => import('./pages/Home'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Portfolio = lazy(() => import('./pages/Portfolio'));
const Watchlist = lazy(() => import('./pages/Watchlist'));
const Scanner = lazy(() => import('./pages/Scanner'));
const Options = lazy(() => import('./pages/Options'));
const Settings = lazy(() => import('./pages/Settings'));
const AIAnalysis = lazy(() => import('./pages/AIAnalysis'));

export const router = createRoot({
  debug: false,
});

export const { RouterProvider } = router;

// @ts-ignore
router.route('').component = Home;
router.route('/').component = Home;
router.route('/dashboard').component = Dashboard;
router.route('/portfolio').component = Portfolio;
router.route('/watchlist').component = Watchlist;
router.route('/scanner').component = Scanner;
router.route('/options').component = Options;
router.route('/settings').component = Settings;
router.route('/ai-analysis').component = AIAnalysis;

export const Routes = () => (
  <Suspense fallback={<div>Loading...</div>}>
    <Router>
      <Route path="/" element={<Home />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/portfolio" element={<Portfolio />} />
      <Route path="/watchlist" element={<Watchlist />} />
      <Route path="/scanner" element={<Scanner />} />
      <Route path="/options" element={<Options />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="/ai-analysis" element={<AIAnalysis />} />
    </Router>
  </Suspense>
);