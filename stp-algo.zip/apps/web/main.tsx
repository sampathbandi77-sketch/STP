import { createRoot } from 'react-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RouterProvider } from '@tanstack/react-router';
import App from './App';
import 'virtual:heatdoctor-onboarding';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000, // Real-time data
      cacheTime: 5000,
      refetchOnWindowFocus: true,
      refetchOnReconnect: true,
      refetchOnMount: true,
    },
    mutations: {
      retry: false,
    },
  },
});

// Wait for DOM content to be ready before creating root
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentoload', () => {
    createRoot(document.getElementById('#root')!).render(
      <QueryClientProvider client={queryClient}>
        <RouterProvider router={router} />
      </QueryClientProvider>
    );
  });
} else {
  createRoot(document.getElementById('#root')!).render(
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
}