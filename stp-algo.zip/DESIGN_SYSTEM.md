# SAMPATH PRO MAX - Design System & Architecture

## Design Philosophy
**Institutional-grade, AI-first trading platform** - Not a retail app. Every pixel communicates precision, speed, and intelligence. Dark theme by default (traders work in dark rooms). Data-dense but never cluttered. Motion is functional, not decorative.

---

## Color System (Core Palette)

### Base - Deep Space
```
--bg-deep:       #05080C    // Primary background - near black with blue undertone
--bg-elevated:   #0A0F16    // Cards, panels, modals
--bg-surface:    #101820    // Input fields, dropdowns
--bg-hover:      #161F2B    // Hover states
--bg-active:     #1B2838    // Active/pressed states
```

### Border & Dividers
```
--border-subtle: #1E2A3A    // Hairline dividers
--border-default: #2A3A4A   // Standard borders
--border-strong: #3A4D5D    // Focus rings, emphasis
```

### Text Hierarchy
```
--text-primary:   #E8ECF1   // Headlines, primary data
--text-secondary: #A8B3C0   // Labels, secondary info
--text-muted:     #6B7A8A   // Placeholders, disabled
--text-inverse:   #05080C   // On accent backgrounds
```

### Semantic Colors (Trading-specific)
```
--green-profit:   #00D47E   // Gains, bids, buy orders
--green-bright:   #00FF9D   // Flash highlights
--green-dim:      #004D2E   // Background tint for profit rows

--red-loss:       #FF4757   // Losses, asks, sell orders
--red-bright:     #FF6B7A   // Flash highlights
--red-dim:        #4D1A1F   // Background tint for loss rows

--blue-info:      #3B82F6   // Neutral info, charts
--blue-bright:    #60A5FA   // Links, CTAs
--blue-dim:       #1E3A5F   // Background tint

--amber-warn:     #F59E0B   // Warnings, pending orders
--amber-bright:   #FBBF24   // Highlights
--amber-dim:      #4D3A0A   // Background tint

--purple-ai:      #A855F7   // AI signals, predictions
--purple-bright:  #C084FC   // AI highlights
--purple-dim:     #3A1F5A   // AI background tint

--gold-premium:   #F5C542   // Premium features, institutional
```

### Data Visualization (Chart-specific)
```
--chart-grid:     #1E2A3A
--chart-axis:     #4A5A6A
--chart-crosshair: #3B82F6
--chart-volume-up:   #00D47E
--chart-volume-down: #FF4757
--chart-ma-9:     #3B82F6
--chart-ma-20:    #F59E0B
--chart-ma-50:    #A855F7
--chart-ma-200:   #FF4757
--chart-vwap:     #00D47E
```

---

## Typography System

### Font Families
```
--font-display: 'Space Grotesk', 'Inter', system-ui, sans-serif;  // Headlines, numbers
--font-mono:    'JetBrains Mono', 'Fira Code', monospace;        // Prices, quantities, code
--font-ui:      'Inter', system-ui, sans-serif;                  // UI labels, body
```

### Type Scale (Fluid, clamp-based)
```
--text-xs:    clamp(0.625rem, 0.6rem + 0.125vw, 0.6875rem);   // 10-11px
--text-sm:    clamp(0.75rem, 0.725rem + 0.125vw, 0.8125rem);  // 12-13px
--text-base:  clamp(0.875rem, 0.85rem + 0.125vw, 0.9375rem);  // 14-15px
--text-lg:    clamp(1rem, 0.975rem + 0.125vw, 1.0625rem);     // 16-17px
--text-xl:    clamp(1.125rem, 1.1rem + 0.125vw, 1.1875rem);   // 18-19px
--text-2xl:   clamp(1.25rem, 1.2rem + 0.25vw, 1.375rem);      // 20-22px
--text-3xl:   clamp(1.5rem, 1.45rem + 0.25vw, 1.625rem);      // 24-26px
--text-4xl:   clamp(1.875rem, 1.8rem + 0.375vw, 2.125rem);    // 30-34px
--text-5xl:   clamp(2.25rem, 2.15rem + 0.5vw, 2.625rem);      // 36-42px
```

### Font Weights
```
--weight-normal: 400
--weight-medium: 500
--weight-semibold: 600
--weight-bold: 700
```

### Line Heights
```
--leading-tight: 1.1
--leading-snug: 1.375
--leading-normal: 1.5
--leading-relaxed: 1.625
```

### Letter Spacing
```
--tracking-tight: -0.02em
--tracking-normal: 0
--tracking-wide: 0.02em
--tracking-wider: 0.04em
--tracking-mono: 0.03em  // For tabular numbers
```

---

## Spacing System (4px base unit)
```
--space-0: 0
--space-1: 4px
--space-2: 8px
--space-3: 12px
--space-4: 16px
--space-5: 20px
--space-6: 24px
--space-8: 32px
--space-10: 40px
--space-12: 48px
--space-16: 64px
--space-20: 80px
--space-24: 96px
```

---

## Border Radius
```
--radius-none: 0
--radius-sm: 4px
--radius-md: 8px
--radius-lg: 12px
--radius-xl: 16px
--radius-2xl: 24px
--radius-full: 9999px
```

---

## Shadows & Depth
```
--shadow-xs: 0 1px 2px rgba(0,0,0,0.3);
--shadow-sm: 0 2px 4px rgba(0,0,0,0.35);
--shadow-md: 0 4px 12px rgba(0,0,0,0.4);
--shadow-lg: 0 8px 24px rgba(0,0,0,0.45);
--shadow-xl: 0 16px 48px rgba(0,0,0,0.5);
--shadow-glow-green: 0 0 24px rgba(0,212,126,0.15);
--shadow-glow-red: 0 0 24px rgba(255,71,87,0.15);
--shadow-glow-blue: 0 0 24px rgba(59,130,246,0.15);
--shadow-glow-purple: 0 0 24px rgba(168,85,247,0.15);
```

---

## Motion & Animation

### Durations
```
--duration-instant: 50ms
--duration-fast: 100ms
--duration-normal: 200ms
--duration-slow: 300ms
--duration-slower: 500ms
```

### Easings
```
--ease-out: cubic-bezier(0.16, 1, 0.3, 1)
--ease-in-out: cubic-bezier(0.4, 0, 0.2, 1)
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1)
--ease-sharp: cubic-bezier(0.4, 0, 0.6, 1)
```

### Motion Principles
- **Price flashes**: 100ms ease-out, no stagger
- **Panel transitions**: 200ms ease-in-out
- **Chart animations**: 300ms ease-out (data-driven)
- **AI signal pulses**: 1000ms ease-in-out infinite
- **Loading skeletons**: 1200ms ease-in-out infinite

---

## Layout System

### Breakpoints
```
--bp-mobile: 320px
--bp-tablet: 768px
--bp-desktop: 1024px
--bp-wide: 1440px
--bp-ultrawide: 1920px
```

### Grid
- 12-column grid on desktop
- 8-column grid on tablet
- 4-column grid on mobile
- Gutter: 16px (desktop), 12px (tablet), 8px (mobile)

### Layout Regions (Desktop)
```
┌─────────────────────────────────────────────────────────────┐
│  Top Bar (48px) - Logo | Search | Alerts | User | Theme    │
├──────────┬────────────────────────────────────┬─────────────┤
│          │                                    │             │
│  Side    │         Main Canvas                │  Right      │
│  Nav     │  (Flexible: Charts, Tables,        │  Panel      │
│  (280px) │   Portfolio, Options)              │  (320px)    │
│          │                                    │             │
├──────────┴────────────────────────────────────┴─────────────┤
│  Bottom Bar (72px) - Watchlist Tabs | Order Entry | Positions │
└─────────────────────────────────────────────────────────────┘
```

---

## Component Architecture

### Core Components (Atomic)
1. **Button** - Primary, Secondary, Ghost, Danger, Icon-only
2. **Input** - Text, Number, Search, Select, DatePicker
3. **Typography** - Heading, Body, Label, Mono, Price, Percentage
4. **Card** - Elevated, Outlined, Glass, Interactive
5. **Badge** - Status, Dot, Pill, Count
6. **Tooltip** - Default, Rich, Chart-specific
7. **Dropdown** - Simple, Multi-select, Searchable
8. **Tabs** - Line, Pill, Segmented
9. **Modal** - Default, Fullscreen, Drawer, Confirmation
10. **Spinner/Skeleton** - Inline, Overlay, Chart-specific

### Trading Components (Molecular)
1. **PriceDisplay** - Real-time with flash, size, change%
2. **OrderEntry** - Limit/Market/SL/SL-M, bracket, OCO
3. **PositionCard** - P&L, unrealized, actions
4. **WatchlistRow** - Multi-symbol, sortable, draggable
5. **ChartToolbar** - Timeframes, indicators, drawings, AI
6. **OptionChain** - Strikes, Greeks, IV, OI, PCR
7. **DepthChart** - L2 order book, heatmap
8. **SignalCard** - AI prediction, confidence, action
9. **SmartMoneyFlow** - FII/DII, block deals, bulk deals
10. **RiskMetrics** - VaR, Greeks, correlation, drawdown

### Layout Components (Organism)
1. **ChartPanel** - Multi-pane, synchronized, layouts
2. **PortfolioDashboard** - Holdings, allocation, performance
3. **ScannerResults** - Filterable, sortable, exportable
4. **OptionsWorkspace** - Strategy builder, P&L graph
5. **MarketOverview** - Indices, sectors, breadth, news
6. **OrderBook** - Live L2, time & sales, footprint

---

## Data Architecture

### State Management (Zustand + TanStack Query)
```
stores/
├── authStore          // User session, permissions
├── marketStore        // Real-time quotes, subscriptions
├── chartStore         // Chart layouts, indicators, drawings
├── portfolioStore     // Holdings, positions, orders
├── scannerStore       // Scan criteria, results, alerts
├── optionsStore       // Chains, strategies, Greeks
├── aiStore            // Signals, predictions, models
├── smartMoneyStore    // Institutional flows, block deals
├── uiStore            // Layout, panels, themes, notifications
└── settingsStore      // Preferences, API keys, broker config
```

### API Layer (TanStack Query + WebSocket)
```
api/
├── rest/
│   ├── auth.ts
│   ├── market.ts
│   ├── portfolio.ts
│   ├── orders.ts
│   ├── options.ts
│   ├── scanner.ts
│   ├── ai.ts
│   └── smart-money.ts
├── ws/
│   ├── marketFeed.ts      // Real-time quotes
│   ├── orderUpdates.ts    // Order/trade notifications
│   ├── chartStream.ts     // Chart data streaming
│   └── aiSignals.ts       // Real-time AI alerts
└── brokers/
    ├── dhan.ts
    ├── upstox.ts
    └── coinswitch.ts
```

---

## Broker Integration Architecture

### Unified Broker Interface
```typescript
interface BrokerAdapter {
  // Authentication
  authenticate(credentials: BrokerCredentials): Promise<AuthResult>
  refreshToken(): Promise<void>
  
  // Market Data
  subscribe(symbols: string[], mode: 'ltp' | 'quote' | 'depth'): Promise<void>
  unsubscribe(symbols: string[]): Promise<void>
  getQuote(symbol: string): Promise<Quote>
  getDepth(symbol: string): Promise<MarketDepth>
  getOHLC(symbol: string, timeframe: Timeframe): Promise<Candle[]>
  
  // Orders
  placeOrder(order: OrderRequest): Promise<OrderResponse>
  modifyOrder(orderId: string, modifications: OrderModification): Promise<void>
  cancelOrder(orderId: string): Promise<void>
  getOrders(filters?: OrderFilters): Promise<Order[]>
  getTrades(dateRange: DateRange): Promise<Trade[]>
  
  // Portfolio
  getPositions(): Promise<Position[]>
  getHoldings(): Promise<Holding[]>
  getFunds(): Promise<Funds>
  
  // Options
  getOptionChain(symbol: string, expiry: string): Promise<OptionChain>
  getGreeks(symbol: string, strike: number, expiry: string): Promise<Greeks>
  
  // WebSocket
  on(event: 'quote' | 'depth' | 'order' | 'trade', handler: Function): void
  off(event: string, handler: Function): void
}
```

---

## AI/ML Integration Architecture

### Signal Pipeline
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Market     │────▶│  Feature    │────▶│  Model      │────▶│  Signal     │
│  Data       │     │  Engineering│     │  Inference  │     │  Generation │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
       │                   │                   │                   │
       ▼                   ▼                   ▼                   ▼
  • OHLCV              • Technical         • LSTM/Transformer   • Direction
  • Order Book         • Microstructure    • Ensemble           • Confidence
  • Options Data       • Cross-asset       • Online Learning    • Time Horizon
  • News/Sentiment     • Regime            • Explainability     • Risk/Reward
  • Smart Money        • Alternative       • Uncertainty        • Entry/Exit
```

### Model Types
1. **Trend Following** - LSTM on multi-timeframe data
2. **Mean Reversion** - Statistical arbitrage signals
3. **Pattern Recognition** - CNN on chart images
4. **Options IV Modeling** - GARCH + ML hybrid
5. **Smart Money Detection** - Clustering on block/bulk deals
6. **Regime Detection** - HMM on market features

---

## Mobile-Specific Adaptations

### Touch Optimizations
- Minimum touch target: 44×44px
- Swipe gestures for chart navigation
- Pull-to-refresh on all data views
- Haptic feedback on order placement
- Bottom sheet modals (not center)

### Layout Adjustments
- Collapsible side nav → bottom tab bar
- Right panel → slide-over sheet
- Chart toolbar → bottom action bar
- Order entry → fixed bottom sheet
- Multi-pane charts → swipeable tabs

### Performance
- Virtualized lists for watchlists/scanners
- Chart data decimation on mobile
- WebWorker for heavy calculations
- Lazy-loaded route chunks
- Image optimization (WebP, lazy load)

---

## Accessibility (WCAG 2.1 AA)
- Color contrast: 4.5:1 minimum (7:1 for price text)
- Focus indicators: 2px solid --blue-bright
- Reduced motion: respects prefers-reduced-motion
- Screen reader: ARIA labels, live regions for price updates
- Keyboard: Full navigation, shortcuts for power users
- High contrast mode: Alternative palette

---

## Security Considerations
- API keys encrypted at rest (Web Crypto API)
- Biometric authentication on mobile
- Certificate pinning for broker APIs
- Rate limiting on all endpoints
- Audit logging for all trading actions
- Session management with refresh tokens
- Content Security Policy headers

---

## Deployment Architecture

### Frontend
- **Web**: Vercel/Netlify (Edge functions for API proxy)
- **Mobile**: Expo EAS Build → App Store / Play Store
- **Desktop**: Tauri (Rust backend) or Electron

### Backend (Node.js/Go)
- **API Gateway**: Kong or AWS API Gateway
- **Services**: Kubernetes (EKS/GKE)
- **WebSocket**: Redis Pub/Sub + Socket.io
- **Cache**: Redis Cluster
- **Database**: TimescaleDB (market data) + PostgreSQL (user data)
- **Queue**: BullMQ (Redis) for async jobs
- **Monitoring**: Prometheus + Grafana + Datadog

---

## Development Workflow

### Monorepo Structure (Turborepo)
```
sampath-pro-max/
├── apps/
│   ├── web/                 # Next.js 14+ App Router
│   ├── mobile/              # Expo Router (React Native)
│   └── desktop/             # Tauri + React
├── packages/
│   ├── ui/                  # Shared component library
│   ├── design-tokens/       # Design system (this file)
│   ├── hooks/               # Shared React hooks
│   ├── utils/               # Shared utilities
│   ├── api/                 # API client, types
│   ├── stores/              # Zustand stores
│   ├── charting/            # Chart components (Lightweight Charts)
│   ├── ai/                  # AI signal components
│   ├── brokers/             # Broker adapters
│   └── testing/             # Test utilities, mocks
├── turbo.json
├── package.json
└── tsconfig.base.json
```

### Key Technologies
- **Framework**: React 18+, Next.js 14, Expo 50+
- **Language**: TypeScript 5.3+ (strict mode)
- **Styling**: Tailwind CSS 3.4+ (custom config)
- **State**: Zustand 4.5+ + TanStack Query 5+
- **Charts**: TradingView Lightweight Charts / Canvas API
- **WebSocket**: Native WS + Socket.io fallback
- **Forms**: React Hook Form + Zod
- **Testing**: Vitest + React Testing Library + Playwright
- **CI/CD**: GitHub Actions + Turborepo

---

## Implementation Phases

### Phase 1: Foundation (Weeks 1-3)
- [ ] Monorepo setup with Turborepo
- [ ] Design system implementation (Tailwind config)
- [ ] Core UI component library
- [ ] Authentication flow (OAuth + Broker)
- [ ] Basic layout & navigation
- [ ] Theme system (dark/light/high-contrast)

### Phase 2: Market Data & Charts (Weeks 4-6)
- [ ] WebSocket infrastructure
- [ ] Broker adapters (Dhan, Upstox, CoinSwitch)
- [ ] Real-time quote components
- [ ] Advanced charting (multi-pane, indicators, drawings)
- [ ] Chart layouts & persistence
- [ ] Market depth / L2 visualization

### Phase 3: Trading Core (Weeks 7-9)
- [ ] Order entry (all order types)
- [ ] Position management
- [ ] Portfolio dashboard
- [ ] Order book & trade history
- [ ] Risk checks & validation
- [ ] Multi-broker order routing

### Phase 4: Options & Analytics (Weeks 10-12)
- [ ] Option chain with Greeks
- [ ] Strategy builder (vertical, calendar, butterfly, condor)
- [ ] P&L visualization
- [ ] IV surface & skew analysis
- [ ] Backtesting engine
- [ ] Options scanner

### Phase 5: AI & Smart Money (Weeks 13-16)
- [ ] ML pipeline infrastructure
- [ ] Signal generation & display
- [ ] Smart money tracking (FII/DII, block/bulk)
- [ ] Institutional flow analytics
- [ ] Pattern recognition
- [ ] Alert system (push, email, in-app)

### Phase 6: Scanners & Advanced (Weeks 17-20)
- [ ] Real-time stock scanner
- [ ] Custom scan builder
- [ ] Sector/industry analysis
- [ ] Correlation & pairs trading
- [ ] News & sentiment integration
- [ ] Advanced risk analytics

### Phase 7: Polish & Launch (Weeks 21-24)
- [ ] Performance optimization
- [ ] Mobile app store builds
- [ ] Desktop app packaging
- [ ] Comprehensive testing
- [ ] Documentation & onboarding
- [ ] Beta launch & feedback
- [ ] Production launch

---

## Success Metrics

### Technical
- <100ms price update latency (WebSocket to UI)
- <2s initial load (web), <3s (mobile cold start)
- 99.9% uptime during market hours
- Zero order placement failures (broker-side)
- <50MB bundle size (web gzipped)

### Product
- >4.5 App Store rating
- <1% crash rate
- >60% DAU/MAU ratio
- >1000 active traders in first quarter
- Positive NPS from institutional users

---

*This design system is a living document. Update as platform evolves.*