#!/bin/bash
# STP Algorithm - One-Command Deploy Script
# Usage: ./deploy.sh [vercel|docker|railway|local]

set -e  # Exit on error

DEPLOY_TARGET=${1:-vercel}
PROJECT_NAME="stp-algorithm"

echo "🚀 STP Algorithm Deployment"
echo "============================"
echo "Target: $DEPLOY_TARGET"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check prerequisites
check_prerequisites() {
    echo -e "${BLUE}🔍 Checking prerequisites...${NC}"

    if ! command -v node &> /dev/null; then
        echo -e "${RED}❌ Node.js not found. Install from nodejs.org${NC}"
        exit 1
    fi

    if ! command -v npm &> /dev/null; then
        echo -e "${RED}❌ npm not found${NC}"
        exit 1
    fi

    if ! command -v pnpm &> /dev/null; then
        echo -e "${YELLOW}⚠️ pnpm not found, installing...${NC}"
        npm install -g pnpm@9.0.0
    fi

    if [ "$DEPLOY_TARGET" = "docker" ] && ! command -v docker &> /dev/null; then
        echo -e "${RED}❌ Docker not found. Install from docker.com${NC}"
        exit 1
    fi

    if [ "$DEPLOY_TARGET" = "vercel" ] && ! command -v vercel &> /dev/null; then
        echo -e "${YELLOW}⚠️ Vercel CLI not found, installing...${NC}"
        npm install -g vercel@latest
    fi

    echo -e "${GREEN}✅ Prerequisites OK${NC}"
}

# Build all packages
build_project() {
    echo -e "${BLUE}🔨 Building STP packages...${NC}"

    # Install dependencies
    pnpm install --frozen-lockfile

    # Build all packages
    pnpm run build

    echo -e "${GREEN}✅ Build complete${NC}"
}

# Deploy to Vercel
deploy_vercel() {
    echo -e "${BLUE}☁️  Deploying to Vercel...${NC}"

    # Check if logged in
    if ! vercel whoami &> /dev/null; then
        echo -e "${YELLOW}🔐 Please login to Vercel...${NC}"
        vercel login
    fi

    # Deploy
    vercel --prod --yes

    echo -e "${GREEN}✅ Vercel deployment complete${NC}"
    echo -e "${BLUE}🌐 Your app is live at the URL above${NC}"
}

# Deploy with Docker
deploy_docker() {
    echo -e "${BLUE}🐳 Deploying with Docker Compose...${NC}"

    # Check for .env.production
    if [ ! -f .env.production ]; then
        echo -e "${RED}❌ .env.production not found!${NC}"
        echo -e "${YELLOW}Copy .env.production.example to .env.production and fill in your credentials${NC}"
        exit 1
    fi

    # Build and start
    docker-compose -f docker-compose.yml up -d --build

    echo -e "${GREEN}✅ Docker deployment complete${NC}"
    echo -e "${BLUE}🌐 Frontend: http://localhost:3000${NC}"
    echo -e "${BLUE}🔧 Engine:   http://localhost:4000${NC}"
}

# Deploy to Railway
deploy_railway() {
    echo -e "${BLUE}🚂 Deploying to Railway...${NC}"

    if ! command -v railway &> /dev/null; then
        echo -e "${YELLOW}⚠️ Railway CLI not found, installing...${NC}"
        npm install -g @railway/cli
    fi

    railway login
    railway init $PROJECT_NAME
    railway up

    echo -e "${GREEN}✅ Railway deployment complete${NC}"
}

# Local development
run_local() {
    echo -e "${BLUE}🏠 Starting local development...${NC}"

    # Start all dev servers
    pnpm run dev
}

# Show usage
usage() {
    echo "Usage: ./deploy.sh [target]"
    echo ""
    echo "Targets:"
    echo "  vercel   - Deploy to Vercel (frontend only, free tier)"
    echo "  docker   - Full stack with Docker Compose (local/production)"
    echo "  railway  - Deploy to Railway (full stack, free tier)"
    echo "  local    - Run local development servers"
    echo ""
    echo "Examples:"
    echo "  ./deploy.sh vercel    # Quick frontend deploy"
    echo "  ./deploy.sh docker    # Full stack local/production"
    echo "  ./deploy.sh railway   # Free full stack cloud"
    echo "  ./deploy.sh local     # Local development"
}

# Main
main() {
    case $DEPLOY_TARGET in
        vercel|docker|railway|local)
            check_prerequisites
            build_project
            case $DEPLOY_TARGET in
                vercel) deploy_vercel ;;
                docker) deploy_docker ;;
                railway) deploy_railway ;;
                local) run_local ;;
            esac
            ;;
        *)
            usage
            exit 1
            ;;
    esac
}

main "$@"